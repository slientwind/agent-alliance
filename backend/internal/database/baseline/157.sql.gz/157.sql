-- Historical migrations SHA-256 d49c70aeda99cdb35cc80fbf94d8d5a219f17341b303e66d9e741eeef9946fe5
--
-- PostgreSQL database dump
--


-- Dumped from database version 16.10 (Debian 16.10-1.pgdg12+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg12+1)

SET LOCAL check_function_bodies = false;
SELECT pg_catalog.set_config('search_path', '', true);

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: a2a_new_question(text, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.a2a_new_question(prior_state text, prior_prompt text, prior_message text, next_state text, next_prompt text, next_message text) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT coalesce(next_state='input-required' AND
    (prior_state IS DISTINCT FROM next_state
      OR (next_prompt<>'' AND prior_prompt IS DISTINCT FROM next_prompt)
      OR (prior_message<>'' AND next_message<>'' AND prior_message<>next_message)),false)
$$;


--
-- Name: advance_account_revision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.advance_account_revision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.account_revision := OLD.account_revision + 1;
    RETURN NEW;
END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_revisions (
    agent_id uuid NOT NULL,
    revision integer NOT NULL,
    name text NOT NULL,
    instructions text NOT NULL,
    resource_id uuid,
    resource_revision integer,
    key_override bytea,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    card jsonb,
    tool jsonb,
    remote_policy jsonb,
    rpc_endpoint text,
    checks_version integer DEFAULT 0 NOT NULL,
    CONSTRAINT agent_revisions_check CHECK ((((card IS NULL) AND (tool IS NULL) AND (resource_id IS NOT NULL) AND (resource_revision IS NOT NULL)) OR ((card IS NOT NULL) AND (tool IS NULL) AND (resource_id IS NULL) AND (resource_revision IS NULL)) OR ((tool IS NOT NULL) AND (card IS NULL) AND (resource_id IS NULL) AND (resource_revision IS NULL)))),
    CONSTRAINT agent_revisions_check1 CHECK (((card IS NULL) = (rpc_endpoint IS NULL)))
);


--
-- Name: agent_accepts_planning_inputs(public.agent_revisions, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_accepts_planning_inputs(a public.agent_revisions, pins jsonb) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT agent_output_operation(a) <> 'aggregate' OR NOT EXISTS (
   SELECT FROM jsonb_to_recordset(pins) p(id uuid,version integer)
   JOIN source_versions v ON (v.source_id,v.version)=(p.id,p.version)
   WHERE lower(right(v.filename,4)) <> '.csv')
$$;


--
-- Name: agent_admissible(uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_admissible(target uuid, rev integer, actor uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT agent_revision_ready(target,rev) AND project_agent_access(NULL,target,rev,actor)
$$;


--
-- Name: agent_build_definition(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_build_definition(target uuid, version integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
 SELECT jsonb_strip_nulls(jsonb_build_object(
   'format',1,'agent',a.id,'revision',r.revision,'team',a.team_id,
   'kind',case when r.tool is not null then 'tool' when r.card is not null then 'external' else 'model' end,
   'output',agent_output_operation(r),
   'definitionDigest',encode(digest(jsonb_build_array(r.name,r.instructions)::text,'sha256'),'hex'),
   'model',case when mr.resource_id is not null then jsonb_build_object(
     'id',mr.resource_id,'revision',mr.revision,'name',mr.model,'operation',mr.operation,'streamText',mr.stream_text,
     'endpointDigest',encode(digest(mr.endpoint,'sha256'),'hex')) end,
   'tool',case when r.tool is not null then jsonb_build_object(
     'operation',r.tool->>'operation','contract',r.tool->>'contract',
     'digest',encode(digest(r.tool::text,'sha256'),'hex')) end,
   'remote',case when r.card is not null then jsonb_build_object(
     'protocol','a2a','endpointDigest',encode(digest(r.rpc_endpoint,'sha256'),'hex'),
     'cardDigest',encode(digest(r.card::text,'sha256'),'hex'),
     'policyDigest',encode(digest(coalesce(r.remote_policy,'{}')::text,'sha256'),'hex')) end,
   'skills',array(select jsonb_build_object('id',b.skill_id,'revision',b.skill_revision,'name',p.name,
       'digest',s.digest,'root',b.root)
       from agent_skill_bindings b join skill_revisions s on(s.skill_id,s.revision)=(b.skill_id,b.skill_revision)
       join skill_packs p on p.id=b.skill_id
       where(b.agent_id,b.revision)=(a.id,r.revision) order by b.position),
   'testsVersion',r.checks_version,
   'checks',array(select jsonb_strip_nulls(jsonb_build_object('id',c.id,'match',c.match_kind,
     'businessReview',c.reviewer is not null,
     'sampleDigest',encode(digest(jsonb_build_array(c.name,c.sample,c.expected,c.reviewer)::text,'sha256'),'hex')))
     from agent_checks c where(c.agent_id,c.revision)=(a.id,r.revision) order by c.ordinal)
 ))
 FROM agent_revisions r JOIN agents a ON a.id=r.agent_id
 LEFT JOIN model_revisions mr ON (mr.resource_id,mr.revision)=(r.resource_id,r.resource_revision)
 WHERE (r.agent_id,r.revision)=(target,version)
$$;


--
-- Name: agent_build_digest(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_build_digest(definition jsonb) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
 SELECT encode(digest(definition::text,'sha256'),'hex')
$$;


--
-- Name: agent_build_matches_publication(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_build_matches_publication(target uuid, version integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT coalesce((SELECT p.build_digest IS NOT DISTINCT FROM agent_build_digest(agent_build_definition(target,version))
    FROM agent_publications p WHERE (p.agent_id,p.revision)=(target,version)
    ORDER BY p.generation DESC LIMIT 1),true)
$$;


--
-- Name: agent_choice_profile(public.agent_revisions); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_choice_profile(candidate public.agent_revisions) RETURNS text
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE
   WHEN candidate.tool IS NOT NULL THEN tool_choice_profile(candidate.tool)
   WHEN (candidate.resource_id IS NOT NULL OR candidate.card IS NOT NULL)
     AND agent_output_operation(candidate)='text' AND NOT agent_uses_picture(candidate) THEN 'text'
 END
$$;


--
-- Name: agent_edits_picture(public.agent_revisions); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_edits_picture(a public.agent_revisions) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS (SELECT FROM model_revisions m
  WHERE (m.resource_id,m.revision)=(a.resource_id,a.resource_revision) AND m.operation='image-edit')
$$;


--
-- Name: agent_file_format(public.agent_revisions); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_file_format(a public.agent_revisions) RETURNS text
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE agent_output_operation(a)
   WHEN 'aggregate' THEN 'xlsx' WHEN 'extract' THEN 'text' ELSE agent_output_operation(a) END
$$;


--
-- Name: agent_next_review(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_next_review(target uuid, rev integer) RETURNS timestamp with time zone
    LANGUAGE sql STABLE
    AS $$
 SELECT (CASE WHEN EXISTS(SELECT FROM agent_checks WHERE agent_id=target AND revision=rev)
   THEN (SELECT min(c.ended_at) FROM check_outcomes c WHERE (c.agent_id,c.revision)=(target,rev) AND c.passed)
   ELSE (SELECT max(v.ended_at) FROM validations v WHERE (v.agent_id,v.revision)=(target,rev) AND v.status='passed'
        AND NOT EXISTS(SELECT FROM validation_withdrawals w WHERE w.trial_id=v.id))
 END) + interval '90 days'
$$;


--
-- Name: agent_output_operation(public.agent_revisions); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_output_operation(a public.agent_revisions) RETURNS text
    LANGUAGE sql STABLE
    AS $$
 SELECT coalesce(a.tool->>'operation',
   (SELECT case m.operation when 'vision' then 'text' when 'image-edit' then 'png' else m.operation end
    FROM model_revisions m WHERE (m.resource_id,m.revision)=(a.resource_id,a.resource_revision)),'text')
$$;


--
-- Name: agent_released_remote_operation_evidence(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_released_remote_operation_evidence(target uuid, rev integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  SELECT p.evidence_snapshot->'remoteOperations'
  FROM agent_publications p WHERE (p.agent_id,p.revision)=(target,rev) AND p.evidence_snapshot ? 'remoteOperations'
  ORDER BY p.generation LIMIT 1
$$;


--
-- Name: agent_remote_operation_evidence(uuid, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_remote_operation_evidence(target uuid, rev integer, build text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  SELECT jsonb_strip_nulls(jsonb_build_object('send',coalesce(direct_text,send),'directText',direct_text,
      'query',coalesce(async_text,query),'asyncText',async_text,'cancel',cancel,
      'supplement',coalesce(supplement_text,supplement),'supplementText',supplement_text))
  FROM (
    SELECT max(o.id) FILTER (WHERE o.operation='send' AND o.outcome<>'unconfirmed') send,
      max(o.id) FILTER (WHERE o.operation='send' AND o.outcome='text' AND result.passed) direct_text,
      max(o.id) FILTER (WHERE o.operation='query' AND o.outcome<>'unconfirmed' AND result.accepted) query,
      max(o.id) FILTER (WHERE o.operation='query' AND o.outcome='text' AND result.accepted AND result.passed) async_text,
      max(o.id) FILTER (WHERE o.operation='cancel' AND o.remote_state='canceled' AND result.accepted) cancel,
      max(o.id) FILTER (WHERE o.operation='supplement' AND o.outcome<>'unconfirmed' AND result.accepted
         AND o.remote_state IN ('submitted','working','completed')) supplement,
      max(o.id) FILTER (WHERE o.operation='supplement' AND o.outcome='text' AND result.accepted AND result.passed) supplement_text
    FROM validations v JOIN remote_trial_observations o ON o.trial_id=v.id
    LEFT JOIN agent_checks c ON c.id=v.check_id
    CROSS JOIN LATERAL (
      SELECT v.status='passed' AND (c.reviewer IS NULL OR EXISTS(
           SELECT FROM validation_reviews vr WHERE vr.trial_id=v.id AND vr.passed)) AS passed,
        EXISTS(SELECT FROM remote_trial_observations initial WHERE initial.trial_id=v.id
          AND initial.operation='send' AND initial.outcome='state'
          AND initial.remote_state IN ('submitted','working','input-required','auth-required')) AS accepted
    ) result
    WHERE (v.agent_id,v.revision,v.build_digest)=(target,rev,build)
      AND NOT EXISTS(SELECT FROM validation_withdrawals w WHERE w.trial_id=v.id)
  ) observed
$$;


--
-- Name: agent_requires_model_restore(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_requires_model_restore(target uuid, version integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM model_replacement_agents x JOIN agents a ON a.id=x.agent_id
 WHERE (x.agent_id,x.original)=(target,version) AND a.published_revision=x.draft
   AND x.adoption_generation=a.publication_generation AND x.rollback_at IS NULL)
$$;


--
-- Name: agent_revision_ready(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_revision_ready(target uuid, rev integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM agents a JOIN agent_revisions r ON r.agent_id=a.id
 LEFT JOIN model_resources m ON m.id=r.resource_id LEFT JOIN model_revisions v ON(v.resource_id,v.revision)=(r.resource_id,r.resource_revision)
 WHERE a.id=target AND r.revision=rev AND NOT a.disabled AND NOT a.emergency AND NOT a.removed
 AND (r.resource_id IS NULL OR (m.team_id=a.team_id AND m.enabled AND NOT m.emergency AND (r.key_override IS NOT NULL OR NOT v.key_blocked)))
 AND agent_build_matches_publication(target,rev)
 AND (r.card IS NULL OR remote_operation_ready(agent_released_remote_operation_evidence(target,rev)))
 AND agent_verified(target,rev) AND agent_skills_usable(target,rev,NULL))
$$;


--
-- Name: agent_skill_activation_coverage(uuid, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_skill_activation_coverage(target uuid, rev integer, build text) RETURNS TABLE(skill_id uuid, skill_revision integer, proof uuid)
    LANGUAGE sql STABLE
    AS $$
 SELECT b.skill_id,b.skill_revision,trial.id
 FROM agent_skill_bindings b
 JOIN skill_revisions s ON (s.skill_id,s.revision)=(b.skill_id,b.skill_revision)
 LEFT JOIN LATERAL (
   SELECT v.id FROM validation_skill_inputs used JOIN validations v ON v.id=used.trial_id
   WHERE (used.skill_id,used.skill_revision)=(b.skill_id,b.skill_revision)
     AND (v.agent_id,v.revision,v.build_digest)=(target,rev,build) AND v.status='passed'
     AND NOT EXISTS(SELECT FROM validation_withdrawals w WHERE w.trial_id=v.id)
   ORDER BY v.created_at DESC,v.id DESC LIMIT 1
 ) trial ON true
 WHERE (b.agent_id,b.revision)=(target,rev) AND b.root AND cardinality(s.activation_terms)>0
$$;


--
-- Name: agent_skills_usable(uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_skills_usable(target uuid, rev integer, actor uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT NOT EXISTS (
   SELECT FROM agent_skill_bindings b JOIN skill_revisions s ON (s.skill_id,s.revision)=(b.skill_id,b.skill_revision)
     JOIN skill_packs p ON p.id=b.skill_id
   WHERE (b.agent_id,b.revision)=(target,rev)
      AND (s.revoked_at IS NOT NULL OR (actor IS NOT NULL AND NOT EXISTS (
          SELECT FROM team_members m JOIN members u ON u.id=m.member_id AND u.enabled
          WHERE m.team_id=p.team_id AND m.member_id=actor
      )))
 )
$$;


--
-- Name: agent_uses_picture(public.agent_revisions); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_uses_picture(a public.agent_revisions) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS (SELECT FROM model_revisions m
  WHERE (m.resource_id,m.revision)=(a.resource_id,a.resource_revision) AND m.operation IN ('vision','image-edit'))
$$;


--
-- Name: agent_verified(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_verified(target uuid, rev integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT coalesce(
  (SELECT bool_and(coalesce(c.passed,false)) FROM check_outcomes c WHERE (c.agent_id,c.revision)=(target,rev)),
  EXISTS(SELECT FROM validations v WHERE (v.agent_id,v.revision)=(target,rev) AND v.status='passed'
   AND NOT EXISTS (SELECT FROM validation_withdrawals w WHERE w.trial_id=v.id))
 ) AND CASE WHEN EXISTS(
   SELECT FROM agent_skill_bindings b JOIN skill_revisions s ON (s.skill_id,s.revision)=(b.skill_id,b.skill_revision)
   WHERE (b.agent_id,b.revision)=(target,rev) AND b.root AND cardinality(s.activation_terms)>0
 ) THEN NOT EXISTS (
   SELECT FROM agent_skill_activation_coverage(target,rev,agent_build_digest(agent_build_definition(target,rev)))
   WHERE proof IS NULL
 ) ELSE true END
$$;


--
-- Name: aggregate_scope(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.aggregate_scope(tool jsonb) RETURNS jsonb
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
 SELECT jsonb_strip_nulls(jsonb_build_object(
  'group',tool->'config'->>'group',
  'amount',tool->'config'->>'amount',
  'filterColumn',tool->'config'->>'filterColumn',
  'filterValue',tool->'config'->>'filterValue',
  'unitColumn',tool->'config'->>'unitColumn'
 ))
$$;


--
-- Name: artifact_draft_block_reason(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.artifact_draft_block_reason(target uuid, edition integer) RETURNS text
    LANGUAGE sql STABLE
    AS $$
 WITH origin AS MATERIALIZED (SELECT * FROM working_artifact_origin(target,edition))
 SELECT CASE WHEN EXISTS(SELECT FROM origin o
    CROSS JOIN LATERAL working_preference_inputs(o.run_id,o.ordinal,o.attempt_no) f WHERE NOT f.usable) THEN 'preference'
  WHEN EXISTS(SELECT FROM origin o
    CROSS JOIN LATERAL invalid_working_step_rules(o.run_id,o.ordinal,o.attempt_no) r WHERE r.scoped) THEN 'rule' END
$$;


--
-- Name: artifact_execution_run(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.artifact_execution_run(target uuid, edition integer) RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
 SELECT coalesce((SELECT b.run_id FROM rule_branch_steps b WHERE b.artifact_id=a.id
       AND b.mode<>'reuse' AND b.result_version<=edition ORDER BY b.result_version DESC LIMIT 1),a.run_id)
 FROM artifacts a WHERE a.id=target
$$;


--
-- Name: artifact_rule_draft_readable(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.artifact_rule_draft_readable(target uuid, edition integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT artifact_draft_block_reason(target,edition) IS NULL
$$;


--
-- Name: run_source_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_source_receipts (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    request_revision integer NOT NULL,
    source_id uuid NOT NULL,
    source_version integer NOT NULL,
    kind text NOT NULL,
    excerpt_start integer NOT NULL,
    excerpt_end integer NOT NULL,
    CONSTRAINT run_source_receipts_check CHECK (((excerpt_end > excerpt_start) AND ((excerpt_end - excerpt_start) <= 320))),
    CONSTRAINT run_source_receipts_excerpt_start_check CHECK ((excerpt_start >= 0)),
    CONSTRAINT run_source_receipts_kind_check CHECK ((kind = ANY (ARRAY['lookup'::text, 'calculation'::text]))),
    CONSTRAINT run_source_receipts_ordinal_check CHECK ((ordinal > 0)),
    CONSTRAINT run_source_receipts_request_revision_check CHECK ((request_revision > 0))
);


--
-- Name: artifact_step_receipts(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.artifact_step_receipts(target uuid, edition integer) RETURNS SETOF public.run_source_receipts
    LANGUAGE plpgsql STABLE ROWS 8
    AS $$
BEGIN
 RETURN QUERY
 WITH RECURSIVE origin(run_id,ordinal) AS (
   SELECT a.run_id,a.ordinal FROM artifacts a WHERE a.id=target AND edition=1
   UNION
   SELECT b.run_id,a.ordinal FROM change_batches b JOIN artifacts a ON a.id=b.artifact_id
   WHERE a.id=target AND b.applied_version=edition
   UNION
   SELECT b.run_id,b.ordinal FROM rule_branch_steps b
   WHERE b.artifact_id=target AND b.result_version=edition AND b.mode<>'reuse'
 ), lineage(run_id,ordinal,attempt_no) AS (
   SELECT i.run_id,i.ordinal,i.attempt_no FROM origin o JOIN invocations i USING (run_id,ordinal)
   UNION
   SELECT p.parent_run,p.parent_ordinal,p.parent_attempt FROM lineage l
   JOIN run_working_parents p USING (run_id,ordinal,attempt_no)
 )
 SELECT DISTINCT r.* FROM lineage l
 JOIN run_working_inputs d USING (run_id,ordinal,attempt_no)
 JOIN step_source_receipt_inputs f ON (f.run_id,f.reader,f.source_id,f.source_version)=(l.run_id,l.ordinal,d.ref,d.revision)
 JOIN run_source_receipts r USING (request_revision)
 WHERE d.kind='source'
 UNION
 SELECT r.* FROM change_batches b JOIN source_assessments c ON c.id=b.source_assessment
 CROSS JOIN LATERAL artifact_step_receipts(target,b.base_version) r
 WHERE b.artifact_id=target AND b.applied_version=edition AND b.base_version<edition
   AND (r.source_id,r.source_version)=(c.source_id,c.pinned_version);
END
$$;


--
-- Name: artifact_upstream_context; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifact_upstream_context (
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    body_digest text NOT NULL,
    CONSTRAINT artifact_upstream_context_body_digest_check CHECK ((body_digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: artifact_upstream_origin(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.artifact_upstream_origin(target uuid, edition integer) RETURNS SETOF public.artifact_upstream_context
    LANGUAGE sql STABLE ROWS 1
    AS $$
 WITH RECURSIVE lineage(version) AS (
   SELECT edition
   UNION ALL SELECT v.copied_from FROM lineage l JOIN artifact_versions v
     ON (v.artifact_id,v.version)=(target,l.version) WHERE v.copied_from IS NOT NULL
 )
 SELECT c.* FROM lineage l JOIN artifact_upstream_context c
   ON (c.artifact_id,c.version)=(target,l.version) ORDER BY c.version DESC LIMIT 1
$$;


--
-- Name: artifact_upstream_review_entries(uuid, uuid, integer, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.artifact_upstream_review_entries(target_project uuid, target uuid, edition integer, viewer uuid, source_step integer) RETURNS TABLE(origin_version integer, step integer, attempt integer, name text, source_version integer, current_version integer, total_bytes integer, head_bytes integer, tail_from integer, available boolean, body text)
    LANGUAGE sql STABLE ROWS 12
    SET jit TO 'off'
    AS $$
 WITH work AS MATERIALIZED (
   SELECT c.version,w.upstream_context,run_working_set_usable(c.run_id,c.ordinal,c.attempt_no)
     AND encode(digest(convert_to(v.body,'UTF8'),'sha256'),'hex')=c.body_digest AS usable
   FROM artifacts a JOIN artifact_versions v ON (v.artifact_id,v.version)=(a.id,edition)
   JOIN project_members pm ON (pm.project_id,pm.member_id)=(a.project_id,viewer) AND pm.can_review
   JOIN members m ON m.id=pm.member_id AND m.enabled AND m.departed_at IS NULL
   JOIN LATERAL artifact_upstream_origin(a.id,v.version) c ON true
   JOIN run_working_sets w ON (w.run_id,w.ordinal,w.attempt_no)=(c.run_id,c.ordinal,c.attempt_no)
   WHERE (a.project_id,a.id)=(target_project,target) AND v.version=a.current_version
     AND distribution_readable(a.id,v.version,viewer)
 )
 SELECT work.version,clip.step,
   CASE WHEN valid.allowed THEN clip."originAttempt" END,
   CASE WHEN valid.allowed THEN a.name END,
   CASE WHEN valid.allowed THEN v.version END,
   CASE WHEN valid.allowed THEN a.current_version END,
   CASE WHEN valid.allowed THEN clip."totalBytes" END,
   CASE WHEN valid.allowed THEN clip."headBytes" END,
   CASE WHEN valid.allowed THEN clip."tailFrom" END,
   valid.allowed, CASE WHEN source_step>0 AND valid.allowed THEN original.body END
 FROM work CROSS JOIN LATERAL jsonb_to_recordset(work.upstream_context) AS clip(
   step int,"originRun" uuid,"originAttempt" int,artifact uuid,version int,
   "totalBytes" int,"headBytes" int,"tailFrom" int,digest text)
 LEFT JOIN artifacts a ON (a.id,a.project_id)=(clip.artifact,target_project)
 LEFT JOIN artifact_versions v ON (v.artifact_id,v.version)=(a.id,clip.version)
 LEFT JOIN runs r ON (r.id,r.project_id)=(clip."originRun",target_project)
 LEFT JOIN invocations i ON (i.run_id,i.ordinal,i.attempt_no)=(r.id,clip.step,clip."originAttempt") AND i.status='completed'
 CROSS JOIN LATERAL (SELECT CASE WHEN clip.artifact IS NULL THEN i.result ELSE v.body END AS body) original
 CROSS JOIN LATERAL (SELECT coalesce(work.usable AND original.body IS NOT NULL
   AND (clip.artifact IS NULL OR distribution_readable(a.id,v.version,viewer))
   AND (clip."originRun" IS NULL OR (r.id IS NOT NULL AND run_working_set_usable(r.id,clip.step,clip."originAttempt")))
   AND octet_length(original.body)=clip."totalBytes"
   AND encode(digest(convert_to(original.body,'UTF8'),'sha256'),'hex')=clip.digest
   AND 0<=clip."headBytes" AND clip."headBytes"<=clip."tailFrom" AND clip."tailFrom"<=clip."totalBytes",
   false) AS allowed) valid
 WHERE source_step=0 OR clip.step=source_step
 ORDER BY clip.step
$$;


--
-- Name: assign_event_attempt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_event_attempt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.ordinal IS NOT NULL THEN
    SELECT attempt_no INTO NEW.call_attempt FROM invocations WHERE run_id=NEW.run_id AND ordinal=NEW.ordinal;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: bind_artifact_copy(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bind_artifact_copy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.copied_from IS NULL AND NEW.reason='上游内容变化，需要核对引用' AND EXISTS(
   SELECT FROM artifact_versions b WHERE (b.artifact_id,b.version,b.body)=(NEW.artifact_id,NEW.version-1,NEW.body)
 ) THEN
   NEW.copied_from := NEW.version-1;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: bind_artifact_remote_receipt(uuid, integer, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bind_artifact_remote_receipt(target uuid, edition integer, origin uuid, step_no integer) RETURNS void
    LANGUAGE sql
    AS $$
 INSERT INTO artifact_remote_receipts(artifact_id,version,run_id,ordinal,attempt_no)
 SELECT v.artifact_id,v.version,i.run_id,i.ordinal,i.attempt_no
 FROM invocations i JOIN remote_completion_evidence e USING(run_id,ordinal,attempt_no)
 JOIN runs r ON r.id=i.run_id
 JOIN artifacts a ON (a.id,a.project_id,a.ordinal)=(target,r.project_id,i.ordinal)
 JOIN artifact_versions v ON (v.artifact_id,v.version)=(a.id,edition)
 WHERE (i.run_id,i.ordinal)=(origin,step_no) AND i.status='completed'
   AND i.remote_status='completed' AND i.remote_task=e.task AND v.body=i.result
   AND e.body_digest=encode(digest(v.body,'sha256'),'hex')
 ON CONFLICT (artifact_id,version) DO NOTHING
$$;


--
-- Name: bind_artifact_upstream_context(uuid, integer, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bind_artifact_upstream_context(target uuid, edition integer, origin uuid, step_no integer) RETURNS void
    LANGUAGE sql
    AS $$
 INSERT INTO artifact_upstream_context(artifact_id,version,run_id,ordinal,attempt_no,body_digest)
 SELECT v.artifact_id,v.version,i.run_id,i.ordinal,i.attempt_no,encode(digest(convert_to(v.body,'UTF8'),'sha256'),'hex')
 FROM invocations i JOIN run_working_sets w USING(run_id,ordinal,attempt_no)
 JOIN runs r ON r.id=i.run_id
 JOIN artifacts a ON (a.id,a.project_id,a.ordinal)=(target,r.project_id,i.ordinal)
 JOIN artifact_versions v ON (v.artifact_id,v.version)=(a.id,edition)
 WHERE (i.run_id,i.ordinal)=(origin,step_no) AND i.status='completed' AND v.body=i.result
   AND jsonb_array_length(w.upstream_context)>0
   AND NOT EXISTS(SELECT FROM jsonb_array_elements(w.upstream_context) input WHERE input->>'digest' IS NULL)
 ON CONFLICT (artifact_id,version) DO NOTHING
$$;


--
-- Name: budget_amount_short(numeric, numeric, boolean, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.budget_amount_short(used numeric, known numeric, has_unknown boolean, ceiling numeric) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
 SELECT coalesce((known>0 AND used+known>ceiling) OR (has_unknown AND used>=ceiling),false)
$$;


--
-- Name: call_operation(uuid, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.call_operation(uuid, integer, integer) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
 SELECT $1::text||'-'||$2::text||CASE WHEN $3=1 THEN '' ELSE '/attempt/'||$3::text END
$_$;


--
-- Name: call_span_id(uuid, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.call_span_id(uuid, integer, integer) RETURNS bytea
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
 SELECT substr(digest($1::text||'/'||$2::text||CASE WHEN $3=1 THEN '' ELSE '/attempt/'||$3::text END,'sha256'),1,8)
$_$;


--
-- Name: cancel_departed_maintenance_offer(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cancel_departed_maintenance_offer() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 WITH cancelled AS (
 UPDATE agents SET maintenance_vacant=(maintenance_vacant OR owner=OLD.member_id),proposed_owner=NULL,proposed_by=NULL,transfer_reason=NULL,maintenance_version=maintenance_version+1
 WHERE team_id=OLD.team_id AND (owner=OLD.member_id OR OLD.member_id IN(proposed_owner,proposed_by))
 RETURNING id,maintenance_version)
 INSERT INTO audit_events(action,subject,detail) SELECT 'agent.maintenance.membership',id::text,
 jsonb_build_object('member',OLD.member_id,'version',maintenance_version) FROM cancelled;
 RETURN OLD;
END $$;


--
-- Name: candidate_distribution_held(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.candidate_distribution_held(project uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM distribution_cases c JOIN artifacts a ON a.id=c.artifact_id AND a.current_version=c.version
 WHERE c.project_id=project AND c.state<>'reference')
$$;


--
-- Name: capture_originating_department(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.capture_originating_department() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    SELECT department_id INTO NEW.originating_department FROM members
    WHERE id = (to_jsonb(NEW)->>TG_ARGV[0])::uuid FOR SHARE;
    RETURN NEW;
END $$;


--
-- Name: clear_budget_owner(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_budget_owner() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE teams SET budget_owner=NULL WHERE id=OLD.team_id AND budget_owner=OLD.member_id;
 RETURN OLD;
END $$;


--
-- Name: clear_ended_lookup_turns(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_ended_lookup_turns() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE lookup_turns SET decision=NULL,outcome='run_ended',refinement_evidence=NULL,initial_evidence=NULL
    WHERE run_id=NEW.id AND decision IS NOT NULL;
    RETURN NULL;
END $$;


--
-- Name: clear_extraction_locations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_extraction_locations() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 NEW.extraction_locations = NULL;
 NEW.extraction_state = '';
 RETURN NEW;
END $$;


--
-- Name: clear_invalidated_local_action(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_invalidated_local_action() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE lookup_turns t
    SET decision=NULL,outcome=case when t.decision is not null then 'invalidated' else t.outcome end,
        refinement_evidence=NULL,initial_evidence=NULL
    WHERE (t.run_id,t.ordinal,t.attempt_no)=(NEW.run_id,NEW.ordinal,NEW.attempt_no)
      AND (t.decision IS NOT NULL OR t.refinement_evidence IS NOT NULL OR t.initial_evidence IS NOT NULL);
    RETURN NULL;
END $$;


--
-- Name: clear_revoked_lookup_turns(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_revoked_lookup_turns() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE lookup_turns t SET decision=NULL,outcome='invalidated',refinement_evidence=NULL,initial_evidence=NULL
    FROM runs r, plan_sources p
    WHERE r.id=t.run_id AND p.project_id=r.project_id AND p.plan_version=t.plan_version
      AND p.source_id=NEW.id AND t.decision IS NOT NULL;
    RETURN NULL;
END $$;


--
-- Name: close_budget_requests(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.close_budget_requests() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 WITH closed AS (
  UPDATE budget_requests SET state='closed',decided_at=now(),
   decision_reason=CASE NEW.stage WHEN 'delivered' THEN '项目已交付' WHEN 'adopted' THEN '成果已采纳' WHEN 'failed' THEN '运行已确认失败' ELSE '项目已取消' END
  WHERE project_id=NEW.id AND state='pending' RETURNING id
 ) INSERT INTO audit_events(actor,action,subject,detail)
 SELECT NULL,'budget.request.close',id::text,jsonb_build_object('project',NEW.id,'stage',NEW.stage) FROM closed;
 RETURN NEW;
END $$;


--
-- Name: close_project_review_clocks(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.close_project_review_clocks() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE review_clocks SET closed_at=clock_timestamp() WHERE project_id=NEW.id AND closed_at IS NULL;
 RETURN NEW;
END $$;


--
-- Name: close_responsibility_offers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.close_responsibility_offers() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE reviewer_handoffs SET state='closed',decided_at=now(),decision_reason='项目已结束'
 WHERE project_id=NEW.id AND state='pending'; RETURN NEW;
END $$;


--
-- Name: column_correction_items(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.column_correction_items(document jsonb) RETURNS SETOF jsonb
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
 SELECT value FROM jsonb_array_elements(
   CASE jsonb_typeof(document)
   WHEN 'array' THEN document
   WHEN 'object' THEN jsonb_build_array(document)
   ELSE '[]'::jsonb END)
$$;


--
-- Name: count_agent_publication(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.count_agent_publication() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 NEW.publication_generation := OLD.publication_generation + 1;
 RETURN NEW;
END $$;


--
-- Name: create_project_budget(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_project_budget() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 INSERT INTO project_budgets(project_id) VALUES(NEW.id);
 RETURN NEW;
END $$;


--
-- Name: delivery_revision_targets(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delivery_revision_targets(delivery_key uuid) RETURNS TABLE(artifact_id uuid, version integer)
    LANGUAGE sql STABLE
    AS $$
  SELECT i.artifact_id,i.version FROM delivery_items i JOIN artifacts a ON a.id=i.artifact_id
  WHERE i.delivery_id=delivery_key AND a.current_version=i.version
  UNION
  SELECT a.id,a.current_version
  FROM deliveries d CROSS JOIN LATERAL jsonb_array_elements(d.coverage->'items') item
  JOIN artifacts a ON a.id::text=item->>'artifact' AND a.current_version=(item->>'version')::int
  WHERE d.id=delivery_key AND d.partial AND item->>'state'='missing' AND a.project_id=d.project_id
$$;


--
-- Name: discard_invalidated_text_reply(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.discard_invalidated_text_reply() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE text_reply_checkpoints SET state='discarded',payload=NULL
 WHERE (run_id,ordinal,attempt_no)=(NEW.run_id,NEW.ordinal,NEW.attempt_no) AND state='pending';
 RETURN NULL;
END $$;


--
-- Name: discard_pending_local_observation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.discard_pending_local_observation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE local_action_observations SET discarded_at=now(),payload=NULL
    WHERE (run_id,ordinal,attempt_no)=(NEW.run_id,NEW.ordinal,NEW.attempt_no) AND payload IS NOT NULL;
    RETURN NULL;
END $$;


--
-- Name: discard_run_text_replies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.discard_run_text_replies() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE text_reply_checkpoints SET state='discarded',payload=NULL
 WHERE run_id=NEW.id AND state='pending';
 RETURN NULL;
END $$;


--
-- Name: distribution_readable(uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.distribution_readable(target uuid, ver integer, member uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT artifact_rule_draft_readable(target,ver) AND NOT EXISTS(
 SELECT FROM artifacts a JOIN runs r ON r.id=a.run_id JOIN projects p ON p.id=a.project_id
 JOIN project_members m ON m.project_id=p.id AND m.member_id=member
 JOIN plan_sources ps ON (ps.project_id,ps.plan_version)=(r.project_id,r.plan_version)
 JOIN withdrawn_delivery_sources s ON s.id=ps.source_id
 LEFT JOIN LATERAL(SELECT decision FROM distribution_reviews v
 WHERE(v.source_id,v.artifact_id,v.version)=(s.id,a.id,ver) ORDER BY revision DESC LIMIT 1) latest ON true
 WHERE a.id=target AND NOT m.can_review AND member NOT IN(p.owner,s.created_by) AND latest.decision IS DISTINCT FROM 'reference')
$$;


--
-- Name: distribution_state(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.distribution_state(target uuid) RETURNS text
    LANGUAGE sql STABLE
    AS $$
 SELECT coalesce((SELECT c.state FROM delivery_items i JOIN delivery_distribution_inputs e USING(delivery_id)
 JOIN distribution_cases c ON(c.source_id,c.artifact_id,c.version)=(e.source_id,i.artifact_id,i.version)
 WHERE i.delivery_id=target ORDER BY CASE c.state WHEN 'restricted' THEN 1 WHEN 'invalid' THEN 2 WHEN 'pending' THEN 3 ELSE 4 END LIMIT 1),'clear')
$$;


--
-- Name: editable_slide_outline(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.editable_slide_outline(target uuid, ver integer) RETURNS text
    LANGUAGE sql STABLE
    AS $$
 SELECT v.body FROM artifact_versions v WHERE (v.artifact_id,v.version)=(target,ver)
 AND verified_document_format(target,ver)='pptx';
$$;


--
-- Name: end_management_grants(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.end_management_grants() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_TABLE_NAME = 'team_members' THEN
        UPDATE management_grants SET revoked_at=now(), revoked_reason='已移出授权团队'
        WHERE member_id=OLD.member_id AND team_id=OLD.team_id AND revoked_at IS NULL;
    ELSE
        UPDATE management_grants SET revoked_at=now(),
            revoked_reason=CASE WHEN NEW.enabled THEN '已调离授权部门' ELSE '成员账号已停用' END
        WHERE member_id=OLD.id AND revoked_at IS NULL AND
            (NOT NEW.enabled OR department_id=OLD.department_id);
    END IF;
    RETURN NULL;
END $$;


--
-- Name: end_recovery_after_project_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.end_recovery_after_project_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE reviewer_handoffs SET access_ended_at=least(now(),recovery_until),access_end_reason=CASE WHEN recovery_until<=now() THEN '授权已到期' WHEN NEW.stage IN('delivered','adopted','cancelled','failed') THEN '项目已结束' ELSE '确认职责已转交' END
 WHERE id=OLD.reviewer_assignment AND recovery_until IS NOT NULL AND access_ended_at IS NULL;
 RETURN NEW;
END $$;


--
-- Name: end_recovery_on_account_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.end_recovery_on_account_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE reviewer_handoffs SET access_ended_at=now(),access_end_reason='账号或管理授权已变更'
 WHERE recovery_until IS NOT NULL AND access_ended_at IS NULL AND state IN('accepted','pending','superseded')
 AND ((NOT NEW.enabled AND NEW.id IN(proposer,successor)) OR (NEW.role<>'admin' AND NEW.id=proposer));
 RETURN NEW;
END $$;


--
-- Name: end_recovery_on_team_loss(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.end_recovery_on_team_loss() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE reviewer_handoffs h SET access_ended_at=now(),access_end_reason='团队授权已撤销',
 state=CASE WHEN h.state='pending' THEN 'superseded' ELSE h.state END
 FROM projects p WHERE p.id=h.project_id AND p.team_id=OLD.team_id AND OLD.member_id IN(h.proposer,h.successor)
 AND h.recovery_until IS NOT NULL AND h.access_ended_at IS NULL AND h.state IN('pending','accepted');
 RETURN OLD;
END $$;


--
-- Name: end_team_rule_duties(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.end_team_rule_duties() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 WITH changes AS (
 UPDATE team_rules SET maintenance_vacant=maintenance_vacant OR maintainer=OLD.member_id,
 proposed_owner=NULL,proposed_by=NULL,transfer_reason=NULL,maintenance_version=maintenance_version+1
 WHERE team_id=OLD.team_id AND ((maintainer=OLD.member_id AND NOT maintenance_vacant) OR OLD.member_id IN(proposed_owner,proposed_by))
 RETURNING id,maintenance_version)
 INSERT INTO audit_events(action,subject,detail) SELECT 'rule.maintenance.membership',id::text,
 jsonb_build_object('member',OLD.member_id,'version',maintenance_version) FROM changes;
 RETURN OLD;
END $$;


--
-- Name: enqueue_trace_span(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enqueue_trace_span() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_TABLE_NAME='runs' THEN
   IF NEW.finished_at IS NOT NULL THEN
     INSERT INTO telemetry_outbox(run_id,ordinal) VALUES(NEW.id,0) ON CONFLICT DO NOTHING;
   END IF;
 ELSIF NEW.ended_at IS NOT NULL THEN
   INSERT INTO telemetry_outbox(run_id,ordinal,call_attempt) VALUES(NEW.run_id,NEW.ordinal,NEW.attempt_no) ON CONFLICT DO NOTHING;
 END IF;
 RETURN NULL;
END $$;


--
-- Name: enter_review_period(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enter_review_period() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.stage='review' THEN NEW.review_started_at=now(); ELSE NEW.review_started_at=NULL; END IF;
 RETURN NEW;
END $$;


--
-- Name: erase_lookup_question_on_invalidation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.erase_lookup_question_on_invalidation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE lookup_question_handoffs SET question=NULL
    WHERE (run_id,parent,parent_attempt)=(NEW.run_id,NEW.ordinal,NEW.attempt_no)
      AND question IS NOT NULL;
    RETURN NULL;
END $$;


--
-- Name: erase_lookup_questions_on_run_end(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.erase_lookup_questions_on_run_end() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE lookup_question_handoffs SET question=NULL WHERE run_id=NEW.id AND question IS NOT NULL;
    RETURN NULL;
END $$;


--
-- Name: evidence_follow_up_skipped(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.evidence_follow_up_skipped(run_key uuid, step_no integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    SELECT exists(select from trace_events where run_id=run_key and ordinal=step_no and code='lookup_synthesis_skipped')
$$;


--
-- Name: expire_inactive_reviewer_offers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.expire_inactive_reviewer_offers() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE reviewer_handoffs SET state='superseded',decided_at=now(),decision_reason='成员状态或接管授权已变更'
 WHERE state='pending' AND ((NOT NEW.enabled AND NEW.id IN(successor,proposer))
 OR (emergency AND NEW.id=proposer AND NEW.role<>'admin'));
 RETURN NEW;
END $$;


--
-- Name: expire_responsibility_offers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.expire_responsibility_offers() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE reviewer_handoffs SET state='superseded',decided_at=now(),decision_reason='项目参与资格已变更'
 WHERE project_id=OLD.project_id AND state='pending' AND OLD.member_id IN(successor,proposer);
 RETURN OLD;
END $$;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    artifact_id uuid NOT NULL,
    base_version integer NOT NULL,
    author uuid NOT NULL,
    reviewer uuid NOT NULL,
    kind text NOT NULL,
    "position" text NOT NULL,
    body text NOT NULL,
    state text NOT NULL,
    candidate_version integer,
    revision integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    submission_id uuid,
    submission_item integer,
    CONSTRAINT feedback_check CHECK (((submission_id IS NULL) = (submission_item IS NULL))),
    CONSTRAINT feedback_kind_check CHECK ((kind = ANY (ARRAY['suggestion'::text, 'change'::text, 'issue'::text]))),
    CONSTRAINT feedback_state_check CHECK ((state = ANY (ARRAY['suggested'::text, 'required'::text, 'investigate'::text, 'verification'::text, 'closed'::text, 'declined'::text, 'withdrawn'::text])))
);


--
-- Name: feedback_notes_readable(public.feedback, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.feedback_notes_readable(item public.feedback, viewer uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS (
   SELECT FROM artifacts a WHERE a.id=item.artifact_id AND run_review_notes_readable(a.run_id,viewer)
 ) AND NOT EXISTS (
   SELECT FROM feedback f JOIN artifacts a ON a.id=f.artifact_id
   WHERE (f.submission_id,f.submission_item)=(item.submission_id,item.submission_item)
   AND f.artifact_id<>item.artifact_id AND NOT run_review_notes_readable(a.run_id,viewer)
 )
$$;


--
-- Name: guard_unscoped_preference_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_unscoped_preference_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF EXISTS(SELECT FROM preferences f WHERE (f.id,f.revision)=(NEW.preference_id,NEW.revision) AND f.agent_scope IS NOT NULL) THEN
        RAISE EXCEPTION 'scoped preferences require a scope-aware plan writer';
    END IF;
    RETURN NEW;
END $$;


--
-- Name: inherit_agent_checks(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.inherit_agent_checks() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 INSERT INTO agent_checks(agent_id,revision,ordinal,name,sample,expected,match_kind,reviewer)
 SELECT agent_id,NEW.revision,ordinal,name,sample,expected,match_kind,reviewer
 FROM agent_checks WHERE agent_id=NEW.agent_id AND revision=NEW.revision-1;
 RETURN NEW;
END $$;


--
-- Name: initialize_rule_maintenance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.initialize_rule_maintenance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 NEW.maintainer=coalesce(NEW.maintainer,NEW.author);
 RETURN NEW;
END $$;


--
-- Name: invalid_working_step_rules(uuid, integer, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalid_working_step_rules(run_key uuid, step_no integer, attempt integer, viewer uuid DEFAULT NULL::uuid) RETURNS TABLE(rule_id uuid, rule_revision integer, scoped boolean)
    LANGUAGE sql STABLE
    AS $$
 WITH RECURSIVE lineage(run_id,ordinal,attempt_no) AS (
   SELECT run_key,step_no,attempt
   UNION
   SELECT p.parent_run,p.parent_ordinal,p.parent_attempt FROM lineage l
   JOIN run_working_parents p USING(run_id,ordinal,attempt_no)
 )
 SELECT DISTINCT d.ref,d.revision,cardinality(v.agent_scope)>0 FROM lineage l
 JOIN run_working_sets s USING(run_id,ordinal,attempt_no)
 JOIN run_working_inputs d USING(run_id,ordinal,attempt_no)
 JOIN runs r ON r.id=l.run_id
 JOIN rule_versions v ON (v.rule_id,v.revision)=(d.ref,d.revision)
 WHERE d.kind='rule' AND (s.invalidated_kind='rule' AND s.invalidated_ref=d.ref
   OR viewer IS NOT NULL AND NOT rule_usable(d.ref,d.revision,viewer)
   OR NOT EXISTS(SELECT FROM effective_run_rules x
        WHERE (x.run_id,x.ordinal,x.rule_id,x.rule_revision)=(l.run_id,l.ordinal,d.ref,d.revision) AND x.usable))
$$;


--
-- Name: invalidate_emergency_session(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_emergency_session() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM sessions WHERE member_id=NEW.id AND emergency;
  RETURN NEW;
END $$;


--
-- Name: invalidate_revoked_skill_working_sets(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_revoked_skill_working_sets() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE run_working_sets s SET invalidated_at=clock_timestamp()
 FROM run_working_inputs d
 WHERE (s.run_id,s.ordinal,s.attempt_no)=(d.run_id,d.ordinal,d.attempt_no)
   AND d.kind='skill' AND (d.ref,d.revision)=(NEW.skill_id,NEW.revision) AND s.invalidated_at IS NULL;
 RETURN NULL;
END $$;


--
-- Name: invalidate_rule_offer(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_rule_offer() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 WITH changes AS (
 UPDATE team_rules SET proposed_owner=NULL,proposed_by=NULL,transfer_reason=NULL,maintenance_version=maintenance_version+1
 WHERE proposed_owner IS NOT NULL AND (
  (NOT NEW.enabled AND NEW.id IN(proposed_by,proposed_owner)) OR
  (NEW.role<>'admin' AND proposed_by=NEW.id AND (maintenance_vacant OR maintainer<>NEW.id)) OR
  (NEW.enabled AND NOT OLD.enabled AND NOT maintenance_vacant AND maintainer=NEW.id AND proposed_by<>NEW.id)
 ) RETURNING id,maintenance_version)
 INSERT INTO audit_events(action,subject,detail) SELECT 'rule.maintenance.authority',id::text,
 jsonb_build_object('member',NEW.id,'version',maintenance_version) FROM changes;
 RETURN NEW;
END $$;


--
-- Name: invalidate_run_working_input(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_run_working_input() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE run_working_sets s SET invalidated_at=clock_timestamp(),invalidated_kind=TG_ARGV[0],invalidated_ref=NEW.id
    FROM run_working_inputs d
    WHERE (s.run_id,s.ordinal,s.attempt_no)=(d.run_id,d.ordinal,d.attempt_no)
      AND d.kind=TG_ARGV[0] AND d.ref=NEW.id AND s.invalidated_at IS NULL;
    RETURN NULL;
END $$;


--
-- Name: keep_skill_activation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.keep_skill_activation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.activation_terms IS DISTINCT FROM NEW.activation_terms THEN
   RAISE EXCEPTION 'Skill activation terms belong to an immutable revision';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: lock_artifact_preference_inputs(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.lock_artifact_preference_inputs(target uuid, edition integer) RETURNS void
    LANGUAGE sql
    AS $$
 SELECT FROM preferences f WHERE EXISTS(
   SELECT FROM working_artifact_origin(target,edition) o
   CROSS JOIN LATERAL working_preference_inputs(o.run_id,o.ordinal,o.attempt_no) pin WHERE pin.ref=f.id)
 ORDER BY f.id FOR SHARE OF f
$$;


--
-- Name: model_replacement_base_clear(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.model_replacement_base_clear(target uuid, base integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT NOT EXISTS (
   SELECT FROM agent_revisions r WHERE r.agent_id=target AND r.revision>base
   AND NOT EXISTS (SELECT FROM model_replacement_agents x WHERE
     (x.agent_id,x.draft)=(r.agent_id,r.revision) AND x.activated_at IS NOT NULL)
 )
$$;


--
-- Name: notify_account_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_account_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO account_notices(event_seq,member_id) VALUES(NEW.seq, NEW.subject::uuid);
    RETURN NEW;
END $$;


--
-- Name: offered_workflow_template_version(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.offered_workflow_template_version(template uuid, actor uuid) RETURNS integer
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE WHEN t.owner=actor THEN t.current_version ELSE t.published_version END
 FROM workflow_templates t JOIN team_members tm ON (tm.team_id,tm.member_id)=(t.team_id,actor)
 JOIN members m ON m.id=tm.member_id AND m.enabled
 WHERE t.id=template AND t.archived_at IS NULL
$$;


--
-- Name: pin_project_planner(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pin_project_planner() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 SELECT resource_id,resource_revision INTO NEW.planning_resource,NEW.planning_revision FROM planning_defaults WHERE team_id=NEW.team_id;
 RETURN NEW;
END $$;


--
-- Name: plan_workflow_build_usable(uuid, integer, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.plan_workflow_build_usable(project_key uuid, plan_version integer, agent_key uuid, version integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $_$
 SELECT NOT EXISTS(SELECT FROM plan_workflow_templates p
   WHERE (p.project_id,p.plan_version)=($1,$2)
     AND NOT workflow_build_usable(p.template_id,p.template_version,$3,$4))
$_$;


--
-- Name: planning_context_readable(uuid, uuid, jsonb, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.planning_context_readable(request_key uuid, viewer uuid, allowed_sources jsonb DEFAULT NULL::jsonb, current_rules boolean DEFAULT true) RETURNS boolean
    LANGUAGE sql STABLE
    AS $_$
 SELECT EXISTS(SELECT FROM planning_requests root JOIN project_members pm ON pm.project_id=root.project_id
               JOIN members m ON m.id=pm.member_id
               WHERE root.id=$1 AND m.id=$2 AND m.enabled)
 AND NOT EXISTS (
   SELECT FROM planning_context_requests($1) ancestor(id)
   JOIN planning_requests q ON q.id=ancestor.id
   WHERE (q.id<>$1 AND q.status<>'ready')
      OR ($4 AND q.rule_pins IS DISTINCT FROM planning_rule_pins(q.project_id,q.actor))
      OR NOT planning_rules_readable(q.rule_pins,$2)
      OR NOT planning_sources_readable(q.project_id,q.input_sources)
      OR ($3 IS NOT NULL AND NOT (coalesce(q.input_sources,'[]') <@ $3))
      OR EXISTS (
        SELECT FROM planning_context_messages c JOIN messages m ON m.seq=c.message_seq
        WHERE c.request_id=q.id AND
          (m.project_id<>q.project_id OR (c.recalled AND (m.kind<>'user' OR m.planning_request IS NOT NULL))
           OR (c.body_hash IS NOT NULL AND c.body_hash IS DISTINCT FROM
             digest(substring(convert_to(m.body,'UTF8') FROM c.body_start+1 FOR c.body_bytes),'sha256')))
      )
 )
$_$;


--
-- Name: planning_context_requests(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.planning_context_requests(request_key uuid) RETURNS SETOF uuid
    LANGUAGE sql STABLE
    AS $_$
 WITH RECURSIVE history(id) AS (
   SELECT $1
   UNION
   SELECT m.planning_request FROM history h
   JOIN planning_context_messages c ON c.request_id=h.id
   JOIN messages m ON m.seq=c.message_seq
   WHERE m.planning_request IS NOT NULL
 )
 SELECT id FROM history
$_$;


--
-- Name: planning_output_scope_valid(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.planning_output_scope_valid(scope text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
 SELECT scope = coalesce((
   SELECT string_agg(DISTINCT op, ',' ORDER BY op)
   FROM unnest(string_to_array(scope, ',')) AS op
   WHERE op IN ('docx','png','pptx','xlsx')
 ), '')
$$;


--
-- Name: planning_rule_pins(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.planning_rule_pins(project_key uuid, who uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE WHEN coalesce(bool_and(rule_usable(r.id,r.published_revision,who)),true)
 THEN coalesce(jsonb_agg(jsonb_build_object('id',r.id,'rev',r.published_revision) ORDER BY r.id),'[]')
 END FROM projects p JOIN team_rules r ON r.team_id=p.team_id
 JOIN rule_versions v ON (v.rule_id,v.revision)=(r.id,r.published_revision)
 WHERE p.id=project_key AND NOT r.disabled AND cardinality(v.agent_scope)=0
$$;


--
-- Name: planning_rules_readable(jsonb, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.planning_rules_readable(pins jsonb, who uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT NOT EXISTS(SELECT FROM jsonb_to_recordset(pins) x(id uuid, rev integer)
 WHERE NOT rule_usable(x.id,x.rev,who))
$$;


--
-- Name: planning_sources_readable(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.planning_sources_readable(project_key uuid, pins jsonb) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT NOT EXISTS (
   SELECT FROM jsonb_to_recordset(pins) x(id uuid, version integer)
   WHERE NOT EXISTS (
     SELECT FROM sources s JOIN source_versions v ON v.source_id=s.id
     WHERE s.project_id=project_key AND s.id=x.id AND v.version=x.version
       AND s.revoked_at IS NULL AND (v.extracted IS NOT NULL OR source_is_picture(v.media_type))
   )
 )
$$;


--
-- Name: project_agent_access(uuid, uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_agent_access(project uuid, target uuid, rev integer, actor uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM agents a JOIN members m ON m.id=actor AND m.enabled WHERE a.id=target AND
 (EXISTS(SELECT FROM team_members t WHERE t.team_id=a.team_id AND t.member_id=actor)
 OR EXISTS(SELECT FROM effective_project_agent_grants g JOIN project_members pm ON pm.project_id=g.project_id AND pm.member_id=actor
 WHERE (g.project_id,g.agent_id,g.revision)=(project,target,rev) AND m.kind='person')))
$$;


--
-- Name: project_agent_admissible(uuid, uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_agent_admissible(project uuid, target uuid, rev integer, actor uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT agent_revision_ready(target,rev) AND agent_skills_usable(target,rev,actor)
 AND (project_agent_access(NULL,target,rev,actor) OR
 (project_agent_access(project,target,rev,actor) AND EXISTS(SELECT FROM effective_project_agent_grants g
 WHERE (g.project_id,g.agent_id,g.revision)=(project,target,rev) AND g.call_limit>(SELECT count(*) FROM project_agent_calls WHERE grant_id=g.id))))
$$;


--
-- Name: project_delivery_coverage(uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_delivery_coverage(target uuid, version integer, viewer uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $_$
  SELECT jsonb_build_object('planVersion',c.plan_version,'allowPartial',c.allow_partial,
    'items',ARRAY(
      SELECT jsonb_strip_nulls(jsonb_build_object('item',q.item,'step',q.ordinal,'label',q.label,
        'run',run.id,'artifact',a.id,'version',a.current_version,'state',coalesce(v.state,'unchecked'),
        'reason',case when access.allowed then v.reason end,'responsible',v.responsible,'responsibleName',owner.display_name,
        'responsibleActive',owner.id IS NOT NULL AND EXISTS(
           SELECT FROM project_members pm WHERE (pm.project_id,pm.member_id)=(q.project_id,v.responsible)
             AND pm.recovery_assignment IS NULL),
        'continueWhen',case when access.allowed then v.continue_when end,'reviewer',v.reviewer,'reviewedAt',v.reviewed_at,
        'fileEvidenceAvailable',case when reviewer.allowed and access.allowed and
          f.filename ~* '\.(docx|xlsx|pptx|pdf)$' then true end,
        'fileEvidence',case when reviewer.allowed and access.allowed and
          (v.file_evidence->>'hash',v.file_evidence->>'name')=(f.object_hash,f.filename)
          then v.file_evidence-'hash' end,
        'remoteEvidence',remote.receipt,
        'remoteEvidenceRecorded',case when remote.receipt is not null and v.remote_receipt_version=remote.version then true end,
        'upstreamEvidenceReady',case when reviewer.allowed and access.allowed and upstream.run_id is not null
          then run_working_set_usable(upstream.run_id,upstream.ordinal,upstream.attempt_no) end,
        'upstreamEvidenceStep',case when reviewer.allowed and access.allowed and upstream.run_id is not null
          and run_working_set_usable(upstream.run_id,upstream.ordinal,upstream.attempt_no)
          then v.upstream_evidence_step end))
      FROM plan_delivery_requirements q
      LEFT JOIN LATERAL (
        SELECT r.id FROM runs r WHERE (r.project_id,r.plan_version)=(q.project_id,q.plan_version)
          AND NOT EXISTS(SELECT FROM change_batches b WHERE b.run_id=r.id)
        ORDER BY r.created_at DESC,r.id DESC LIMIT 1
      ) run ON true
      LEFT JOIN run_candidate_artifacts a ON (a.run_id,a.ordinal)=(run.id,q.ordinal)
      LEFT JOIN visible_artifact_remote_receipts(c.project_id,viewer) remote
        ON (remote.artifact_id,remote.version)=(a.id,a.current_version)
      LEFT JOIN LATERAL artifact_upstream_origin(a.id,a.current_version) upstream ON reviewer.allowed
      LEFT JOIN artifact_files f ON (f.artifact_id,f.version)=(a.id,a.current_version)
      CROSS JOIN LATERAL (SELECT viewer IS NULL OR a.id IS NULL OR distribution_readable(a.id,a.current_version,viewer) AS allowed) access
      LEFT JOIN LATERAL (
        SELECT v.* FROM delivery_item_assessments v
        WHERE (v.project_id,v.plan_version,v.item)=(q.project_id,q.plan_version,q.item)
        ORDER BY v.id DESC LIMIT 1
      ) v ON ((v.run_id=run.id OR EXISTS (
            SELECT FROM rule_branch_steps b JOIN branch_rebuild_ancestors history ON history.run_id=b.run_id
            WHERE (b.run_id,b.ordinal,b.mode,b.artifact_id,b.result_version)=(run.id,q.ordinal,'reuse',a.id,a.current_version)
            AND history.source_run=v.run_id))
        AND (v.artifact_id,v.artifact_version) IS NOT DISTINCT FROM (a.id,a.current_version)
        AND EXISTS(SELECT FROM project_members pm JOIN members rm ON rm.id=pm.member_id AND rm.enabled
          WHERE (pm.project_id,pm.member_id)=(q.project_id,v.reviewer) AND pm.can_review))
      LEFT JOIN members owner ON owner.id=v.responsible AND owner.enabled AND owner.kind='person'
      WHERE (q.project_id,q.plan_version)=(c.project_id,c.plan_version)
      ORDER BY q.item))
  FROM plan_delivery_contracts c
  CROSS JOIN LATERAL (SELECT viewer IS NOT NULL AND EXISTS(
    SELECT FROM project_members pm JOIN members u ON u.id=pm.member_id AND u.enabled AND u.departed_at IS NULL
    WHERE (pm.project_id,pm.member_id)=(c.project_id,viewer) AND pm.can_review) AS allowed) reviewer
  WHERE (c.project_id,c.plan_version)=(target,version)
$_$;


--
-- Name: project_delivery_mode(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_delivery_mode(coverage jsonb) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT CASE WHEN unchecked>0 THEN 'coverage' WHEN missing=0 THEN 'full'
    WHEN covered>0 AND assigned=missing AND coverage->>'allowPartial'='true' THEN 'partial'
    ELSE 'coverage' END
  FROM (SELECT count(*) FILTER(WHERE item->>'state'='unchecked') unchecked,
    count(*) FILTER(WHERE item->>'state'='covered') covered,
    count(*) FILTER(WHERE item->>'state'='missing') missing,
    count(*) FILTER(WHERE item->>'state'='missing' AND item->>'responsibleActive'='true'
      AND coalesce(item->>'continueWhen','')<>'') assigned
    FROM jsonb_array_elements(coverage->'items') item) stats
$$;


--
-- Name: project_review_requirement_evidence(uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_review_requirement_evidence(target uuid, revision integer, viewer uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    SET jit TO 'off'
    AS $$
 WITH coverage AS MATERIALIZED (
   SELECT project_delivery_coverage(target,revision,viewer) AS value
 ), evidence AS MATERIALIZED (
   SELECT * FROM visible_artifact_requirement_evidence(target,viewer)
 ), items AS (
   SELECT item, item_order, CASE
     WHEN finding->>'gap' IS NOT NULL THEN jsonb_build_object('gap',finding->>'gap')
     WHEN refs.quotes IS NOT NULL AND refs.count=jsonb_array_length(finding->'citations')
       THEN jsonb_build_object('citations',refs.quotes)
     END AS hint
   FROM coverage CROSS JOIN LATERAL jsonb_array_elements(value->'items') WITH ORDINALITY AS q(item,item_order)
   LEFT JOIN evidence e ON (e.artifact_id,e.version)=((item->>'artifact')::uuid,(item->>'version')::integer)
   LEFT JOIN LATERAL (SELECT f AS finding FROM jsonb_array_elements(e.findings) f WHERE f->'item'=item->'item') matched ON true
   LEFT JOIN LATERAL (
     SELECT count(*) AS count, jsonb_agg(jsonb_build_object(
       'name',coalesce(v.filename,s.name),'version',v.version,'start',c.start+1,'end',c."end",'text',span.text
     ) ORDER BY c.seq) AS quotes
     FROM ROWS FROM (jsonb_to_recordset(finding->'citations')
       AS (source uuid,version integer,start integer,"end" integer,digest text,receipt integer))
       WITH ORDINALITY AS c(source,version,start,"end",digest,receipt,seq)
     JOIN sources s ON (s.id,s.project_id)=(c.source,target) AND s.revoked_at IS NULL
     JOIN source_versions v ON (v.source_id,v.version)=(c.source,c.version)
     JOIN run_working_inputs input ON (input.run_id,input.ordinal,input.attempt_no,input.kind,input.ref,input.revision)=
       (e.run_id,e.ordinal,e.attempt_no,'source',c.source,c.version)
     CROSS JOIN LATERAL (SELECT substring(v.extracted FROM c.start+1 FOR greatest(c."end"-c.start,0)) AS text) span
     WHERE c.start>=0 AND c."end">c.start AND c."end"<=char_length(v.extracted)
       AND c."end"-c.start<=320 AND encode(digest(convert_to(span.text,'UTF8'),'sha256'),'hex')=c.digest
       AND (EXISTS(
         SELECT FROM run_source_inputs pin JOIN runs r ON r.id=pin.run_id
         JOIN plan_sources p ON (p.project_id,p.plan_version,p.source_id)=(r.project_id,r.plan_version,pin.source_id)
         WHERE (pin.run_id,pin.source_id,pin.version)=(e.run_id,c.source,c.version) AND pin.extracted IS NOT NULL
         AND ((c.receipt=0 AND p.receipt_step IS NULL) OR
              (c.receipt=e.ordinal AND p.receipt_step=c.receipt AND c.start>=p.excerpt_start AND c."end"<=p.excerpt_end))
       ) OR (c.receipt=e.ordinal AND EXISTS(
         SELECT FROM step_source_receipt_inputs p
         WHERE (p.run_id,p.reader,p.source_id,p.source_version)=(e.run_id,c.receipt,c.source,c.version)
           AND c.start>=p.excerpt_start AND c."end"<=p.excerpt_end)))
   ) refs ON finding IS NOT NULL
 )
 SELECT CASE WHEN value IS NOT NULL THEN jsonb_set(value,'{items}',coalesce((
   SELECT jsonb_agg(CASE WHEN hint IS NULL THEN item ELSE item||jsonb_build_object('evidence',hint) END ORDER BY item_order)
   FROM items
 ),'[]'::jsonb)) END FROM coverage
$$;


--
-- Name: project_upstream_review_scope(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.project_upstream_review_scope(target uuid, viewer uuid) RETURNS text
    LANGUAGE sql STABLE
    SET jit TO 'off'
    AS $$
 SELECT string_agg(a.id::text||'/'||a.current_version||'/'||
   run_working_set_usable(c.run_id,c.ordinal,c.attempt_no)::text,',' ORDER BY a.id)
 FROM project_members pm JOIN artifacts a ON a.project_id=pm.project_id
 JOIN LATERAL artifact_upstream_origin(a.id,a.current_version) c ON true
 WHERE (pm.project_id,pm.member_id)=(target,viewer) AND pm.can_review
   AND distribution_readable(a.id,a.current_version,viewer)
$$;


--
-- Name: publish_project_session_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.publish_project_session_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    pid uuid;
    rid uuid;
    fragment bigint;
    next_seq bigint;
    change_tx bigint;
BEGIN
    CASE TG_TABLE_NAME
        WHEN 'projects' THEN pid := NEW.id;
        WHEN 'messages' THEN pid := NEW.project_id;
        WHEN 'runs' THEN pid := NEW.project_id;
        ELSE
            SELECT project_id INTO pid FROM runs WHERE id=NEW.run_id;
            IF TG_TABLE_NAME='run_draft_fragments' THEN
                rid := NEW.run_id;
                fragment := NEW.seq;
            END IF;
    END CASE;
    IF pid IS NULL THEN RETURN NULL; END IF;
    IF fragment IS NULL THEN change_tx := txid_current(); END IF;
    INSERT INTO project_session_heads AS h(project_id,seq,last_change_tx) VALUES(pid,1,change_tx)
    ON CONFLICT(project_id) DO UPDATE
        SET seq=h.seq+1,last_change_tx=coalesce(change_tx,h.last_change_tx)
        WHERE change_tx IS NULL OR h.last_change_tx IS DISTINCT FROM change_tx
    RETURNING seq INTO next_seq;
    IF next_seq IS NOT NULL THEN
        INSERT INTO project_session_events(project_id,seq,run_id,draft_seq) VALUES(pid,next_seq,rid,fragment);
    END IF;
    RETURN NULL;
END $$;


--
-- Name: publish_reviewer_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.publish_reviewer_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid uuid; step integer;
BEGIN
 IF TG_TABLE_NAME='projects' THEN
  FOR rid IN SELECT id FROM runs WHERE project_id=NEW.id AND app_id IS NOT NULL LOOP
   PERFORM record_service_event(rid,'project','reviewer_changed');
  END LOOP;
 ELSE
  SELECT run_id,ordinal INTO rid,step FROM artifacts WHERE id=NEW.artifact_id;
  PERFORM record_service_event(rid,'artifact','takeover_reviewed',step,NEW.artifact_id,NEW.version);
 END IF;
 RETURN NULL;
END $$;


--
-- Name: purge_correction_headers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.purge_correction_headers() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE target jsonb := jsonb_build_array(jsonb_build_object('source',NEW.id::text));
BEGIN
 UPDATE invocations SET input_issue=NULL WHERE input_issue->>'source'=NEW.id::text;
 UPDATE invocations SET input_issue=NULL WHERE jsonb_typeof(input_issue)='array' AND input_issue @> target;
 UPDATE call_reviews SET input_mapping=input_mapping-'columns' WHERE input_mapping->>'source'=NEW.id::text;
 UPDATE call_reviews v SET input_mapping=(
   SELECT jsonb_agg(CASE WHEN q.mapping->>'source'=NEW.id::text THEN q.mapping-'columns' ELSE q.mapping END ORDER BY q.n)
   FROM column_correction_items(v.input_mapping) WITH ORDINALITY AS q(mapping,n))
 WHERE jsonb_typeof(v.input_mapping)='array' AND v.input_mapping @> target;
 RETURN NULL;
END $$;


--
-- Name: purge_due_preferences(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.purge_due_preferences() RETURNS void
    LANGUAGE sql
    AS $$
 WITH cleared AS (
   UPDATE preferences SET body=NULL,purged_at=now(),enabled=false,revision=revision+1,lifecycle_revision=lifecycle_revision+1
   WHERE purged_at IS NULL AND least(deleted_at,expires_at)<=now()-interval '30 days'
   RETURNING id,revision
 )
 INSERT INTO audit_events(action,subject,detail)
 SELECT 'preference.purge',id::text,jsonb_build_object('revision',revision) FROM cleared
$$;


--
-- Name: purge_source_content(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.purge_source_content(target uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT FROM sources WHERE id=target AND recycled_at IS NOT NULL AND purged_at IS NULL FOR UPDATE) THEN RETURN; END IF;
 INSERT INTO source_object_cleanup SELECT DISTINCT target,object_hash FROM source_versions
 WHERE source_id=target AND object_hash IS NOT NULL ON CONFLICT DO NOTHING;
 UPDATE source_versions SET object_hash=NULL,extracted=NULL,embedding=NULL,filename=NULL WHERE source_id=target;
 UPDATE sources SET name='已清除资料',purged_at=clock_timestamp() WHERE id=target;
END $$;


--
-- Name: readable_run_skills(uuid, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.readable_run_skills(run_key uuid, step_no integer, attempt integer) RETURNS jsonb
    LANGUAGE sql STABLE STRICT
    AS $$
 SELECT CASE WHEN run_working_set_usable(run_key,step_no,attempt) THEN (
    SELECT jsonb_agg(jsonb_build_object('name',p.name,'revision',d.revision) ORDER BY p.name,d.ref)
    FROM run_working_inputs d JOIN skill_packs p ON p.id=d.ref
    WHERE (d.run_id,d.ordinal,d.attempt_no)=(run_key,step_no,attempt) AND d.kind='skill'
 ) END
$$;


--
-- Name: rebuild_source_passages(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rebuild_source_passages(target uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
 DELETE FROM source_passages WHERE source_id=target;
 INSERT INTO source_passages(source_id,version,start_char,passage)
 SELECT target,version,position::integer,part FROM (
  SELECT v.version,parts.m[1] AS part,1+coalesce(sum(char_length(parts.m[1])) OVER
   (ORDER BY parts.ordinal ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) AS position
  FROM sources s JOIN source_versions v ON (v.source_id,v.version)=(s.id,s.current_version)
  CROSS JOIN LATERAL regexp_matches(v.extracted,'[^。！？!?；;\r\n]{1,180}|[。！？!?；;\r\n]+','g') WITH ORDINALITY AS parts(m,ordinal)
  WHERE s.id=target AND s.revoked_at IS NULL
 ) segments WHERE part ~ '[^[:space:]。！？!?；;]';
END $$;


--
-- Name: record_service_event(uuid, text, text, integer, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_service_event(rid uuid, category text, val text, step integer DEFAULT NULL::integer, item uuid DEFAULT NULL::uuid, ver integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE cursor_id bigint;
BEGIN
 IF NOT EXISTS(SELECT FROM runs WHERE id=rid AND app_id IS NOT NULL) THEN RETURN; END IF;
 INSERT INTO service_event_heads VALUES(rid,1) ON CONFLICT(run_id) DO UPDATE SET seq=service_event_heads.seq+1 RETURNING seq INTO cursor_id;
 INSERT INTO service_events(run_id,seq,kind,state,ordinal,artifact_id,version) VALUES(rid,cursor_id,category,val,step,item,ver);
END $$;


--
-- Name: register_resource_budget(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.register_resource_budget() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_TABLE_NAME='model_resources' THEN
  INSERT INTO resource_budgets(team_id,kind,model_id) VALUES(NEW.team_id,'model',NEW.id);
 ELSIF NEW.tool IS NOT NULL OR NEW.card IS NOT NULL THEN
  INSERT INTO resource_budgets(team_id,kind,agent_id)
   SELECT team_id,CASE WHEN NEW.tool IS NOT NULL THEN 'tool' ELSE 'external' END,NEW.agent_id FROM agents WHERE id=NEW.agent_id
   ON CONFLICT(agent_id,kind) DO NOTHING;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: remote_input_window_open(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.remote_input_window_open(run_status text, job_phase text, job_detail text) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
 SELECT job_phase='manual' AND CASE WHEN job_detail='remote_step_input'
 THEN run_status='running' ELSE run_status='reconcile' END
$$;


--
-- Name: remote_operation_availability(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.remote_operation_availability(proof jsonb) RETURNS jsonb
    LANGUAGE sql STABLE STRICT
    AS $$
  SELECT jsonb_build_object('send',remote_operation_live(proof,'send')
    OR remote_operation_live(proof,'directText') OR remote_operation_live(proof,'asyncText')
    OR remote_operation_live(proof,'supplementText'),
    'directText',remote_operation_live(proof,'directText'),'query',remote_operation_live(proof,'query'),
    'asyncText',remote_operation_live(proof,'asyncText'),'cancel',remote_operation_live(proof,'cancel'),
    'supplement',remote_operation_live(proof,'supplement'),'supplementText',remote_operation_live(proof,'supplementText'))
$$;


--
-- Name: remote_operation_live(jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.remote_operation_live(proof jsonb, operation_key text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  SELECT EXISTS(SELECT FROM remote_trial_observations o WHERE o.id=(proof->>operation_key)::bigint
    AND NOT EXISTS(SELECT FROM validation_withdrawals w WHERE w.trial_id=o.trial_id))
$$;


--
-- Name: remote_operation_ready(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.remote_operation_ready(proof jsonb) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  SELECT proof IS NULL OR remote_operation_live(proof,'directText')
    OR (remote_operation_live(proof,'query') AND remote_operation_live(proof,'asyncText'))
    OR (remote_operation_live(proof,'supplement') AND remote_operation_live(proof,'supplementText'))
$$;


--
-- Name: remote_step_input_parked(uuid, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.remote_step_input_parked(run_key uuid, step integer, job_phase text, job_detail text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $_$
 SELECT coalesce(job_phase='manual' AND job_detail='remote_step_input',false)
 AND NOT EXISTS(SELECT FROM remote_task_inputs q WHERE (q.run_id,q.ordinal)=($1,$2) AND q.state='submitted')
$_$;


--
-- Name: remove_departed_oidc(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.remove_departed_oidc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM oidc_bindings WHERE member_id=NEW.id;
    RETURN NEW;
END $$;


--
-- Name: require_charge_resource(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_charge_resource() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.resource_budget IS NULL OR NEW.source_revision IS NULL OR NEW.source_name IS NULL THEN RAISE EXCEPTION 'missing charge resource'; END IF;
 RETURN NEW;
END $$;


--
-- Name: require_review_preference_inputs(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_review_preference_inputs() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM lock_artifact_preference_inputs(NEW.artifact_id,NEW.version);
 IF artifact_draft_block_reason(NEW.artifact_id,NEW.version)='preference' THEN
   RAISE EXCEPTION 'review_candidate_preference_unavailable' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: require_scoped_preference_worker(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_scoped_preference_worker() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.status='submitted' AND current_setting('alliance.scoped_preference_worker',true) IS DISTINCT FROM 'true'
       AND EXISTS (SELECT FROM runs r JOIN plan_scoped_preferences p
                   ON (p.project_id,p.plan_version)=(r.project_id,r.plan_version) WHERE r.id=NEW.run_id) THEN
        RAISE EXCEPTION 'scoped preferences require an updated Worker';
    END IF;
    RETURN NEW;
END $$;


--
-- Name: require_service_run_delivery_contract(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_service_run_delivery_contract() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF EXISTS(SELECT FROM service_delivery_requirements WHERE (service_id,version)=(NEW.service_id,NEW.service_version))
       AND (
        NOT EXISTS(
            SELECT FROM plan_delivery_contracts c JOIN service_versions v
            ON (v.service_id,v.version)=(NEW.service_id,NEW.service_version)
            WHERE (c.project_id,c.plan_version)=(NEW.project_id,NEW.plan_version)
                AND (NOT c.allow_partial OR v.allows_partial_delivery))
        OR EXISTS(
            SELECT item,ordinal,label FROM service_delivery_requirements WHERE (service_id,version)=(NEW.service_id,NEW.service_version)
            EXCEPT
            SELECT item,ordinal,label FROM plan_delivery_requirements WHERE (project_id,plan_version)=(NEW.project_id,NEW.plan_version))
        OR EXISTS(
            SELECT item,ordinal,label FROM plan_delivery_requirements WHERE (project_id,plan_version)=(NEW.project_id,NEW.plan_version)
            EXCEPT
            SELECT item,ordinal,label FROM service_delivery_requirements WHERE (service_id,version)=(NEW.service_id,NEW.service_version))
       )
    THEN
        RAISE EXCEPTION 'service_delivery_contract_mismatch' USING ERRCODE='23514', CONSTRAINT='run_service_delivery_contract';
    END IF;
    RETURN NEW;
END $$;


--
-- Name: require_step_dispatch_worker(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_step_dispatch_worker() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.status='submitted' AND EXISTS(SELECT FROM runs WHERE id=NEW.run_id AND step_dispatch_wait)
   AND (current_setting('alliance.step_dispatch_worker',true) IS DISTINCT FROM 'true'
      OR EXISTS(SELECT FROM step_dispatch_waits w WHERE (w.run_id,w.ordinal)=(NEW.run_id,NEW.ordinal)))
 THEN
   RAISE EXCEPTION 'step dispatch requires an updated Worker and a cleared wait';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: require_text_agent_choice_worker(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.require_text_agent_choice_worker() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.status='submitted' AND current_setting('alliance.text_agent_choice_worker',true) IS DISTINCT FROM 'true'
   AND EXISTS(
     SELECT FROM runs r JOIN plan_tool_choices route
       ON (route.project_id,route.plan_version)=(r.project_id,r.plan_version)
     JOIN nodes n ON (n.project_id,n.plan_version,n.ordinal)=(route.project_id,route.plan_version,route.ordinal)
     JOIN agent_revisions a ON (a.agent_id,a.revision)=(n.agent_id,n.agent_revision)
     WHERE r.id=NEW.run_id AND NEW.ordinal IN (route.selector,route.ordinal)
       AND agent_choice_profile(a)='text'
   ) THEN
   RAISE EXCEPTION 'text Agent choice requires an updated Worker';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: retire_invalid_working_payloads(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.retire_invalid_working_payloads(batch_size integer) RETURNS bigint
    LANGUAGE sql
    AS $$
 WITH payload_attempts AS (
   SELECT run_id,ordinal,attempt_no FROM text_reply_checkpoints WHERE state='pending'
   UNION
   SELECT run_id,parent,parent_attempt FROM lookup_question_handoffs WHERE question IS NOT NULL
   UNION
   SELECT run_id,ordinal,attempt_no FROM run_draft_fragments
   UNION
   SELECT run_id,ordinal,attempt_no FROM lookup_turns
   WHERE decision IS NOT NULL OR refinement_evidence IS NOT NULL OR initial_evidence IS NOT NULL
   UNION
   SELECT i.run_id,i.ordinal,i.attempt_no FROM invocations i
   WHERE i.status='completed' AND i.result IS NOT NULL
     AND NOT EXISTS(SELECT FROM artifacts a WHERE (a.run_id,a.ordinal)=(i.run_id,i.ordinal))
     AND NOT EXISTS(SELECT FROM change_batches c WHERE c.run_id=i.run_id AND c.applied_version IS NOT NULL)
 ), attempts AS MATERIALIZED (
   SELECT s.run_id,s.ordinal,s.attempt_no FROM payload_attempts p
   JOIN run_working_sets s USING(run_id,ordinal,attempt_no)
   JOIN runs r ON r.id=s.run_id
   WHERE NOT run_working_set_usable(s.run_id,s.ordinal,s.attempt_no)
   ORDER BY s.run_id,s.ordinal,s.attempt_no
   LIMIT batch_size FOR NO KEY UPDATE OF r SKIP LOCKED
 ), drafts AS (
   DELETE FROM run_draft_fragments f USING attempts a
   WHERE (f.run_id,f.ordinal,f.attempt_no)=(a.run_id,a.ordinal,a.attempt_no)
 ), replies AS (
   UPDATE text_reply_checkpoints c SET state='discarded',payload=NULL FROM attempts a
   WHERE (c.run_id,c.ordinal,c.attempt_no)=(a.run_id,a.ordinal,a.attempt_no) AND c.state='pending'
 ), questions AS (
   UPDATE lookup_question_handoffs q SET question=NULL FROM attempts a
   WHERE (q.run_id,q.parent,q.parent_attempt)=(a.run_id,a.ordinal,a.attempt_no) AND q.question IS NOT NULL
 ), turns AS (
   -- Ending the decision also discards its pending local observations.
   UPDATE lookup_turns t SET decision=NULL,refinement_evidence=NULL,initial_evidence=NULL,
     outcome=CASE WHEN t.decision IS NOT NULL THEN 'invalidated' ELSE t.outcome END
   FROM attempts a WHERE (t.run_id,t.ordinal,t.attempt_no)=(a.run_id,a.ordinal,a.attempt_no)
     AND (t.decision IS NOT NULL OR t.refinement_evidence IS NOT NULL OR t.initial_evidence IS NOT NULL)
 ), results AS (
   UPDATE invocations i SET result=NULL FROM attempts a
   WHERE (i.run_id,i.ordinal,i.attempt_no)=(a.run_id,a.ordinal,a.attempt_no)
     AND i.status='completed' AND i.result IS NOT NULL
     AND NOT EXISTS(SELECT FROM artifacts a WHERE (a.run_id,a.ordinal)=(i.run_id,i.ordinal))
     AND NOT EXISTS(SELECT FROM change_batches c WHERE c.run_id=i.run_id AND c.applied_version IS NOT NULL)
 )
 SELECT count(*) FROM attempts
$$;


--
-- Name: retire_review_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.retire_review_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE review_notifications SET status='obsolete' WHERE binding=OLD.binding_id AND status IN('pending','failed');
 RETURN OLD;
END $$;


--
-- Name: rule_owner_changed(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rule_owner_changed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 NEW.lifecycle=OLD.lifecycle+1;
 RETURN NEW;
END $$;


--
-- Name: rule_usable(uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rule_usable(rule_key uuid, rev integer, actor uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM team_rules r
 JOIN rule_versions v ON (v.rule_id,v.revision)=(r.id,rev)
 JOIN team_members tm ON tm.team_id=r.team_id AND tm.member_id=actor
 JOIN members m ON m.id=tm.member_id AND m.enabled
 WHERE r.id=rule_key AND NOT r.disabled AND v.review_at IS NOT NULL
 AND (v.expires_at IS NULL OR v.expires_at>statement_timestamp()))
$$;


--
-- Name: run_failure_confirmable(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_failure_confirmable(target uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    SELECT EXISTS (SELECT FROM runs WHERE id=target AND status IN ('running','blocked','reconcile','paused'))
       AND (EXISTS (SELECT FROM invocations WHERE run_id=target AND status='input_rejected')
            OR EXISTS (SELECT FROM invocations i JOIN remote_jobs j USING(run_id,ordinal)
            WHERE i.run_id=target AND i.status='remote_closed' AND i.remote_status IN ('failed','rejected')
              AND j.phase='finished' AND j.detail IN ('remote_failed','remote_rejected')))
       AND NOT EXISTS (SELECT FROM invocations WHERE run_id=target AND status NOT IN ('completed','remote_closed','input_rejected'))
       AND NOT EXISTS (SELECT FROM remote_jobs WHERE run_id=target AND phase<>'finished')
       AND NOT EXISTS (
            SELECT FROM superseded_calls s JOIN call_reviews v ON v.control_id=s.review_control WHERE s.run_id=target AND v.input_mapping IS NULL AND NOT EXISTS (
                SELECT FROM late_call_receipts l
                WHERE (l.run_id,l.ordinal,l.attempt_no)=(s.run_id,s.ordinal,s.attempt_no)
                  AND (l.outcome IN ('completed','input_rejected') OR (l.outcome='remote'
                       AND l.remote_state IN ('completed','failed','canceled','rejected')))
            )
       )
$$;


--
-- Name: run_memory_can_use_personal(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_memory_can_use_personal(run_key uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM runs r JOIN members u ON u.id=r.actor
 WHERE r.id=run_key AND u.kind='person' AND u.enabled AND u.departed_at IS NULL
   AND (r.app_id IS NULL OR EXISTS(
       SELECT FROM delegations d JOIN applications a ON a.id=d.app_id
       JOIN members app ON app.id=a.id AND app.enabled
       WHERE d.id=r.delegated_by AND d.app_id=r.app_id AND d.member_id=r.actor
         AND a.revoked_at IS NULL AND a.expires_at>statement_timestamp()
         AND d.revoked_at IS NULL AND d.expires_at>statement_timestamp()
   )))
$$;


--
-- Name: run_preference_pin_usable(uuid, uuid, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_preference_pin_usable(run_key uuid, build uuid, ref uuid, ref_revision integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT run_memory_can_use_personal(run_key) AND EXISTS(
   SELECT FROM runs r JOIN plan_bound_preferences p ON (p.project_id,p.plan_version)=(r.project_id,r.plan_version)
   JOIN preferences f ON (f.id,f.revision)=(p.preference_id,p.revision)
   WHERE (r.id,p.preference_id,p.revision)=(run_key,ref,ref_revision)
     AND p.agent_scope IS NOT DISTINCT FROM f.agent_scope AND (p.agent_scope IS NULL OR p.agent_scope=build)
     AND f.member_id=r.actor AND f.enabled AND f.deleted_at IS NULL AND NOT f.departure_guard
     AND f.body IS NOT NULL AND f.expires_at>statement_timestamp())
$$;


--
-- Name: run_review_notes_readable(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_review_notes_readable(target_run uuid, viewer uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS (
   SELECT FROM runs r JOIN projects p ON p.id=r.project_id
   JOIN project_members m ON m.project_id=p.id AND m.member_id=viewer
   JOIN members u ON u.id=m.member_id AND u.enabled
   WHERE r.id=target_run AND (m.can_review OR p.owner=viewer OR NOT EXISTS (
     SELECT FROM plan_sources ps JOIN sources s ON s.id=ps.source_id
     WHERE (ps.project_id,ps.plan_version)=(r.project_id,r.plan_version)
     AND s.revoked_at IS NOT NULL AND s.created_by<>viewer
   ))
 )
$$;


--
-- Name: run_working_set_usable(uuid, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_working_set_usable(run_key uuid, step_no integer, attempt integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 WITH RECURSIVE lineage(run_id,ordinal,attempt_no,invalidated_at) AS (
   SELECT s.run_id,s.ordinal,s.attempt_no,s.invalidated_at FROM run_working_sets s
   WHERE (s.run_id,s.ordinal,s.attempt_no)=(run_key,step_no,attempt)
   UNION
   SELECT origin.run_id,origin.ordinal,origin.attempt_no,origin.invalidated_at FROM lineage l
   JOIN run_working_parents p ON(p.run_id,p.ordinal,p.attempt_no)=(l.run_id,l.ordinal,l.attempt_no)
   JOIN run_working_sets origin ON(origin.run_id,origin.ordinal,origin.attempt_no)=(p.parent_run,p.parent_ordinal,p.parent_attempt)
 )
 SELECT NOT EXISTS(
   SELECT FROM lineage l JOIN runs r ON r.id=l.run_id
   JOIN run_working_sets s USING(run_id,ordinal,attempt_no)
   WHERE l.invalidated_at IS NOT NULL OR (s.build_digest IS NOT NULL AND s.build_digest IS DISTINCT FROM
     agent_build_digest(agent_build_definition(s.build_agent,s.build_revision))) OR NOT EXISTS(
     SELECT FROM project_members pm JOIN members u ON u.id=pm.member_id AND u.enabled
     WHERE (pm.project_id,pm.member_id)=(r.project_id,r.actor))
   OR EXISTS(
     SELECT FROM run_working_inputs d WHERE(d.run_id,d.ordinal,d.attempt_no)=(l.run_id,l.ordinal,l.attempt_no)
     AND CASE d.kind
       WHEN 'source' THEN NOT EXISTS(
         SELECT FROM run_source_inputs f WHERE f.run_id=l.run_id AND f.source_id=d.ref AND f.version=d.revision
           AND (f.extracted IS NOT NULL OR f.picture_hash IS NOT NULL)
         UNION ALL
         SELECT FROM step_source_receipt_inputs f
         JOIN sources source ON (source.id,source.project_id)=(f.source_id,r.project_id)
         JOIN source_versions v ON (v.source_id,v.version)=(f.source_id,f.source_version)
         WHERE (f.run_id,f.reader,f.source_id,f.source_version)=(l.run_id,l.ordinal,d.ref,d.revision)
           AND source.revoked_at IS NULL AND v.extracted IS NOT NULL)
       WHEN 'rule' THEN NOT EXISTS(
         SELECT FROM effective_run_rules x
         WHERE (x.run_id,x.ordinal,x.rule_id,x.rule_revision)=(l.run_id,l.ordinal,d.ref,d.revision) AND x.usable)
       WHEN 'skill' THEN NOT EXISTS(
         SELECT FROM skill_revisions v JOIN skill_packs p ON p.id=v.skill_id
         JOIN team_members m ON (m.team_id,m.member_id)=(p.team_id,r.actor)
         WHERE (v.skill_id,v.revision)=(d.ref,d.revision) AND v.revoked_at IS NULL
       )
       WHEN 'preference' THEN NOT run_preference_pin_usable(l.run_id,s.build_agent,d.ref,d.revision)
     END
   )
 )
$$;


--
-- Name: service_delivery_contract(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.service_delivery_contract(target uuid, edition integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
    SELECT jsonb_build_object('allowsPartial',v.allows_partial_delivery,'items',ARRAY(
        SELECT jsonb_build_object('item',q.item,'step',q.ordinal,'label',q.label)
        FROM service_delivery_requirements q
        WHERE (q.service_id,q.version)=(v.service_id,v.version)
        ORDER BY q.item))
    FROM service_versions v
    WHERE (v.service_id,v.version)=(target,edition)
$$;


--
-- Name: service_requires_csv_choice(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.service_requires_csv_choice(service uuid, rev integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(
  SELECT FROM service_tool_choices c
  JOIN service_nodes n ON (n.service_id,n.version,n.ordinal)=(c.service_id,c.version,c.ordinal)
  JOIN agent_revisions a ON (a.agent_id,a.revision)=(n.agent_id,n.agent_revision)
  WHERE (c.service_id,c.version)=(service,rev) AND a.tool->>'operation'='aggregate'
 )
$$;


--
-- Name: source_check_needed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.source_check_needed(target uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM changed_artifact_sources WHERE artifact_id=target AND decision IS DISTINCT FROM 'retain')
$$;


--
-- Name: source_is_picture(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.source_is_picture(media text) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
 SELECT coalesce(media IN ('image/png','image/jpeg'),false)
$$;


--
-- Name: source_passages_after_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.source_passages_after_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM rebuild_source_passages(NEW.id);
 RETURN NULL;
END $$;


--
-- Name: source_passages_after_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.source_passages_after_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF EXISTS(SELECT FROM sources WHERE id=NEW.source_id AND current_version=NEW.version) THEN
  PERFORM rebuild_source_passages(NEW.source_id);
 END IF;
 RETURN NULL;
END $$;


--
-- Name: source_receipt_open(text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.source_receipt_open(state text, request_revision integer) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
 SELECT CASE WHEN request_revision IS NULL THEN state='blocked' ELSE state='running' END
$$;


--
-- Name: supersede_agent_release_requests(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.supersede_agent_release_requests() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE agent_release_requests SET state='superseded',decider=NEW.created_by,decided_at=now()
 WHERE agent_id=NEW.agent_id AND revision<NEW.revision AND state='pending';
 RETURN NEW;
END
$$;


--
-- Name: sync_review_clocks(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_review_clocks(target uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM id FROM projects WHERE id=target FOR NO KEY UPDATE;
 IF NOT FOUND THEN RETURN; END IF;
 WITH active AS MATERIALIZED (SELECT * FROM review_actions WHERE project_id=target),
 retired AS (
   UPDATE review_clocks c SET closed_at=now()
   WHERE c.project_id=target AND c.closed_at IS NULL AND NOT EXISTS (
    SELECT FROM active a WHERE a.action_key=c.action_key)
 )
 INSERT INTO review_clocks(action_key,project_id,opened_at,original_due,due_at,lead_hours,escalation_hours)
 SELECT a.action_key,target,a.opened,d.deadline,d.deadline,
        coalesce(p.lead_hours,t.lead_hours,2),coalesce(p.escalation_hours,t.escalation_hours,4)
 FROM active a LEFT JOIN review_policies p ON p.project_id=target
 LEFT JOIN review_policies t ON t.team_id=a.team_id
 CROSS JOIN LATERAL (SELECT a.opened+make_interval(hours=>coalesce(p.hours,t.hours,24)) AS deadline) d
 WHERE NOT EXISTS (SELECT FROM review_clocks c WHERE c.action_key=a.action_key AND c.closed_at IS NULL)
 ON CONFLICT(action_key) WHERE closed_at IS NULL DO NOTHING;
END $$;


--
-- Name: takeover_review_needed(uuid, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.takeover_review_needed(project uuid, artifact uuid, rev integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT FROM projects p JOIN reviewer_handoffs h ON h.id=p.reviewer_assignment
 WHERE p.id=project AND h.emergency AND h.state='accepted' AND h.successor=p.final_reviewer AND NOT EXISTS(
 SELECT FROM takeover_reviews t WHERE t.assignment=h.id AND (t.artifact_id,t.version,t.reviewer)=(artifact,rev,p.final_reviewer)))
$$;


--
-- Name: text_agent_choice_ready(public.agent_revisions); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.text_agent_choice_ready(candidate public.agent_revisions) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT coalesce(agent_choice_profile(candidate)='text' AND (
   candidate.card IS NULL OR (
     agent_released_remote_operation_evidence(candidate.agent_id,candidate.revision) IS NOT NULL
     AND remote_operation_ready(agent_released_remote_operation_evidence(candidate.agent_id,candidate.revision))
   )
 ),false)
$$;


--
-- Name: tool_choice_profile(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tool_choice_profile(tool jsonb) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
 SELECT CASE
  WHEN tool->>'operation' IN ('aggregate','docx','xlsx','pptx') AND coalesce(tool->>'contract','')=''
   THEN tool->>'operation'
  WHEN tool @> '{"operation":"pptx","contract":"pptx-outline-v1"}' THEN 'pptx-outline-v1'
 END
$$;


--
-- Name: trace_run_transition(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trace_run_transition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='INSERT' OR OLD.status IS DISTINCT FROM NEW.status THEN
   IF NEW.status IN ('completed','cancelled','failed') AND NEW.finished_at IS NULL THEN
     NEW.finished_at=clock_timestamp();
     SELECT NEW.finished_at+t.trace_days*interval '1 day' INTO NEW.trace_expires_at
       FROM projects p JOIN teams t ON t.id=p.team_id WHERE p.id=NEW.project_id;
   END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: trace_transition_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trace_transition_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='UPDATE' AND NEW.status IS NOT DISTINCT FROM OLD.status THEN RETURN NULL; END IF;
 IF TG_TABLE_NAME='runs' THEN
   INSERT INTO trace_events(run_id,kind,code) VALUES(NEW.id,'run',NEW.status);
 ELSE
   INSERT INTO trace_events(run_id,ordinal,kind,code) VALUES(NEW.run_id,NEW.ordinal,'call',NEW.status);
 END IF;
 RETURN NULL;
END $$;


--
-- Name: track_service_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.track_service_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid uuid; step integer;
BEGIN
 CASE TG_TABLE_NAME
 WHEN 'runs' THEN
  IF TG_OP='INSERT' OR OLD.status IS DISTINCT FROM NEW.status THEN PERFORM record_service_event(NEW.id,'run',NEW.status); END IF;
 WHEN 'projects' THEN
  IF NEW.stage IS DISTINCT FROM OLD.stage THEN
   FOR rid IN SELECT id FROM runs WHERE project_id=NEW.id AND app_id IS NOT NULL LOOP PERFORM record_service_event(rid,'project',NEW.stage); END LOOP;
  END IF;
 WHEN 'artifacts' THEN
  IF TG_OP='INSERT' OR NEW.current_version IS DISTINCT FROM OLD.current_version THEN PERFORM record_service_event(NEW.run_id,'artifact','ready',NEW.ordinal,NEW.id,NEW.current_version); END IF;
 WHEN 'reviews' THEN
  SELECT run_id,ordinal INTO rid,step FROM artifacts WHERE id=NEW.artifact_id;
  PERFORM record_service_event(rid,'artifact','approved',step,NEW.artifact_id,NEW.version);
 WHEN 'feedback' THEN
  IF TG_OP='INSERT' OR NEW.state IS DISTINCT FROM OLD.state THEN
   SELECT run_id,ordinal INTO rid,step FROM artifacts WHERE id=NEW.artifact_id;
   PERFORM record_service_event(rid,'feedback',NEW.state,step,NEW.artifact_id,NEW.base_version);
  END IF;
 END CASE;
 RETURN NULL;
END $$;


--
-- Name: usable_change_source(uuid, uuid, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.usable_change_source(target uuid, source_key uuid, pinned integer, observed integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS (
   SELECT FROM source_versions original JOIN source_versions candidate ON candidate.source_id=original.source_id
   WHERE original.source_id=source_key AND original.version=pinned AND candidate.version=observed
     AND CASE WHEN source_is_picture(original.media_type) THEN
       source_is_picture(candidate.media_type) AND candidate.object_hash IS NOT NULL AND EXISTS (
         SELECT FROM artifacts a JOIN effective_run_nodes n ON (n.run_id,n.ordinal)=(a.run_id,a.ordinal)
         JOIN agent_revisions v ON (v.agent_id,v.revision)=(n.agent_id,n.agent_revision)
         WHERE a.id=target AND agent_uses_picture(v)
       )
     ELSE candidate.extracted IS NOT NULL END
 )
$$;


--
-- Name: verified_document_format(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.verified_document_format(target uuid, ver integer) RETURNS text
    LANGUAGE sql STABLE
    AS $$
 SELECT agent.tool->>'operation' FROM artifacts a
 JOIN artifact_versions v ON (v.artifact_id,v.version)=(a.id,ver)
 JOIN artifact_files f ON (f.artifact_id,f.version)=(v.artifact_id,v.version)
 JOIN runs r ON r.id=a.run_id
 JOIN nodes n ON (n.project_id,n.plan_version,n.ordinal)=(a.project_id,r.plan_version,a.ordinal)
 JOIN agent_revisions agent ON (agent.agent_id,agent.revision)=(n.agent_id,n.agent_revision)
 WHERE a.id=target AND (
   (agent.tool->>'operation'='docx' AND f.media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
   OR (agent.tool @> '{"operation":"pptx","contract":"pptx-outline-v1"}'::jsonb
       AND f.media_type='application/vnd.openxmlformats-officedocument.presentationml.presentation')
 )
 AND EXISTS (
   SELECT FROM invocation_files ff JOIN invocations i USING(run_id,ordinal)
   WHERE ff.object_hash=f.object_hash AND i.ordinal=a.ordinal AND i.result=v.body AND
   (i.run_id=a.run_id OR EXISTS(SELECT FROM change_batches cb WHERE cb.run_id=i.run_id AND cb.artifact_id=a.id)
     OR EXISTS(SELECT FROM rule_branch_steps b WHERE b.run_id=i.run_id AND b.artifact_id=a.id AND b.result_version=ver AND b.mode<>'reuse'))
 );
$$;


--
-- Name: visible_artifact_remote_receipts(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.visible_artifact_remote_receipts(target uuid, viewer uuid) RETURNS TABLE(artifact_id uuid, version integer, receipt jsonb)
    LANGUAGE sql STABLE ROWS 32
    SET jit TO 'off'
    AS $$
 SELECT link.artifact_id,link.version,jsonb_build_object(
   'task',e.task,'way',e.way,'agent',ar.name,'agentRevision',e.agent_revision,
   'step',e.ordinal,'attempt',e.attempt_no,'completedAt',e.observed_at)
 FROM project_members pm JOIN members m ON m.id=pm.member_id AND m.enabled AND m.departed_at IS NULL
 JOIN artifacts a ON a.project_id=pm.project_id
 JOIN artifact_versions v ON (v.artifact_id,v.version)=(a.id,a.current_version)
 JOIN artifact_remote_receipts link ON (link.artifact_id,link.version)=(v.artifact_id,v.version)
 JOIN remote_completion_evidence e ON (e.run_id,e.ordinal,e.attempt_no)=(link.run_id,link.ordinal,link.attempt_no)
 JOIN agent_revisions ar ON (ar.agent_id,ar.revision)=(e.agent_id,e.agent_revision)
 WHERE (pm.project_id,pm.member_id)=(target,viewer) AND pm.can_review
   AND distribution_readable(a.id,v.version,viewer)
   AND run_working_set_usable(e.run_id,e.ordinal,e.attempt_no)
   AND e.body_digest=encode(digest(v.body,'sha256'),'hex')
$$;


--
-- Name: artifact_requirement_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifact_requirement_evidence (
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    findings jsonb NOT NULL,
    CONSTRAINT artifact_requirement_evidence_findings_check CHECK (((jsonb_typeof(findings) = 'array'::text) AND ((jsonb_array_length(findings) >= 1) AND (jsonb_array_length(findings) <= 32))))
);


--
-- Name: visible_artifact_requirement_evidence(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.visible_artifact_requirement_evidence(target uuid, viewer uuid) RETURNS SETOF public.artifact_requirement_evidence
    LANGUAGE sql STABLE ROWS 32
    SET jit TO 'off'
    AS $$
 SELECT e.* FROM projects p JOIN artifacts a ON a.project_id=p.id
 JOIN artifact_requirement_evidence e ON (e.artifact_id,e.version)=(a.id,a.current_version)
 JOIN runs r ON (r.id,r.project_id,r.plan_version)=(e.run_id,p.id,p.plan_version)
 JOIN project_members m ON (m.project_id,m.member_id)=(p.id,viewer) AND m.can_review
 JOIN members u ON u.id=m.member_id AND u.enabled AND u.departed_at IS NULL
 WHERE p.id=target AND p.stage IN ('running','review')
   AND e.ordinal=a.ordinal AND distribution_readable(e.artifact_id,e.version,viewer)
   AND run_working_set_usable(e.run_id,e.ordinal,e.attempt_no)
$$;


--
-- Name: visible_column_issues(uuid, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.visible_column_issues(target uuid, actor uuid, document jsonb) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE WHEN document IS NOT NULL
 AND EXISTS(SELECT FROM column_correction_authority ca WHERE ca.run_id=target AND ca.member_id=actor)
 AND NOT EXISTS(SELECT FROM run_source_inputs f WHERE f.run_id=target AND f.extracted IS NULL)
 AND NOT EXISTS(SELECT FROM column_correction_items(document) issue
   WHERE NOT EXISTS(SELECT FROM run_source_inputs f WHERE f.run_id=target
   AND f.source_id::text=issue->>'source' AND f.version::text=issue->>'version' AND f.extracted IS NOT NULL))
 THEN (SELECT jsonb_agg(issue ORDER BY n) FROM column_correction_items(document) WITH ORDINALITY AS q(issue,n)) END
$$;


--
-- Name: visible_column_mappings(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.visible_column_mappings(target uuid, document jsonb) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
 SELECT jsonb_agg(jsonb_build_object('name',f.filename,'version',f.version,'columns',q.mapping->'columns') ORDER BY q.n)
 FROM column_correction_items(document) WITH ORDINALITY AS q(mapping,n)
 JOIN run_source_inputs f ON f.run_id=target AND f.source_id::text=q.mapping->>'source'
 AND f.version::text=q.mapping->>'version' AND f.extracted IS NOT NULL
 WHERE q.mapping ? 'columns'
$$;


--
-- Name: workflow_build_usable(uuid, integer, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workflow_build_usable(template_key uuid, template_version integer, agent_key uuid, version integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $_$
 SELECT NOT EXISTS(SELECT FROM workflow_template_builds b
   WHERE (b.template_id,b.version,b.agent_id,b.agent_revision)=($1,$2,$3,$4)
     AND b.build_digest IS DISTINCT FROM agent_build_digest(agent_build_definition($3,$4)))
$_$;


--
-- Name: working_artifact_origin(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.working_artifact_origin(artifact_key uuid, edition integer) RETURNS TABLE(run_id uuid, ordinal integer, attempt_no integer)
    LANGUAGE sql STABLE
    AS $$
 WITH RECURSIVE undelivered(version) AS (
   SELECT edition WHERE NOT EXISTS(SELECT FROM reviews v WHERE (v.artifact_id,v.version)=(artifact_key,edition))
   UNION ALL
   SELECT v.copied_from FROM undelivered e
   JOIN artifact_versions v ON (v.artifact_id,v.version)=(artifact_key,e.version)
   WHERE v.copied_from IS NOT NULL AND NOT EXISTS(
     SELECT FROM reviews approved WHERE (approved.artifact_id,approved.version)=(artifact_key,v.copied_from))
 )
 SELECT i.run_id,i.ordinal,i.attempt_no FROM invocations i JOIN (
   SELECT a.run_id,a.ordinal FROM artifacts a WHERE a.id=artifact_key AND EXISTS(SELECT FROM undelivered WHERE version=1)
   UNION
   SELECT c.run_id,a.ordinal FROM change_batches c JOIN artifacts a ON a.id=c.artifact_id
   WHERE a.id=artifact_key AND c.applied_version IN (SELECT version FROM undelivered)
   UNION
   SELECT b.run_id,b.ordinal FROM rule_branch_steps b
   WHERE b.artifact_id=artifact_key AND b.result_version IN (SELECT version FROM undelivered) AND b.mode<>'reuse'
 ) origin USING(run_id,ordinal)
$$;


--
-- Name: working_preference_inputs(uuid, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.working_preference_inputs(run_key uuid, step_no integer, attempt integer) RETURNS TABLE(run_id uuid, ref uuid, revision integer, usable boolean)
    LANGUAGE sql STABLE
    AS $$
 WITH RECURSIVE lineage(run_id,ordinal,attempt_no) AS (
   SELECT run_key,step_no,attempt
   UNION
   SELECT p.parent_run,p.parent_ordinal,p.parent_attempt FROM lineage l
   JOIN run_working_parents p USING(run_id,ordinal,attempt_no)
 )
 SELECT d.run_id,d.ref,d.revision,
   run_preference_pin_usable(d.run_id,s.build_agent,d.ref,d.revision)
     AND NOT coalesce(s.invalidated_kind='preference' AND s.invalidated_ref=d.ref,false)
 FROM lineage l JOIN run_working_sets s USING(run_id,ordinal,attempt_no)
 JOIN run_working_inputs d USING(run_id,ordinal,attempt_no) WHERE d.kind='preference'
$$;


--
-- Name: account_notices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_notices (
    event_seq bigint NOT NULL,
    member_id uuid NOT NULL,
    read_at timestamp with time zone
);


--
-- Name: change_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_batches (
    run_id uuid NOT NULL,
    feedback_id uuid NOT NULL,
    feedback_revision integer NOT NULL,
    artifact_id uuid NOT NULL,
    base_version integer NOT NULL,
    replacement text NOT NULL,
    disposition text DEFAULT 'pending'::text NOT NULL,
    applied_version integer,
    excerpt text DEFAULT ''::text NOT NULL,
    source_assessment uuid,
    slide_page integer,
    image_region jsonb,
    CONSTRAINT change_batches_disposition_check CHECK ((disposition = ANY (ARRAY['pending'::text, 'conflict'::text, 'applied'::text, 'discarded'::text]))),
    CONSTRAINT change_batches_slide_page_check CHECK (((slide_page >= 1) AND (slide_page <= 40)))
);


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    display_name text NOT NULL,
    password_hash text NOT NULL,
    role text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    kind text DEFAULT 'person'::text NOT NULL,
    department_id uuid,
    departed_at timestamp with time zone,
    account_revision bigint DEFAULT 1 NOT NULL,
    CONSTRAINT members_check CHECK (((departed_at IS NULL) OR (NOT enabled))),
    CONSTRAINT members_kind_check CHECK ((kind = ANY (ARRAY['person'::text, 'application'::text]))),
    CONSTRAINT members_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'member'::text])))
);


--
-- Name: project_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_memberships (
    project_id uuid NOT NULL,
    member_id uuid NOT NULL,
    can_review boolean DEFAULT false NOT NULL,
    can_view_costs boolean DEFAULT false NOT NULL,
    recovery_assignment uuid
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner uuid NOT NULL,
    team_id uuid NOT NULL,
    final_reviewer uuid NOT NULL,
    title text NOT NULL,
    stage text DEFAULT 'brief'::text NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    plan_version integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    planning_resource uuid,
    planning_revision integer,
    reviewer_assignment uuid,
    originating_department uuid,
    review_started_at timestamp with time zone
);


--
-- Name: reviewer_handoffs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviewer_handoffs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    previous_reviewer uuid NOT NULL,
    successor uuid NOT NULL,
    proposer uuid NOT NULL,
    emergency boolean NOT NULL,
    reason text NOT NULL,
    end_condition text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    decided_at timestamp with time zone,
    decision_by uuid,
    decision_reason text DEFAULT ''::text NOT NULL,
    recovery_until timestamp with time zone,
    access_ended_at timestamp with time zone,
    access_end_reason text,
    CONSTRAINT reviewer_handoffs_check CHECK (((previous_reviewer <> successor) OR (recovery_until IS NOT NULL))),
    CONSTRAINT reviewer_handoffs_check1 CHECK (((recovery_until IS NULL) OR emergency)),
    CONSTRAINT reviewer_handoffs_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'accepted'::text, 'declined'::text, 'withdrawn'::text, 'superseded'::text, 'closed'::text])))
);


--
-- Name: project_members; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.project_members AS
 SELECT project_id,
    member_id,
    can_review,
    can_view_costs,
    recovery_assignment
   FROM public.project_memberships pm
  WHERE ((recovery_assignment IS NULL) OR (EXISTS ( SELECT
           FROM (public.reviewer_handoffs h
             JOIN public.projects p ON (((p.id = h.project_id) AND (p.reviewer_assignment = h.id))))
          WHERE ((h.id = pm.recovery_assignment) AND (h.project_id = pm.project_id) AND (h.successor = pm.member_id) AND (h.state = 'accepted'::text) AND (h.access_ended_at IS NULL) AND (h.recovery_until > statement_timestamp()) AND (p.stage <> ALL (ARRAY['delivered'::text, 'adopted'::text, 'cancelled'::text, 'failed'::text]))))));


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    actor uuid NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    charge_team uuid NOT NULL,
    request_key text NOT NULL,
    request_hash bytea NOT NULL,
    max_calls integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    app_id uuid,
    delegated_by uuid,
    service_id uuid,
    service_version integer,
    control_revision integer DEFAULT 1 NOT NULL,
    finished_at timestamp with time zone,
    trace_expires_at timestamp with time zone,
    await_calculation_receipt boolean DEFAULT false NOT NULL,
    await_lookup_receipt boolean DEFAULT false NOT NULL,
    draft_seq bigint DEFAULT 0 NOT NULL,
    step_remote_input boolean DEFAULT false NOT NULL,
    step_source_receipt boolean DEFAULT false NOT NULL,
    step_tool_choice boolean DEFAULT false NOT NULL,
    bounded_upstream_context boolean DEFAULT true NOT NULL,
    step_dispatch_wait boolean DEFAULT false NOT NULL,
    skip_unavailable_preferences boolean DEFAULT false NOT NULL,
    CONSTRAINT runs_max_calls_check CHECK ((max_calls > 0))
);


--
-- Name: call_review_authority; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.call_review_authority AS
 SELECT r.id AS run_id,
    m.id AS member_id
   FROM (((public.runs r
     JOIN public.projects p ON ((p.id = r.project_id)))
     JOIN public.project_members pm ON ((pm.project_id = p.id)))
     JOIN public.members m ON (((m.id = pm.member_id) AND m.enabled)))
  WHERE ((m.id = p.owner) OR (pm.can_review AND (m.id = r.actor) AND (EXISTS ( SELECT
           FROM public.change_batches cb
          WHERE (cb.run_id = r.id)))));


--
-- Name: call_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.call_reviews (
    control_id uuid NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    decision text NOT NULL,
    submission_timed_out boolean DEFAULT false NOT NULL,
    execution_due timestamp with time zone,
    receipt_due timestamp with time zone,
    input_mapping jsonb,
    superseded_by uuid,
    CONSTRAINT call_reviews_check CHECK (((input_mapping IS NULL) OR (decision = 'redo'::text))),
    CONSTRAINT call_reviews_check1 CHECK (((superseded_by IS NULL) OR ((input_mapping IS NOT NULL) AND (superseded_by <> control_id)))),
    CONSTRAINT call_reviews_decision_check CHECK ((decision = ANY (ARRAY['hold'::text, 'redo'::text])))
);


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    team_id uuid NOT NULL,
    member_id uuid NOT NULL
);


--
-- Name: column_correction_authority; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.column_correction_authority AS
 SELECT r.id AS run_id,
    m.id AS member_id
   FROM (((public.runs r
     JOIN public.projects p ON ((p.id = r.project_id)))
     JOIN public.project_members pm ON ((pm.project_id = p.id)))
     JOIN public.members m ON ((m.id = pm.member_id)))
  WHERE (m.enabled AND (m.kind = 'person'::text) AND ((EXISTS ( SELECT
           FROM public.call_review_authority a
          WHERE ((a.run_id = r.id) AND (a.member_id = m.id)))) OR ((r.app_id IS NOT NULL) AND (r.delegated_by IS NULL) AND (p.final_reviewer = m.id) AND pm.can_review AND (EXISTS ( SELECT
           FROM public.team_members t
          WHERE ((t.team_id = p.team_id) AND (t.member_id = m.id)))))));


--
-- Name: controls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.controls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    signature bytea NOT NULL,
    action text NOT NULL,
    reason text NOT NULL,
    revision integer NOT NULL,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    wake_ordinal integer,
    CONSTRAINT controls_wake_ordinal_check CHECK ((wake_ordinal > 0))
);


--
-- Name: active_call_redos; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.active_call_redos AS
 SELECT v.control_id,
    v.run_id,
    v.ordinal,
    v.attempt_no,
    v.decision,
    v.submission_timed_out,
    v.execution_due,
    v.receipt_due,
    v.input_mapping,
    v.superseded_by,
        CASE
            WHEN (v.input_mapping IS NOT NULL) THEN (EXISTS ( SELECT
               FROM public.column_correction_authority a
              WHERE ((a.run_id = v.run_id) AND (a.member_id = c.actor))))
            ELSE (EXISTS ( SELECT
               FROM public.call_review_authority a
              WHERE ((a.run_id = v.run_id) AND (a.member_id = c.actor))))
        END AS authority_current
   FROM (public.call_reviews v
     JOIN public.controls c ON ((c.id = v.control_id)))
  WHERE ((v.decision = 'redo'::text) AND (v.superseded_by IS NULL));


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodes (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    ordinal integer NOT NULL,
    agent_id uuid NOT NULL,
    agent_revision integer NOT NULL,
    lookup_phase text DEFAULT ''::text NOT NULL,
    CONSTRAINT nodes_lookup_phase_check CHECK ((lookup_phase = ANY (ARRAY[''::text, 'search'::text, 'answer'::text, 'answer_calc'::text, 'review_evidence'::text, 'synthesize'::text])))
);


--
-- Name: run_tool_choice_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_tool_choice_waits (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    control_revision integer NOT NULL
);


--
-- Name: run_tool_choices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_tool_choices (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    choice integer NOT NULL,
    manual_choice integer,
    manual_by uuid,
    CONSTRAINT run_tool_choices_check CHECK (((manual_choice IS NULL) OR ((manual_choice = ANY (ARRAY[1, 2])) AND (choice = 0)))),
    CONSTRAINT run_tool_choices_check1 CHECK (((manual_choice IS NULL) = (manual_by IS NULL))),
    CONSTRAINT run_tool_choices_choice_check CHECK (((choice >= 0) AND (choice <= 2)))
);


--
-- Name: step_tool_choice_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.step_tool_choice_waits (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    opened_at_control integer NOT NULL
);


--
-- Name: active_tool_choice_waits; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.active_tool_choice_waits AS
 SELECT r.id AS run_id,
    c.ordinal,
    r.step_tool_choice AS step_scoped
   FROM (((((public.runs r
     JOIN public.run_tool_choices c ON (((c.run_id = r.id) AND (c.choice = 0) AND (c.manual_choice IS NULL))))
     JOIN public.nodes n ON (((n.project_id = r.project_id) AND (n.plan_version = r.plan_version) AND (n.ordinal = c.ordinal))))
     JOIN public.agent_revisions a ON (((a.agent_id = n.agent_id) AND (a.revision = n.agent_revision))))
     LEFT JOIN public.step_tool_choice_waits step_wait ON (((step_wait.run_id = r.id) AND (step_wait.ordinal = c.ordinal))))
     LEFT JOIN public.run_tool_choice_waits run_wait ON (((run_wait.run_id = r.id) AND (run_wait.ordinal = c.ordinal))))
  WHERE ((r.step_tool_choice AND (r.status = 'running'::text) AND (step_wait.run_id IS NOT NULL)) OR ((NOT r.step_tool_choice) AND (r.status = 'blocked'::text) AND (((a.tool ->> 'operation'::text) = 'aggregate'::text) OR (run_wait.control_revision = r.control_revision))));


--
-- Name: model_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_revisions (
    resource_id uuid NOT NULL,
    revision integer NOT NULL,
    endpoint text NOT NULL,
    model text NOT NULL,
    encrypted_key bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    estimate_cny numeric(18,6),
    key_generation integer DEFAULT 1 NOT NULL,
    key_blocked boolean DEFAULT false NOT NULL,
    operation text DEFAULT 'text'::text NOT NULL,
    stream_text boolean DEFAULT false NOT NULL,
    CONSTRAINT model_revisions_check CHECK (((NOT stream_text) OR (operation = 'text'::text))),
    CONSTRAINT model_revisions_estimate_cny_check CHECK ((estimate_cny >= (0)::numeric)),
    CONSTRAINT model_revisions_operation_check CHECK ((operation = ANY (ARRAY['text'::text, 'png'::text, 'vision'::text, 'image-edit'::text])))
);


--
-- Name: resource_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_budgets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    kind text NOT NULL,
    model_id uuid,
    agent_id uuid,
    limit_cny numeric(18,6),
    call_limit integer,
    warning_percent integer DEFAULT 80 NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    CONSTRAINT resource_budgets_call_limit_check CHECK ((call_limit >= 0)),
    CONSTRAINT resource_budgets_check CHECK ((((kind = 'model'::text) AND (model_id IS NOT NULL) AND (agent_id IS NULL)) OR ((kind <> 'model'::text) AND (model_id IS NULL) AND (agent_id IS NOT NULL)))),
    CONSTRAINT resource_budgets_kind_check CHECK ((kind = ANY (ARRAY['model'::text, 'tool'::text, 'external'::text]))),
    CONSTRAINT resource_budgets_limit_cny_check CHECK ((limit_cny >= (0)::numeric)),
    CONSTRAINT resource_budgets_warning_percent_check CHECK (((warning_percent >= 1) AND (warning_percent <= 100)))
);


--
-- Name: agent_budget_bindings; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.agent_budget_bindings AS
 SELECT r.agent_id,
    r.revision,
    b.id AS budget_id,
    r.resource_revision AS source_revision,
    m.model AS source_name
   FROM ((public.agent_revisions r
     JOIN public.resource_budgets b ON ((b.model_id = r.resource_id)))
     JOIN public.model_revisions m ON (((m.resource_id = r.resource_id) AND (m.revision = r.resource_revision))))
UNION ALL
 SELECT r.agent_id,
    r.revision,
    b.id AS budget_id,
    r.revision AS source_revision,
    COALESCE((r.tool ->> 'operation'::text), (r.card ->> 'name'::text), r.name) AS source_name
   FROM (public.agent_revisions r
     JOIN public.resource_budgets b ON (((b.agent_id = r.agent_id) AND (b.kind =
        CASE
            WHEN (r.tool IS NOT NULL) THEN 'tool'::text
            WHEN (r.card IS NOT NULL) THEN 'external'::text
            ELSE NULL::text
        END))));


--
-- Name: agent_build_manifests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_build_manifests (
    agent_id uuid NOT NULL,
    revision integer NOT NULL,
    digest text NOT NULL,
    definition jsonb NOT NULL,
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_build_manifests_digest_check CHECK ((digest ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: agent_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_checks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    revision integer NOT NULL,
    ordinal integer NOT NULL,
    name text NOT NULL,
    sample text NOT NULL,
    expected text NOT NULL,
    match_kind text NOT NULL,
    reviewer uuid,
    CONSTRAINT agent_checks_match_kind_check CHECK ((match_kind = ANY (ARRAY['contains'::text, 'exact'::text])))
);


--
-- Name: agent_improvement_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_improvement_decisions (
    request_id uuid NOT NULL,
    version integer NOT NULL,
    actor uuid NOT NULL,
    state text NOT NULL,
    reason text NOT NULL,
    decided_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_improvements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_improvements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    base_revision integer NOT NULL,
    requester uuid NOT NULL,
    request_key text NOT NULL,
    description text NOT NULL,
    acceptance text NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    result_revision integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_improvements_check CHECK (((state = 'resolved'::text) = (result_revision IS NOT NULL))),
    CONSTRAINT agent_improvements_state_check CHECK ((state = ANY (ARRAY['open'::text, 'accepted'::text, 'declined'::text, 'withdrawn'::text, 'resolved'::text])))
);


--
-- Name: agent_publications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_publications (
    agent_id uuid NOT NULL,
    generation bigint NOT NULL,
    revision integer NOT NULL,
    build_digest text NOT NULL,
    evidence_digest text NOT NULL,
    evidence_snapshot jsonb NOT NULL,
    prior_revision integer,
    request_id uuid,
    actor uuid NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    restored_from_generation bigint,
    restore_reason text DEFAULT ''::text NOT NULL,
    CONSTRAINT agent_publications_check CHECK ((((restored_from_generation IS NULL) AND (restore_reason = ''::text)) OR ((restored_from_generation IS NOT NULL) AND (restored_from_generation = (generation - 1)) AND (prior_revision IS NOT NULL) AND (prior_revision <> revision) AND ((length(restore_reason) >= 1) AND (length(restore_reason) <= 1000)))))
);


--
-- Name: agent_release_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_release_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    revision integer NOT NULL,
    requester uuid NOT NULL,
    requested_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    decider uuid,
    reason text DEFAULT ''::text NOT NULL,
    decided_at timestamp with time zone,
    build_digest text,
    evidence_digest text,
    evidence_snapshot jsonb,
    base_generation bigint,
    CONSTRAINT agent_release_requests_check CHECK ((((state = 'pending'::text) = (decider IS NULL)) AND ((decider IS NULL) = (decided_at IS NULL)))),
    CONSTRAINT agent_release_requests_check1 CHECK (((state = 'returned'::text) = (reason <> ''::text))),
    CONSTRAINT agent_release_requests_check2 CHECK ((((build_digest IS NULL) AND (evidence_digest IS NULL) AND (evidence_snapshot IS NULL) AND (base_generation IS NULL)) OR ((build_digest IS NOT NULL) AND (evidence_digest IS NOT NULL) AND (evidence_snapshot IS NOT NULL) AND (base_generation IS NOT NULL)))),
    CONSTRAINT agent_release_requests_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'returned'::text, 'published'::text, 'superseded'::text])))
);


--
-- Name: agent_skill_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_skill_bindings (
    agent_id uuid NOT NULL,
    revision integer NOT NULL,
    skill_id uuid NOT NULL,
    skill_revision integer NOT NULL,
    "position" integer NOT NULL,
    root boolean NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner uuid NOT NULL,
    team_id uuid NOT NULL,
    published_revision integer,
    disabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    emergency boolean DEFAULT false NOT NULL,
    removed boolean DEFAULT false NOT NULL,
    maintenance_vacant boolean DEFAULT false NOT NULL,
    maintenance_version integer DEFAULT 1 NOT NULL,
    proposed_owner uuid,
    proposed_by uuid,
    transfer_reason text,
    publication_generation bigint DEFAULT 0 NOT NULL,
    CONSTRAINT agents_check CHECK ((((proposed_owner IS NULL) = (proposed_by IS NULL)) AND ((proposed_owner IS NULL) = (transfer_reason IS NULL))))
);


--
-- Name: answer_adoptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.answer_adoptions (
    project_id uuid NOT NULL,
    request_id uuid NOT NULL,
    actor uuid NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.applications (
    id uuid NOT NULL,
    service_id uuid NOT NULL,
    token_hash bytea NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: artifact_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifact_files (
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    object_hash text NOT NULL,
    filename text NOT NULL,
    media_type text NOT NULL
);


--
-- Name: artifact_remote_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifact_remote_receipts (
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL
);


--
-- Name: artifact_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifact_versions (
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    body text NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    copied_from integer,
    CONSTRAINT artifact_versions_check CHECK ((copied_from = (version - 1)))
);


--
-- Name: artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    name text NOT NULL,
    current_version integer DEFAULT 1 NOT NULL
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    seq bigint NOT NULL,
    actor uuid,
    action text NOT NULL,
    subject text NOT NULL,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_events ALTER COLUMN seq ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bill_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bill_rows (
    team_id uuid NOT NULL,
    line_key text NOT NULL,
    spend_id uuid NOT NULL,
    amount_cny numeric(18,6) NOT NULL,
    final boolean NOT NULL,
    actor uuid NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rule_branch_rebuilds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_branch_rebuilds (
    run_id uuid NOT NULL,
    source_run uuid NOT NULL,
    authorized_calls integer NOT NULL,
    preview jsonb NOT NULL,
    CONSTRAINT rule_branch_rebuilds_authorized_calls_check CHECK ((authorized_calls > 0)),
    CONSTRAINT rule_branch_rebuilds_check CHECK ((source_run <> run_id))
);


--
-- Name: branch_rebuild_ancestors; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.branch_rebuild_ancestors AS
 WITH RECURSIVE parents(run_id, source_run) AS (
         SELECT rule_branch_rebuilds.run_id,
            rule_branch_rebuilds.source_run
           FROM public.rule_branch_rebuilds
        UNION
         SELECT p.run_id,
            b.source_run
           FROM (parents p
             JOIN public.rule_branch_rebuilds b ON ((b.run_id = p.source_run)))
        )
 SELECT run_id,
    source_run
   FROM parents;


--
-- Name: trace_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trace_events (
    seq bigint NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer,
    kind text NOT NULL,
    code text NOT NULL,
    occurred_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    call_attempt integer
);


--
-- Name: budget_blocked_runs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.budget_blocked_runs AS
 SELECT id,
    project_id,
    control_revision,
    actor,
    created_at,
    (EXISTS ( SELECT
           FROM public.change_batches c
          WHERE (c.run_id = r.id))) AS is_change
   FROM public.runs r
  WHERE ((status = 'blocked'::text) AND (( SELECT e.code
           FROM public.trace_events e
          WHERE ((e.run_id = r.id) AND (e.kind = 'checkpoint'::text))
          ORDER BY e.seq DESC
         LIMIT 1) = 'budget_denied'::text));


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    team_id uuid NOT NULL,
    limit_cny numeric(18,6),
    warning_percent integer DEFAULT 80 NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    CONSTRAINT budgets_limit_cny_check CHECK ((limit_cny >= (0)::numeric)),
    CONSTRAINT budgets_warning_percent_check CHECK (((warning_percent >= 1) AND (warning_percent <= 100)))
);


--
-- Name: gap_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gap_bindings (
    request_id uuid NOT NULL,
    slot integer NOT NULL,
    revision integer NOT NULL,
    agent_id uuid NOT NULL,
    agent_revision integer NOT NULL,
    actor uuid NOT NULL,
    example_input text NOT NULL,
    expected_output text NOT NULL,
    CONSTRAINT gap_bindings_slot_check CHECK ((slot >= 0))
);


--
-- Name: model_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_resources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    team_id uuid NOT NULL,
    created_by uuid NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    emergency boolean DEFAULT false NOT NULL,
    lifecycle integer DEFAULT 1 NOT NULL
);


--
-- Name: planning_budget_blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planning_budget_blocks (
    project_id uuid NOT NULL,
    project_revision integer NOT NULL,
    budget_id uuid NOT NULL
);


--
-- Name: planning_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planning_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    project_revision integer NOT NULL,
    resource_id uuid NOT NULL,
    resource_revision integer NOT NULL,
    status text DEFAULT 'submitted'::text NOT NULL,
    result jsonb,
    tokens integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    rule_pins jsonb DEFAULT '[]'::jsonb NOT NULL,
    key_generation integer,
    input_sources jsonb,
    required_output text DEFAULT ''::text NOT NULL,
    context_through bigint DEFAULT 0 NOT NULL,
    context_compacted boolean DEFAULT false NOT NULL,
    CONSTRAINT planning_requests_required_output_check CHECK (public.planning_output_scope_valid(required_output))
);


--
-- Name: project_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_budgets (
    project_id uuid NOT NULL,
    limit_cny numeric(18,6),
    warning_percent integer DEFAULT 80 NOT NULL,
    revision integer DEFAULT 0 NOT NULL,
    CONSTRAINT project_budgets_limit_cny_check CHECK ((limit_cny >= (0)::numeric)),
    CONSTRAINT project_budgets_warning_percent_check CHECK (((warning_percent >= 1) AND (warning_percent <= 100)))
);


--
-- Name: spend; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spend (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    op_key text NOT NULL,
    team_id uuid NOT NULL,
    actor uuid NOT NULL,
    project_id uuid,
    run_id uuid,
    kind text NOT NULL,
    reserved_cny numeric(18,6),
    amount_cny numeric(18,6) DEFAULT 0 NOT NULL,
    unknown_authorized boolean NOT NULL,
    settled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resource_budget uuid,
    source_revision integer,
    source_name text,
    originating_department uuid,
    CONSTRAINT spend_reserved_cny_check CHECK ((reserved_cny >= (0)::numeric))
);


--
-- Name: project_budget_targets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.project_budget_targets AS
 SELECT p.id AS project_id,
    'project'::text AS scope,
    p.team_id,
    b.limit_cny,
    b.revision
   FROM (public.projects p
     JOIN public.project_budgets b ON ((b.project_id = p.id)))
UNION ALL
 SELECT payer.project_id,
    'team'::text AS scope,
    payer.team_id,
    b.limit_cny,
    b.revision
   FROM (( SELECT projects.id AS project_id,
            projects.team_id
           FROM public.projects
        UNION
         SELECT spend.project_id,
            spend.team_id
           FROM public.spend
          WHERE (spend.project_id IS NOT NULL)
        UNION
         SELECT n.project_id,
            a.team_id
           FROM ((public.nodes n
             JOIN public.projects p ON (((p.id = n.project_id) AND (p.plan_version = n.plan_version))))
             JOIN public.agents a ON ((a.id = n.agent_id)))) payer
     JOIN public.budgets b ON ((b.team_id = payer.team_id)));


--
-- Name: project_resource_budgets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.project_resource_budgets AS
 SELECT spend.project_id,
    spend.resource_budget AS budget_id
   FROM public.spend
  WHERE ((spend.project_id IS NOT NULL) AND (spend.resource_budget IS NOT NULL))
UNION
 SELECT pb.project_id,
    pb.budget_id
   FROM (public.planning_budget_blocks pb
     JOIN public.projects p ON (((p.id = pb.project_id) AND (p.revision = pb.project_revision))))
UNION
 SELECT n.project_id,
    b.budget_id
   FROM ((public.nodes n
     JOIN public.projects p ON (((p.id = n.project_id) AND (p.plan_version = n.plan_version))))
     JOIN public.agent_budget_bindings b ON (((b.agent_id = n.agent_id) AND (b.revision = n.agent_revision))))
UNION
 SELECT q.project_id,
    b.budget_id
   FROM (((public.gap_bindings g
     JOIN public.planning_requests q ON ((q.id = g.request_id)))
     JOIN public.projects p ON (((p.id = q.project_id) AND (q.project_revision >= (p.revision - 1)))))
     JOIN public.agent_budget_bindings b ON (((b.agent_id = g.agent_id) AND (b.revision = g.agent_revision))));


--
-- Name: resource_budget_status; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.resource_budget_status AS
 SELECT b.id,
    b.team_id,
    b.kind,
    b.model_id,
    b.agent_id,
    b.limit_cny,
    b.call_limit,
    b.warning_percent,
    b.revision,
    COALESCE(m.name, v.name) AS name,
    s.used,
    s.calls,
    s.unknown,
    s.recorded,
    s.reserved
   FROM (((public.resource_budgets b
     LEFT JOIN public.model_resources m ON ((m.id = b.model_id)))
     LEFT JOIN LATERAL ( SELECT r.name
           FROM public.agent_revisions r
          WHERE ((r.agent_id = b.agent_id) AND (((b.kind = 'tool'::text) AND (r.tool IS NOT NULL)) OR ((b.kind = 'external'::text) AND (r.card IS NOT NULL))))
          ORDER BY r.revision DESC
         LIMIT 1) v ON (true))
     CROSS JOIN LATERAL ( SELECT count(*) AS calls,
            count(*) FILTER (WHERE ((spend.reserved_cny IS NULL) AND (NOT spend.settled))) AS unknown,
            COALESCE(sum(spend.amount_cny), (0)::numeric) AS recorded,
            COALESCE(sum(GREATEST((spend.reserved_cny - spend.amount_cny), (0)::numeric)) FILTER (WHERE (NOT spend.settled)), (0)::numeric) AS reserved,
            COALESCE(sum((spend.amount_cny +
                CASE
                    WHEN spend.settled THEN (0)::numeric
                    ELSE GREATEST((COALESCE(spend.reserved_cny, (0)::numeric) - spend.amount_cny), (0)::numeric)
                END)), (0)::numeric) AS used
           FROM public.spend
          WHERE (spend.resource_budget = b.id)) s);


--
-- Name: budget_request_targets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.budget_request_targets AS
 SELECT project_budget_targets.project_id,
    project_budget_targets.scope,
    project_budget_targets.team_id,
    project_budget_targets.limit_cny AS limit_value,
    project_budget_targets.revision,
    NULL::uuid AS resource_budget,
    NULL::text AS resource_name
   FROM public.project_budget_targets
UNION ALL
 SELECT DISTINCT p.project_id,
    'team'::text AS scope,
    b.team_id,
    tb.limit_cny AS limit_value,
    tb.revision,
    NULL::uuid AS resource_budget,
    NULL::text AS resource_name
   FROM ((public.project_resource_budgets p
     JOIN public.resource_budgets b ON ((b.id = p.budget_id)))
     JOIN public.budgets tb ON ((tb.team_id = b.team_id)))
  WHERE (NOT (EXISTS ( SELECT
           FROM public.project_budget_targets t
          WHERE ((t.project_id = p.project_id) AND (t.scope = 'team'::text) AND (t.team_id = b.team_id)))))
UNION ALL
 SELECT p.project_id,
    v.scope,
    b.team_id,
    v.limit_value,
    b.revision,
    b.id AS resource_budget,
    b.name AS resource_name
   FROM ((public.project_resource_budgets p
     JOIN public.resource_budget_status b ON ((b.id = p.budget_id)))
     CROSS JOIN LATERAL ( VALUES ('resource'::text,b.limit_cny), ('resource_calls'::text,(b.call_limit)::numeric)) v(scope, limit_value));


--
-- Name: budget_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    scope text NOT NULL,
    team_id uuid NOT NULL,
    requester uuid NOT NULL,
    request_key text NOT NULL,
    signature bytea NOT NULL,
    requested_increase numeric(18,6) NOT NULL,
    baseline_revision integer NOT NULL,
    baseline_limit numeric(18,6) NOT NULL,
    project_used numeric NOT NULL,
    project_unknown bigint NOT NULL,
    reason text NOT NULL,
    remaining_work text NOT NULL,
    alternative text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    decided_at timestamp with time zone,
    decided_by uuid,
    decision_reason text,
    applied_revision integer,
    applied_limit numeric(18,6),
    run_id uuid,
    control_revision integer,
    project_calls bigint,
    resource_name text,
    resource_budget uuid,
    CONSTRAINT budget_requests_check CHECK (((state = 'pending'::text) = (decided_at IS NULL))),
    CONSTRAINT budget_requests_check1 CHECK (((state = 'approved'::text) = (applied_limit IS NOT NULL))),
    CONSTRAINT budget_requests_check2 CHECK (((run_id IS NULL) = (control_revision IS NULL))),
    CONSTRAINT budget_requests_check3 CHECK ((((scope = ANY (ARRAY['team'::text, 'project'::text])) AND (resource_budget IS NULL)) OR ((scope = ANY (ARRAY['resource'::text, 'resource_calls'::text])) AND (resource_budget IS NOT NULL)))),
    CONSTRAINT budget_requests_check4 CHECK (((scope <> 'resource_calls'::text) OR ((requested_increase = trunc(requested_increase)) AND (requested_increase <= (2147483647)::numeric)))),
    CONSTRAINT budget_requests_increment_cny_check CHECK ((requested_increase > (0)::numeric)),
    CONSTRAINT budget_requests_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text, 'withdrawn'::text, 'closed'::text])))
);


--
-- Name: calculation_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calculation_requests (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    reason text NOT NULL,
    kind text DEFAULT 'calculation'::text NOT NULL,
    request_revision integer,
    CONSTRAINT calculation_requests_kind_check CHECK ((kind = ANY (ARRAY['calculation'::text, 'lookup'::text]))),
    CONSTRAINT calculation_requests_request_revision_check CHECK ((request_revision > 0))
);


--
-- Name: invocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invocations (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    status text NOT NULL,
    tokens integer,
    cost_state text DEFAULT 'unknown'::text NOT NULL,
    result text,
    diagnostic text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    remote_task text,
    remote_context text,
    remote_status text,
    key_generation integer,
    attempt_no integer DEFAULT 1 NOT NULL,
    execution_seconds integer DEFAULT 120 NOT NULL,
    receipt_seconds integer DEFAULT 900 NOT NULL,
    input_issue jsonb,
    CONSTRAINT invocations_attempt_no_check CHECK ((attempt_no > 0)),
    CONSTRAINT invocations_execution_seconds_check CHECK ((execution_seconds > 0)),
    CONSTRAINT invocations_receipt_seconds_check CHECK ((receipt_seconds > 0))
);


--
-- Name: late_call_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.late_call_receipts (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    received_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    outcome text NOT NULL,
    tokens integer,
    body_sha256 text,
    file_sha256 text,
    remote_task text,
    remote_context text,
    remote_state text,
    CONSTRAINT late_call_receipts_outcome_check CHECK ((outcome = ANY (ARRAY['completed'::text, 'remote'::text, 'unknown'::text, 'input_rejected'::text])))
);


--
-- Name: superseded_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superseded_calls (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone NOT NULL,
    key_generation integer,
    review_control uuid NOT NULL
);


--
-- Name: call_attempts; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.call_attempts AS
 SELECT i.run_id,
    i.ordinal,
    i.attempt_no,
    i.started_at,
    i.ended_at,
    i.status,
    COALESCE(i.tokens, l.tokens) AS tokens,
    public.call_operation(i.run_id, i.ordinal, i.attempt_no) AS op_key
   FROM (public.invocations i
     LEFT JOIN public.late_call_receipts l USING (run_id, ordinal, attempt_no))
UNION ALL
 SELECT s.run_id,
    s.ordinal,
    s.attempt_no,
    s.started_at,
    s.ended_at,
        CASE
            WHEN (v.input_mapping IS NULL) THEN 'unknown'::text
            ELSE 'input_rejected'::text
        END AS status,
    l.tokens,
    public.call_operation(s.run_id, s.ordinal, s.attempt_no) AS op_key
   FROM ((public.superseded_calls s
     JOIN public.call_reviews v ON ((v.control_id = s.review_control)))
     LEFT JOIN public.late_call_receipts l ON (((l.run_id = s.run_id) AND (l.ordinal = s.ordinal) AND (l.attempt_no = s.attempt_no))));


--
-- Name: change_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_inputs (
    run_id uuid NOT NULL,
    artifact_id uuid NOT NULL,
    version integer NOT NULL
);


--
-- Name: source_assessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_assessments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    artifact_id uuid NOT NULL,
    artifact_version integer NOT NULL,
    source_id uuid NOT NULL,
    pinned_version integer NOT NULL,
    observed_version integer NOT NULL,
    revoked boolean NOT NULL,
    decision text NOT NULL,
    reason text NOT NULL,
    actor uuid NOT NULL,
    feedback_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT source_assessments_check CHECK (((decision = 'change'::text) = (feedback_id IS NOT NULL))),
    CONSTRAINT source_assessments_decision_check CHECK ((decision = ANY (ARRAY['retain'::text, 'change'::text])))
);


--
-- Name: source_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_versions (
    source_id uuid NOT NULL,
    version integer NOT NULL,
    object_hash text,
    media_type text NOT NULL,
    extracted text,
    embedding public.vector,
    author uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    filename text,
    extraction_state text DEFAULT ''::text NOT NULL,
    extraction_locations jsonb,
    CONSTRAINT source_versions_extraction_state_check CHECK ((extraction_state = ANY (ARRAY[''::text, 'ready'::text, 'empty'::text, 'invalid'::text, 'limited'::text, 'unavailable'::text])))
);


--
-- Name: change_source_receipts; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.change_source_receipts AS
 SELECT b.run_id,
    b.artifact_id,
    b.applied_version,
    c.source_id,
    jsonb_build_object('run', r.id, 'artifact', b.artifact_id, 'version', b.applied_version, 'source', c.source_id, 'name', v.filename, 'planPin', c.pinned_version, 'selected', c.observed_version, 'authorizedBy', r.actor, 'assessment', c.id, 'feedback', b.feedback_id) AS receipt
   FROM (((public.change_batches b
     JOIN public.source_assessments c ON ((c.id = b.source_assessment)))
     JOIN public.runs r ON ((r.id = b.run_id)))
     JOIN public.source_versions v ON (((v.source_id = c.source_id) AND (v.version = c.observed_version))));


--
-- Name: plan_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_sources (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    source_id uuid NOT NULL,
    source_version integer NOT NULL,
    receipt_step integer,
    receipt_order integer,
    excerpt_start integer,
    excerpt_end integer,
    receipt_kind text DEFAULT 'calculation'::text NOT NULL,
    picture_order integer,
    CONSTRAINT plan_sources_check CHECK ((((receipt_step IS NULL) AND (receipt_order IS NULL) AND (excerpt_start IS NULL) AND (excerpt_end IS NULL)) OR ((receipt_step IS NOT NULL) AND (receipt_order IS NOT NULL) AND (excerpt_start IS NOT NULL) AND (excerpt_end IS NOT NULL) AND (receipt_step > 0) AND (receipt_order > 0) AND (excerpt_start >= 0) AND (excerpt_end > excerpt_start) AND ((excerpt_end - excerpt_start) <= 320)))),
    CONSTRAINT plan_sources_picture_order_check CHECK ((picture_order > 0)),
    CONSTRAINT plan_sources_receipt_kind_check CHECK ((receipt_kind = ANY (ARRAY['calculation'::text, 'lookup'::text])))
);


--
-- Name: sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    name text NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    revoked_at timestamp with time zone,
    created_by uuid NOT NULL,
    recycled_at timestamp with time zone,
    purge_due timestamp with time zone,
    purged_at timestamp with time zone,
    originally_revoked boolean DEFAULT false NOT NULL,
    recovered_as uuid,
    shared_files_retained integer DEFAULT 0 NOT NULL,
    upload_key text,
    CONSTRAINT source_recycle_state CHECK ((((recycled_at IS NULL) = (purge_due IS NULL)) AND ((recycled_at IS NULL) OR (revoked_at IS NOT NULL)) AND ((purged_at IS NULL) OR (recycled_at IS NOT NULL))))
);


--
-- Name: changed_artifact_sources; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.changed_artifact_sources AS
 SELECT a.project_id,
    a.id AS artifact_id,
    a.current_version AS artifact_version,
    s.id AS source_id,
    ps.source_version AS pinned,
    s.current_version AS observed,
    (s.revoked_at IS NOT NULL) AS revoked,
    v.filename AS original_name,
    s.name AS current_name,
    c.id AS assessment,
    c.decision,
    c.actor,
    c.reason,
    c.feedback_id
   FROM ((((((public.artifacts a
     JOIN public.runs r ON ((r.id = a.run_id)))
     JOIN LATERAL ( SELECT plan_sources.source_id,
            plan_sources.source_version
           FROM public.plan_sources
          WHERE ((plan_sources.project_id = r.project_id) AND (plan_sources.plan_version = r.plan_version))
        UNION
         SELECT artifact_step_receipts.source_id,
            artifact_step_receipts.source_version
           FROM public.artifact_step_receipts(a.id, a.current_version) artifact_step_receipts(run_id, ordinal, request_revision, source_id, source_version, kind, excerpt_start, excerpt_end)) ps ON (true))
     JOIN public.sources s ON ((s.id = ps.source_id)))
     JOIN public.source_versions v ON (((v.source_id = s.id) AND (v.version = ps.source_version))))
     JOIN public.source_versions latest ON (((latest.source_id = s.id) AND (latest.version = s.current_version))))
     LEFT JOIN public.source_assessments c ON (((c.artifact_id = a.id) AND (c.artifact_version = a.current_version) AND (c.source_id = s.id) AND (c.observed_version = s.current_version) AND (c.revoked = (s.revoked_at IS NOT NULL)))))
  WHERE ((s.revoked_at IS NOT NULL) OR (v.object_hash <> latest.object_hash) OR (v.media_type <> latest.media_type) OR (v.extracted IS DISTINCT FROM latest.extracted));


--
-- Name: channel_attachment_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_attachment_jobs (
    id uuid NOT NULL,
    event_id text NOT NULL,
    tenant text NOT NULL,
    chat_id text NOT NULL,
    member_id uuid NOT NULL,
    binding_id uuid NOT NULL,
    service_id uuid,
    version integer,
    calls integer,
    input text NOT NULL,
    file_message_id text NOT NULL,
    file_key text NOT NULL,
    file_name text NOT NULL,
    accepted_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    next_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    await_lookup_receipt boolean DEFAULT false NOT NULL,
    await_calculation_receipt boolean DEFAULT false NOT NULL,
    receipt_run uuid,
    receipt_step integer,
    receipt_revision integer,
    receipt_kind text,
    receipt_question_revision integer,
    CONSTRAINT channel_attachment_jobs_calls_check CHECK ((calls > 0)),
    CONSTRAINT channel_attachment_jobs_check CHECK ((((service_id IS NOT NULL) AND (version IS NOT NULL) AND (calls IS NOT NULL) AND (receipt_run IS NULL) AND (receipt_step IS NULL) AND (receipt_revision IS NULL) AND (receipt_kind IS NULL)) OR ((service_id IS NULL) AND (version IS NULL) AND (calls IS NULL) AND (receipt_run IS NOT NULL) AND (receipt_step IS NOT NULL) AND (receipt_step > 0) AND (receipt_revision IS NOT NULL) AND (receipt_revision >= 0) AND (receipt_kind IS NOT NULL) AND (receipt_kind = ANY (ARRAY['lookup'::text, 'calculation'::text])) AND (NOT await_lookup_receipt) AND (NOT await_calculation_receipt)))),
    CONSTRAINT channel_attachment_jobs_receipt_question_revision_check CHECK ((receipt_question_revision > 0))
);


--
-- Name: channel_card_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_card_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    reply_id uuid NOT NULL,
    request_id uuid NOT NULL,
    project_revision integer NOT NULL,
    message_id text DEFAULT ''::text NOT NULL,
    expires_at timestamp with time zone DEFAULT (clock_timestamp() + '00:15:00'::interval) NOT NULL,
    accepted_at timestamp with time zone
);


--
-- Name: channel_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_codes (
    token_hash bytea NOT NULL,
    member_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: channel_contexts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_contexts (
    tenant text NOT NULL,
    chat_id text NOT NULL,
    member_id uuid NOT NULL,
    project_id uuid NOT NULL,
    changed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: channel_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_events (
    id text NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant text,
    message_id text
);


--
-- Name: channel_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_links (
    tenant text NOT NULL,
    open_id text NOT NULL,
    member_id uuid NOT NULL,
    binding_id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_reminders boolean DEFAULT false NOT NULL
);


--
-- Name: channel_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_proposals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant text NOT NULL,
    chat_id text NOT NULL,
    member_id uuid NOT NULL,
    service_id uuid,
    version integer,
    calls integer,
    input text NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:10:00'::interval) NOT NULL,
    origin_message_id text DEFAULT ''::text NOT NULL,
    origin_time bigint DEFAULT 0 NOT NULL,
    file_message_id text DEFAULT ''::text NOT NULL,
    file_key text DEFAULT ''::text NOT NULL,
    file_name text DEFAULT ''::text NOT NULL,
    file_time bigint DEFAULT 0 NOT NULL,
    await_lookup_receipt boolean DEFAULT false NOT NULL,
    await_calculation_receipt boolean DEFAULT false NOT NULL,
    receipt_run uuid,
    receipt_step integer,
    receipt_revision integer,
    receipt_kind text,
    receipt_question_revision integer,
    CONSTRAINT channel_proposals_calls_check CHECK ((calls > 0)),
    CONSTRAINT channel_proposals_check CHECK ((((service_id IS NOT NULL) AND (version IS NOT NULL) AND (calls IS NOT NULL) AND (receipt_run IS NULL) AND (receipt_step IS NULL) AND (receipt_revision IS NULL) AND (receipt_kind IS NULL)) OR ((service_id IS NULL) AND (version IS NULL) AND (calls IS NULL) AND (receipt_run IS NOT NULL) AND (receipt_step IS NOT NULL) AND (receipt_step > 0) AND (receipt_revision IS NOT NULL) AND (receipt_revision >= 0) AND (receipt_kind IS NOT NULL) AND (receipt_kind = ANY (ARRAY['lookup'::text, 'calculation'::text])) AND (NOT await_lookup_receipt) AND (NOT await_calculation_receipt)))),
    CONSTRAINT channel_proposals_receipt_question_revision_check CHECK ((receipt_question_revision > 0))
);


--
-- Name: channel_remote_input_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_remote_input_proposals (
    id uuid NOT NULL,
    tenant text NOT NULL,
    chat_id text NOT NULL,
    member_id uuid NOT NULL,
    binding_id uuid NOT NULL,
    context_changed_at timestamp with time zone NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    control_revision integer NOT NULL,
    input_revision integer NOT NULL,
    origin_time bigint NOT NULL,
    encrypted_body bytea,
    input_id uuid,
    expires_at timestamp with time zone DEFAULT (now() + '00:10:00'::interval) NOT NULL,
    CONSTRAINT channel_remote_input_proposals_check CHECK (((input_id IS NULL) = (encrypted_body IS NOT NULL))),
    CONSTRAINT channel_remote_input_proposals_input_revision_check CHECK ((input_revision > 0))
);


--
-- Name: channel_replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_replies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id text NOT NULL,
    message_id text NOT NULL,
    member_id uuid,
    project_id uuid,
    note text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    binding_id uuid,
    private_chat boolean DEFAULT false NOT NULL,
    suppressed_at timestamp with time zone,
    reply_kind text DEFAULT 'note'::text NOT NULL,
    argument text DEFAULT ''::text NOT NULL,
    chat_id text DEFAULT ''::text NOT NULL
);


--
-- Name: validation_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validation_reviews (
    trial_id uuid NOT NULL,
    actor uuid NOT NULL,
    passed boolean NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: validation_withdrawals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validation_withdrawals (
    trial_id uuid NOT NULL,
    actor uuid NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: validations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    revision integer NOT NULL,
    actor uuid,
    status text NOT NULL,
    evidence text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    remote_task text,
    tokens integer,
    expected text,
    input_text text,
    remote_context text,
    remote_status text,
    follow_lease uuid,
    follow_until timestamp with time zone,
    cancel_requested boolean DEFAULT false NOT NULL,
    request_key text,
    check_id uuid,
    key_generation integer,
    build_digest text,
    remote_input_revision integer DEFAULT 0 NOT NULL,
    remote_input_prompt text DEFAULT ''::text NOT NULL,
    remote_input_message text DEFAULT ''::text NOT NULL
);


--
-- Name: check_outcomes; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.check_outcomes AS
 SELECT c.id,
    c.agent_id,
    c.revision,
    c.ordinal,
    c.name,
    c.sample,
    c.expected,
    c.match_kind,
    c.reviewer,
    e.id AS evidence_id,
    e.passed,
    e.ended_at
   FROM (public.agent_checks c
     LEFT JOIN LATERAL ( SELECT v.id,
            ((v.status = 'passed'::text) AND (w.trial_id IS NULL) AND ((c.reviewer IS NULL) OR review.passed)) AS passed,
            v.ended_at
           FROM ((public.validations v
             LEFT JOIN public.validation_reviews review ON ((review.trial_id = v.id)))
             LEFT JOIN public.validation_withdrawals w ON ((w.trial_id = v.id)))
          WHERE ((v.check_id = c.id) AND ((v.status = 'failed'::text) OR ((v.status = 'passed'::text) AND ((c.reviewer IS NULL) OR (review.trial_id IS NOT NULL) OR (w.trial_id IS NOT NULL)))))
          ORDER BY v.created_at DESC, v.id DESC
         LIMIT 1) e ON (true));


--
-- Name: column_suggestion_targets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.column_suggestion_targets AS
 SELECT r.id AS run_id,
    r.control_revision,
    ca.member_id AS actor,
    p.id AS project_id,
    i.ordinal,
    i.attempt_no,
    i.input_issue,
    m.id AS resource_id,
    v.revision AS resource_revision,
    v.key_generation,
    v.encrypted_key,
    v.endpoint,
    v.model,
    v.estimate_cny,
    m.team_id,
    b.id AS budget_id
   FROM (((((((public.runs r
     JOIN public.projects p ON (((p.id = r.project_id) AND (p.plan_version = r.plan_version))))
     JOIN public.column_correction_authority ca ON ((ca.run_id = r.id)))
     JOIN public.invocations i ON (((i.run_id = r.id) AND (i.status = 'input_rejected'::text) AND (i.input_issue IS NOT NULL))))
     JOIN public.model_revisions v ON (((v.resource_id = p.planning_resource) AND (v.revision = p.planning_revision))))
     JOIN public.model_resources m ON (((m.id = v.resource_id) AND m.enabled AND (NOT m.emergency))))
     JOIN public.team_members tm ON (((tm.team_id = m.team_id) AND (tm.member_id = ca.member_id))))
     JOIN public.resource_budgets b ON ((b.model_id = m.id)))
  WHERE ((r.status = 'reconcile'::text) AND (v.operation = 'text'::text) AND (NOT v.key_blocked) AND (NOT (EXISTS ( SELECT
           FROM public.call_reviews c
          WHERE (((c.run_id = i.run_id) AND (c.ordinal = i.ordinal) AND (c.attempt_no = i.attempt_no)) AND (c.decision = 'redo'::text))))));


--
-- Name: column_suggestions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.column_suggestions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    actor uuid NOT NULL,
    control_revision integer NOT NULL,
    resource_id uuid NOT NULL,
    resource_revision integer NOT NULL,
    key_generation integer NOT NULL,
    status text DEFAULT 'submitted'::text NOT NULL,
    entries jsonb,
    tokens integer,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    deadline timestamp with time zone DEFAULT (clock_timestamp() + '00:01:40'::interval) NOT NULL,
    CONSTRAINT column_suggestions_check CHECK (((status = 'ready'::text) = (entries IS NOT NULL))),
    CONSTRAINT column_suggestions_entries_check CHECK (((entries IS NULL) OR (jsonb_typeof(entries) = 'array'::text))),
    CONSTRAINT column_suggestions_status_check CHECK ((status = ANY (ARRAY['submitted'::text, 'ready'::text, 'ambiguous'::text, 'invalid'::text, 'unknown'::text, 'stale'::text])))
);


--
-- Name: current_column_suggestions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.current_column_suggestions AS
 SELECT s.id,
    s.run_id,
    s.ordinal,
    s.attempt_no,
    s.actor,
    s.control_revision,
    s.resource_id,
    s.resource_revision,
    s.key_generation,
    s.status,
    s.entries,
    s.tokens,
    s.created_at,
    s.deadline,
        CASE
            WHEN (e.run_id IS NULL) THEN 'stale'::text
            WHEN ((s.status = 'submitted'::text) AND (s.deadline <= clock_timestamp())) THEN 'unknown'::text
            ELSE s.status
        END AS current_status
   FROM (public.column_suggestions s
     LEFT JOIN public.column_suggestion_targets e ON (((e.run_id = s.run_id) AND (e.ordinal = s.ordinal) AND (e.attempt_no = s.attempt_no) AND (e.actor = s.actor) AND (e.control_revision = s.control_revision) AND (e.resource_id = s.resource_id) AND (e.resource_revision = s.resource_revision) AND (e.key_generation = s.key_generation))));


--
-- Name: current_planning_requests; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.current_planning_requests AS
 SELECT id,
    project_id,
    actor,
    request_key,
    project_revision,
    resource_id,
    resource_revision,
    status,
    result,
    tokens,
    created_at,
    rule_pins,
        CASE
            WHEN ((status = 'ready'::text) AND (NOT public.planning_context_readable(id, actor))) THEN 'stale'::text
            ELSE status
        END AS current_status,
    input_sources,
    required_output,
    context_through,
    context_compacted
   FROM public.planning_requests q;


--
-- Name: current_source_receipt_requests; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.current_source_receipt_requests AS
 SELECT q.run_id,
    q.ordinal,
    q.reason,
    q.kind,
    q.request_revision
   FROM (public.calculation_requests q
     JOIN public.runs r ON ((r.id = q.run_id)))
  WHERE public.source_receipt_open(r.status, q.request_revision);


--
-- Name: plan_tool_choices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_tool_choices (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    ordinal integer NOT NULL,
    selector integer NOT NULL,
    alternative uuid NOT NULL,
    alternative_revision integer NOT NULL,
    CONSTRAINT plan_tool_choices_check CHECK ((selector < ordinal))
);


--
-- Name: effective_run_nodes; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.effective_run_nodes AS
 SELECT r.id AS run_id,
    n.project_id,
    n.plan_version,
    n.ordinal,
    n.lookup_phase,
        CASE
            WHEN (COALESCE(picked.manual_choice, picked.choice) = 2) THEN route.alternative
            ELSE n.agent_id
        END AS agent_id,
        CASE
            WHEN (COALESCE(picked.manual_choice, picked.choice) = 2) THEN route.alternative_revision
            ELSE n.agent_revision
        END AS agent_revision,
    route.selector,
    COALESCE(picked.manual_choice, picked.choice) AS choice
   FROM (((((public.runs r
     JOIN public.nodes n ON (((n.project_id = r.project_id) AND (n.plan_version = r.plan_version))))
     LEFT JOIN public.change_batches cb ON ((cb.run_id = r.id)))
     LEFT JOIN public.artifacts original ON ((original.id = cb.artifact_id)))
     LEFT JOIN public.plan_tool_choices route ON (((route.project_id = n.project_id) AND (route.plan_version = n.plan_version) AND (route.ordinal = n.ordinal))))
     LEFT JOIN public.run_tool_choices picked ON (((picked.run_id = COALESCE(original.run_id, r.id)) AND (picked.ordinal = n.ordinal))));


--
-- Name: step_dispatch_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.step_dispatch_waits (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    plan_version integer NOT NULL,
    agent_id uuid NOT NULL,
    agent_revision integer NOT NULL,
    wait_revision integer NOT NULL,
    reason text NOT NULL,
    note text NOT NULL,
    CONSTRAINT step_dispatch_waits_ordinal_check CHECK ((ordinal > 0)),
    CONSTRAINT step_dispatch_waits_reason_check CHECK ((reason = ANY (ARRAY['resource_denied'::text, 'verification_failed'::text, 'template_build_changed'::text, 'build_unavailable'::text, 'skill_unavailable'::text, 'remote_policy_unverified'::text, 'budget_denied'::text])))
);


--
-- Name: current_step_dispatch_waits; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.current_step_dispatch_waits AS
 SELECT w.run_id,
    w.ordinal,
    w.plan_version,
    w.agent_id,
    w.agent_revision,
    w.wait_revision,
    w.reason,
    w.note
   FROM ((public.step_dispatch_waits w
     JOIN public.runs r ON (((r.id = w.run_id) AND (r.plan_version = w.plan_version))))
     JOIN public.effective_run_nodes n ON (((n.run_id = w.run_id) AND (n.ordinal = w.ordinal) AND (n.agent_id = w.agent_id) AND (n.agent_revision = w.agent_revision))))
  WHERE (r.status = ANY (ARRAY['running'::text, 'paused'::text, 'blocked'::text, 'reconcile'::text]));


--
-- Name: delegations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delegations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_id uuid NOT NULL,
    member_id uuid NOT NULL,
    token_hash bytea NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    confirmed_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reviewer_assignment uuid,
    handoff jsonb DEFAULT '{}'::jsonb NOT NULL,
    edition integer DEFAULT 1 NOT NULL,
    partial boolean DEFAULT false NOT NULL,
    coverage jsonb,
    CONSTRAINT deliveries_check CHECK (((NOT partial) OR (coverage IS NOT NULL))),
    CONSTRAINT deliveries_edition_check CHECK ((edition > 0))
);


--
-- Name: delivery_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_items (
    delivery_id uuid NOT NULL,
    artifact_id uuid NOT NULL,
    version integer NOT NULL
);


--
-- Name: node_edges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_edges (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    ordinal integer NOT NULL,
    depends_on integer NOT NULL,
    CONSTRAINT node_edges_check CHECK (((depends_on < ordinal) AND (depends_on > 0)))
);


--
-- Name: delivery_recipient_items; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.delivery_recipient_items AS
 SELECT i.delivery_id,
    a.id AS artifact_id,
    a.ordinal,
    a.name,
    i.version,
    COALESCE(( SELECT jsonb_agg(jsonb_build_object('artifact', upstream.id, 'name', upstream.name, 'step', upstream.ordinal, 'version', pinned.version) ORDER BY upstream.ordinal) AS jsonb_agg
           FROM ((public.node_edges e
             JOIN public.artifacts upstream ON (((upstream.run_id = a.run_id) AND (upstream.ordinal = e.depends_on))))
             JOIN public.delivery_items pinned ON (((pinned.delivery_id = i.delivery_id) AND (pinned.artifact_id = upstream.id))))
          WHERE ((e.project_id = r.project_id) AND (e.plan_version = r.plan_version) AND (e.ordinal = a.ordinal))), '[]'::jsonb) AS dependencies
   FROM ((public.delivery_items i
     JOIN public.artifacts a ON ((a.id = i.artifact_id)))
     JOIN public.runs r ON ((r.id = a.run_id)));


--
-- Name: delivery_comparisons; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.delivery_comparisons AS
 SELECT d.id,
    d.edition,
    prev.id AS previous,
    ARRAY( SELECT jsonb_build_object('step', i.ordinal, 'name', i.name, 'artifact', i.artifact_id, 'from', old.version, 'to', i.version, 'bodyChanged', (v.body IS DISTINCT FROM ov.body), 'fileChanged', (((f.object_hash IS DISTINCT FROM ofile.object_hash) OR (f.filename IS DISTINCT FROM ofile.filename)) OR (f.media_type IS DISTINCT FROM ofile.media_type)), 'dependenciesChanged', (i.dependencies IS DISTINCT FROM old.dependencies)) AS jsonb_build_object
           FROM (((((public.delivery_recipient_items i
             JOIN public.delivery_recipient_items old ON (((old.delivery_id = prev.id) AND (old.artifact_id = i.artifact_id))))
             JOIN public.artifact_versions v ON (((v.artifact_id = i.artifact_id) AND (v.version = i.version))))
             JOIN public.artifact_versions ov ON (((ov.artifact_id = old.artifact_id) AND (ov.version = old.version))))
             LEFT JOIN public.artifact_files f ON (((f.artifact_id = i.artifact_id) AND (f.version = i.version))))
             LEFT JOIN public.artifact_files ofile ON (((ofile.artifact_id = old.artifact_id) AND (ofile.version = old.version))))
          WHERE ((i.delivery_id = d.id) AND (old.version <> i.version))
          ORDER BY i.ordinal) AS changes,
    ARRAY( SELECT key.key
           FROM unnest(ARRAY['purpose'::text, 'instructions'::text, 'limitations'::text]) key(key)
          WHERE ((prev.id IS NOT NULL) AND ((prev.handoff -> key.key) IS DISTINCT FROM (d.handoff -> key.key)))) AS changed_notes
   FROM (public.deliveries d
     LEFT JOIN public.deliveries prev ON (((prev.project_id = d.project_id) AND (prev.edition = (d.edition - 1)))));


--
-- Name: delivery_source_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_source_evidence (
    delivery_id uuid NOT NULL,
    source_id uuid NOT NULL,
    pinned integer NOT NULL,
    observed integer NOT NULL,
    revoked boolean NOT NULL,
    assessments jsonb NOT NULL,
    revision_inputs jsonb DEFAULT '[]'::jsonb NOT NULL,
    calculation_receipt jsonb,
    lookup_receipt jsonb,
    step_receipts jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: delivery_distribution_inputs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.delivery_distribution_inputs AS
 SELECT e.delivery_id,
    e.source_id,
    (NOT e.revoked) AS check_withdrawal
   FROM public.delivery_source_evidence e
UNION ALL
 SELECT DISTINCT i.delivery_id,
    ps.source_id,
    true AS check_withdrawal
   FROM (((public.delivery_items i
     JOIN public.artifacts a ON ((a.id = i.artifact_id)))
     JOIN public.runs r ON ((r.id = a.run_id)))
     JOIN public.plan_sources ps ON (((ps.project_id = r.project_id) AND (ps.plan_version = r.plan_version))))
  WHERE (NOT (EXISTS ( SELECT
           FROM public.delivery_source_evidence e
          WHERE ((e.delivery_id = i.delivery_id) AND (e.source_id = ps.source_id)))));


--
-- Name: delivery_item_assessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_item_assessments (
    id bigint NOT NULL,
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    item integer NOT NULL,
    run_id uuid NOT NULL,
    artifact_id uuid,
    artifact_version integer,
    state text NOT NULL,
    reason text NOT NULL,
    responsible uuid,
    continue_when text DEFAULT ''::text NOT NULL,
    reviewer uuid NOT NULL,
    reviewed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    file_evidence jsonb,
    remote_receipt_version integer,
    upstream_evidence_step integer,
    CONSTRAINT delivery_item_assessments_check CHECK (((state = 'missing'::text) OR ((artifact_id IS NOT NULL) AND (responsible IS NULL) AND (continue_when = ''::text)))),
    CONSTRAINT delivery_item_assessments_check1 CHECK (((responsible IS NULL) = (continue_when = ''::text))),
    CONSTRAINT delivery_item_assessments_check2 CHECK (((file_evidence IS NULL) OR ((artifact_id IS NOT NULL) AND (jsonb_typeof(file_evidence) = 'object'::text)))),
    CONSTRAINT delivery_item_assessments_check3 CHECK (((remote_receipt_version IS NULL) OR ((artifact_id IS NOT NULL) AND (remote_receipt_version = artifact_version)))),
    CONSTRAINT delivery_item_assessments_check4 CHECK (((upstream_evidence_step IS NULL) OR ((upstream_evidence_step > 0) AND (artifact_id IS NOT NULL)))),
    CONSTRAINT delivery_item_assessments_state_check CHECK ((state = ANY (ARRAY['covered'::text, 'missing'::text])))
);


--
-- Name: delivery_item_assessments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.delivery_item_assessments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.delivery_item_assessments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: delivery_recipient_manifests; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.delivery_recipient_manifests AS
SELECT
    NULL::uuid AS project_id,
    NULL::uuid AS id,
    NULL::uuid AS confirmed_by,
    NULL::timestamp with time zone AS created_at,
    NULL::jsonb AS handoff,
    NULL::jsonb AS items,
    NULL::boolean AS partial,
    NULL::jsonb AS coverage;


--
-- Name: delivery_revision_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_revision_requests (
    base_delivery uuid NOT NULL,
    feedback_id uuid NOT NULL,
    requested_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL
);


--
-- Name: distribution_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distribution_reviews (
    source_id uuid NOT NULL,
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    revision integer NOT NULL,
    actor uuid NOT NULL,
    decision text NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT distribution_reviews_decision_check CHECK ((decision = ANY (ARRAY['pending'::text, 'reference'::text, 'invalid'::text, 'restricted'::text]))),
    CONSTRAINT distribution_reviews_revision_check CHECK ((revision > 0))
);


--
-- Name: withdrawn_delivery_sources; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.withdrawn_delivery_sources AS
 SELECT id,
    project_id,
    created_by,
    name
   FROM public.sources s
  WHERE ((revoked_at IS NOT NULL) AND ((recycled_at IS NOT NULL) OR (EXISTS ( SELECT
           FROM public.delivery_distribution_inputs e
          WHERE ((e.source_id = s.id) AND e.check_withdrawal)))));


--
-- Name: distribution_cases; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.distribution_cases AS
 WITH scope AS (
         SELECT e.source_id,
            i.artifact_id,
            i.version
           FROM ((public.delivery_distribution_inputs e
             JOIN public.delivery_items i USING (delivery_id))
             JOIN public.withdrawn_delivery_sources s_1 ON ((s_1.id = e.source_id)))
          WHERE ((EXISTS ( SELECT
                   FROM public.delivery_source_evidence d
                  WHERE (((d.delivery_id = e.delivery_id) AND (d.source_id = e.source_id)) AND (d.step_receipts = '[]'::jsonb)))) OR (NOT (EXISTS ( SELECT
                   FROM public.delivery_source_evidence d
                  WHERE ((d.delivery_id = e.delivery_id) AND (d.source_id = e.source_id))))) OR (EXISTS ( SELECT
                   FROM public.artifact_step_receipts(i.artifact_id, i.version) p(run_id, ordinal, request_revision, source_id, source_version, kind, excerpt_start, excerpt_end)
                  WHERE (p.source_id = e.source_id))))
        UNION
         SELECT ps.source_id,
            a.id,
            a.current_version
           FROM ((((public.artifacts a
             JOIN public.projects p ON (((p.id = a.project_id) AND (p.stage = 'review'::text))))
             JOIN public.runs r ON ((r.id = a.run_id)))
             JOIN public.plan_sources ps ON (((ps.project_id = r.project_id) AND (ps.plan_version = r.plan_version))))
             JOIN public.withdrawn_delivery_sources s_1 ON ((s_1.id = ps.source_id)))
        UNION
         SELECT ps.source_id,
            a.id,
            a.current_version
           FROM (((public.artifacts a
             JOIN public.projects p ON ((p.id = a.project_id)))
             CROSS JOIN LATERAL public.artifact_step_receipts(a.id, a.current_version) ps(run_id, ordinal, request_revision, source_id, source_version, kind, excerpt_start, excerpt_end))
             JOIN public.sources s_1 ON (((s_1.id = ps.source_id) AND (s_1.revoked_at IS NOT NULL))))
          WHERE (p.stage = ANY (ARRAY['running'::text, 'paused'::text, 'blocked'::text, 'reconcile'::text, 'review'::text]))
        )
 SELECT x.source_id,
    x.artifact_id,
    x.version,
    s.project_id,
    s.created_by,
    s.name AS source_name,
    COALESCE(v.revision, 0) AS revision,
    COALESCE(v.decision, 'pending'::text) AS state,
    v.actor,
    v.reason,
    v.created_at
   FROM ((scope x
     JOIN public.sources s ON ((s.id = x.source_id)))
     LEFT JOIN LATERAL ( SELECT r.source_id,
            r.artifact_id,
            r.version,
            r.revision,
            r.actor,
            r.decision,
            r.reason,
            r.created_at
           FROM public.distribution_reviews r
          WHERE ((r.source_id = x.source_id) AND (r.artifact_id = x.artifact_id) AND (r.version = x.version))
          ORDER BY r.revision DESC
         LIMIT 1) v ON (true));


--
-- Name: project_agent_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_agent_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    revision integer NOT NULL,
    description text NOT NULL,
    requested_by uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    call_limit integer NOT NULL,
    resource_approver uuid,
    budget_approver uuid,
    revoked_at timestamp with time zone,
    generation integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_agent_grants_call_limit_check CHECK ((call_limit > 0))
);


--
-- Name: effective_project_agent_grants; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.effective_project_agent_grants AS
 SELECT id,
    project_id,
    agent_id,
    revision,
    description,
    requested_by,
    expires_at,
    call_limit,
    resource_approver,
    budget_approver,
    revoked_at,
    generation,
    created_at
   FROM public.project_agent_grants g
  WHERE ((revoked_at IS NULL) AND (expires_at > statement_timestamp()) AND (resource_approver IS NOT NULL) AND (budget_approver IS NOT NULL));


--
-- Name: plan_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_rules (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    rule_id uuid NOT NULL,
    rule_revision integer NOT NULL
);


--
-- Name: rule_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_versions (
    rule_id uuid NOT NULL,
    revision integer NOT NULL,
    body text NOT NULL,
    author uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    review_at timestamp with time zone,
    agent_scope uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    CONSTRAINT rule_versions_agent_scope_check CHECK ((array_position(agent_scope, NULL::uuid) IS NULL))
);


--
-- Name: step_rule_replacements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.step_rule_replacements (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    rule_id uuid NOT NULL,
    rule_revision integer NOT NULL,
    CONSTRAINT step_rule_replacements_ordinal_check CHECK ((ordinal > 0))
);


--
-- Name: team_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    author uuid NOT NULL,
    published_revision integer,
    disabled boolean DEFAULT false NOT NULL,
    lifecycle integer DEFAULT 1 NOT NULL,
    maintainer uuid NOT NULL,
    maintenance_vacant boolean DEFAULT false NOT NULL,
    maintenance_version integer DEFAULT 1 NOT NULL,
    proposed_owner uuid,
    proposed_by uuid,
    transfer_reason text,
    CONSTRAINT team_rules_check CHECK ((((proposed_owner IS NULL) = (proposed_by IS NULL)) AND ((proposed_owner IS NULL) = (transfer_reason IS NULL))))
);


--
-- Name: effective_run_rules; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.effective_run_rules AS
 SELECT n.run_id,
    n.ordinal,
    p.rule_id,
    v.revision AS rule_revision,
    (cardinality(original.agent_scope) > 0) AS scoped,
    ((tr.team_id = project.team_id) AND public.rule_usable(p.rule_id, v.revision, r.actor)) AS usable
   FROM ((((((((public.effective_run_nodes n
     JOIN public.runs r ON ((r.id = n.run_id)))
     JOIN public.nodes primary_node ON (((primary_node.project_id = n.project_id) AND (primary_node.plan_version = n.plan_version) AND (primary_node.ordinal = n.ordinal))))
     JOIN public.projects project ON ((project.id = r.project_id)))
     JOIN public.plan_rules p ON (((p.project_id = n.project_id) AND (p.plan_version = n.plan_version))))
     JOIN public.team_rules tr ON ((tr.id = p.rule_id)))
     JOIN public.rule_versions original ON (((original.rule_id = p.rule_id) AND (original.revision = p.rule_revision))))
     LEFT JOIN public.step_rule_replacements replacement ON (((replacement.run_id = n.run_id) AND (replacement.ordinal = n.ordinal) AND (replacement.rule_id = p.rule_id))))
     JOIN public.rule_versions v ON (((v.rule_id = p.rule_id) AND (v.revision = COALESCE(replacement.rule_revision, p.rule_revision)))))
  WHERE ((cardinality(original.agent_scope) = 0) OR (n.agent_id = ANY (original.agent_scope)) OR (primary_node.agent_id = ANY (original.agent_scope)));


--
-- Name: enterprise; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enterprise (
    id boolean DEFAULT true NOT NULL,
    name text NOT NULL,
    default_team uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT enterprise_id_check CHECK (id)
);


--
-- Name: enterprise_login_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enterprise_login_policy (
    singleton boolean DEFAULT true NOT NULL,
    issuer text DEFAULT ''::text NOT NULL,
    client_id text DEFAULT ''::text NOT NULL,
    mode text DEFAULT ''::text NOT NULL,
    emergency_member text DEFAULT ''::text NOT NULL,
    redirect_uri text DEFAULT ''::text NOT NULL,
    CONSTRAINT enterprise_login_policy_singleton_check CHECK (singleton)
);


--
-- Name: feedback_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback_events (
    feedback_id uuid NOT NULL,
    revision integer NOT NULL,
    actor uuid NOT NULL,
    action text NOT NULL,
    reason text NOT NULL,
    artifact_version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: feedback_source_quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback_source_quotes (
    feedback_id uuid NOT NULL,
    source_id uuid NOT NULL,
    version integer NOT NULL,
    start_char integer NOT NULL,
    end_char integer NOT NULL,
    text_hash text NOT NULL,
    CONSTRAINT feedback_source_quotes_check CHECK ((end_char >= start_char)),
    CONSTRAINT feedback_source_quotes_start_char_check CHECK ((start_char >= 1))
);


--
-- Name: im_binding_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.im_binding_codes (
    connection text NOT NULL,
    member_id uuid NOT NULL,
    token_hash bytea NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: im_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.im_bindings (
    connection text NOT NULL,
    external_user text NOT NULL,
    member_id uuid NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: im_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.im_events (
    connection text NOT NULL,
    event_id text NOT NULL,
    chat_id text NOT NULL,
    thread_id text NOT NULL,
    message_id text NOT NULL,
    external_user text NOT NULL,
    binding_id uuid,
    payload bytea,
    project_id uuid,
    reply_kind text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'received'::text NOT NULL,
    process_attempts integer DEFAULT 0 NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    received_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    reply_target bytea,
    reply_expires_at timestamp with time zone,
    reply_argument bytea,
    CONSTRAINT im_events_check CHECK (((state = 'received'::text) = (payload IS NOT NULL))),
    CONSTRAINT im_events_check1 CHECK (((reply_target IS NULL) OR ((reply_expires_at IS NOT NULL) AND (state = ANY (ARRAY['received'::text, 'ready'::text, 'sending'::text]))))),
    CONSTRAINT im_events_state_check CHECK ((state = ANY (ARRAY['received'::text, 'ready'::text, 'sending'::text, 'sent'::text, 'unknown'::text, 'failed'::text, 'suppressed'::text])))
);


--
-- Name: im_service_launches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.im_service_launches (
    id uuid NOT NULL,
    binding_id uuid NOT NULL,
    chat_id text NOT NULL,
    thread_id text NOT NULL,
    service_id uuid NOT NULL,
    version integer NOT NULL,
    routing_revision integer NOT NULL,
    calls integer NOT NULL,
    goal bytea,
    expires_at timestamp with time zone DEFAULT (clock_timestamp() + '00:10:00'::interval) NOT NULL,
    run_id uuid,
    accepted_at timestamp with time zone,
    CONSTRAINT im_service_launches_calls_check CHECK ((calls > 0)),
    CONSTRAINT im_service_launches_check CHECK ((((run_id IS NULL) AND (accepted_at IS NULL) AND (goal IS NOT NULL)) OR ((run_id IS NOT NULL) AND (accepted_at IS NOT NULL) AND (goal IS NULL))))
);


--
-- Name: im_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.im_threads (
    binding_id uuid NOT NULL,
    chat_id text NOT NULL,
    thread_id text NOT NULL,
    project_id uuid NOT NULL
);


--
-- Name: invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invites (
    token_hash bytea NOT NULL,
    team_id uuid NOT NULL,
    issued_by uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_by uuid
);


--
-- Name: invocation_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invocation_files (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    object_hash text NOT NULL,
    filename text NOT NULL,
    media_type text NOT NULL
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    reviewer uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: review_actions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.review_actions AS
 WITH review_projects AS NOT MATERIALIZED (
         SELECT projects.id,
            projects.owner,
            projects.team_id,
            projects.final_reviewer,
            projects.revision,
            projects.plan_version,
            COALESCE(projects.review_started_at, projects.updated_at) AS started
           FROM public.projects
          WHERE (projects.stage = 'review'::text)
        ), coverage AS NOT MATERIALIZED (
         SELECT p_1.id,
            projection.coverage,
            public.project_delivery_mode(projection.coverage) AS mode
           FROM (review_projects p_1
             CROSS JOIN LATERAL ( SELECT public.project_delivery_coverage(p_1.id, p_1.plan_version) AS coverage) projection)
        ), items AS NOT MATERIALIZED (
         SELECT a.id,
            a.project_id,
            a.name,
            a.ordinal,
            a.current_version,
            v.created_at,
            r.created_at AS reviewed,
            ((r.reviewer IS NOT NULL) AND (NOT public.source_check_needed(a.id))) AS approved,
            public.takeover_review_needed(a.project_id, a.id, a.current_version) AS takeover,
            (EXISTS ( SELECT
                   FROM public.feedback f
                  WHERE ((f.artifact_id = a.id) AND (f.state = ANY (ARRAY['required'::text, 'investigate'::text, 'verification'::text]))))) AS blocked
           FROM (((review_projects p_1
             JOIN public.artifacts a ON ((a.project_id = p_1.id)))
             JOIN public.artifact_versions v ON (((v.artifact_id = a.id) AND (v.version = a.current_version))))
             LEFT JOIN public.reviews r ON (((r.artifact_id = a.id) AND (r.version = a.current_version))))
        ), actions AS (
         SELECT i.project_id,
            ((('review:'::text || i.id) || ':'::text) || i.current_version) AS action_key,
            'review'::text AS kind,
            i.id AS subject,
            i.name,
            i.current_version AS version,
            0 AS revision,
            i.ordinal,
            ''::text AS "position",
            GREATEST(i.created_at, p_1.started) AS opened,
                CASE
                    WHEN (i.approved AND i.takeover) THEN p_1.final_reviewer
                    ELSE NULL::uuid
                END AS assigned
           FROM (items i
             JOIN review_projects p_1 ON ((p_1.id = i.project_id)))
          WHERE (((NOT i.approved) OR i.takeover) AND (NOT i.blocked) AND public.artifact_rule_draft_readable(i.id, i.current_version))
        UNION ALL
         SELECT i.project_id,
            ((((('feedback:'::text || f.id) || ':'::text) || COALESCE(e.revision, 1)) || ':'::text) || i.current_version),
            f.state,
            f.id,
            i.name,
            i.current_version,
            f.revision,
            i.ordinal,
            "left"(f."position", 80) AS "left",
            GREATEST(p_1.started, i.created_at, COALESCE(e.created_at, f.created_at)) AS "greatest",
            f.reviewer
           FROM (((items i
             JOIN public.feedback f ON ((f.artifact_id = i.id)))
             JOIN review_projects p_1 ON ((p_1.id = i.project_id)))
             LEFT JOIN LATERAL ( SELECT feedback_events.revision,
                    feedback_events.created_at
                   FROM public.feedback_events
                  WHERE ((feedback_events.feedback_id = f.id) AND (feedback_events.action <> 'transfer'::text))
                  ORDER BY feedback_events.revision DESC
                 LIMIT 1) e ON (true))
          WHERE (f.state = ANY (ARRAY['suggested'::text, 'required'::text, 'investigate'::text, 'verification'::text]))
        UNION ALL
         SELECT p_1.id,
            ((('coverage:'::text || p_1.id) || ':'::text) || p_1.plan_version),
            'coverage'::text,
            p_1.id,
            '核对必交项和缺项安排'::text,
            0,
            p_1.revision,
            0,
            ''::text,
            p_1.started,
            NULL::uuid AS uuid
           FROM (review_projects p_1
             JOIN coverage c USING (id))
          WHERE (c.mode = 'coverage'::text)
        UNION ALL
         SELECT p_1.id,
            ((('deliver:'::text || p_1.id) || ':'::text) || md5(string_agg(((i.id || ':'::text) || i.current_version), ','::text ORDER BY i.id))),
            'deliver'::text,
            p_1.id,
            ''::text,
            0,
            p_1.revision,
            0,
            ''::text,
            GREATEST(p_1.started, max(i.reviewed)) AS "greatest",
            p_1.final_reviewer
           FROM ((review_projects p_1
             JOIN items i ON ((i.project_id = p_1.id)))
             JOIN coverage c ON ((c.id = p_1.id)))
          WHERE ((c.mode = 'full'::text) OR ((c.mode = 'partial'::text) AND (c.coverage @> jsonb_build_object('items', jsonb_build_array(jsonb_build_object('artifact', i.id, 'state', 'covered'))))))
          GROUP BY p_1.id, p_1.revision, p_1.started, p_1.final_reviewer
         HAVING (bool_and((i.approved AND (NOT i.takeover) AND (NOT i.blocked))) AND (NOT public.candidate_distribution_held(p_1.id)) AND (NOT (EXISTS ( SELECT
                   FROM public.changed_artifact_sources s
                  WHERE ((s.project_id = p_1.id) AND (s.decision IS DISTINCT FROM 'retain'::text))))))
        )
 SELECT t.project_id,
    t.action_key,
    t.kind,
    t.subject,
    t.name,
    t.version,
    t.revision,
    t.ordinal,
    t."position",
    t.opened,
    t.assigned,
    p.team_id,
    p.owner,
    ARRAY( SELECT pm.member_id
           FROM (public.project_members pm
             JOIN public.members m ON ((m.id = pm.member_id)))
          WHERE ((pm.project_id = p.id) AND m.enabled AND (m.kind = 'person'::text) AND (pm.can_review OR (t.kind = 'deliver'::text)) AND ((t.assigned IS NULL) OR (t.assigned = pm.member_id)))
          ORDER BY pm.member_id) AS recipients
   FROM (actions t
     JOIN review_projects p ON ((p.id = t.project_id)));


--
-- Name: review_clocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_clocks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action_key text NOT NULL,
    project_id uuid NOT NULL,
    opened_at timestamp with time zone NOT NULL,
    original_due timestamp with time zone NOT NULL,
    due_at timestamp with time zone NOT NULL,
    lead_hours integer NOT NULL,
    escalation_hours integer NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    closed_at timestamp with time zone
);


--
-- Name: live_review_clocks; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.live_review_clocks AS
 SELECT a.project_id,
    a.action_key,
    a.kind,
    a.subject,
    a.name,
    a.version,
    a.revision,
    a.ordinal,
    a."position",
    a.opened,
    a.assigned,
    a.team_id,
    a.owner,
    a.recipients,
    c.id AS clock,
    c.opened_at,
    c.original_due,
    c.due_at,
    c.revision AS clock_revision,
    (now() >= (c.due_at - make_interval(hours => c.lead_hours))) AS due,
    (now() >= (c.due_at + make_interval(hours => c.escalation_hours))) AS overdue
   FROM (public.review_actions a
     JOIN public.review_clocks c ON (((c.action_key = a.action_key) AND (c.closed_at IS NULL))));


--
-- Name: local_action_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_action_observations (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    control_revision integer NOT NULL,
    payload bytea,
    outcome text NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL,
    consumed_at timestamp with time zone,
    discarded_at timestamp with time zone,
    action_round integer DEFAULT 1 NOT NULL,
    CONSTRAINT local_action_observations_action_round_check CHECK (((action_round >= 1) AND (action_round <= 3))),
    CONSTRAINT local_action_observations_check CHECK ((num_nonnulls(payload, consumed_at, discarded_at) = 1)),
    CONSTRAINT local_action_observations_control_revision_check CHECK ((control_revision > 0))
);


--
-- Name: lookup_index_wait_no; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lookup_index_wait_no
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lookup_index_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_index_waits (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    plan_version integer NOT NULL,
    active boolean DEFAULT false NOT NULL,
    deadline timestamp with time zone NOT NULL,
    next_check_at timestamp with time zone NOT NULL,
    observation text,
    step_wait_revision integer,
    wake_pending boolean DEFAULT false NOT NULL,
    expiry_announced boolean DEFAULT false NOT NULL,
    CONSTRAINT lookup_index_waits_check CHECK (((NOT active) OR (observation IS NULL))),
    CONSTRAINT lookup_index_waits_check1 CHECK (((NOT wake_pending) OR ((step_wait_revision IS NOT NULL) AND (NOT active) AND (observation IS NULL)))),
    CONSTRAINT lookup_index_waits_ordinal_check CHECK ((ordinal > 0)),
    CONSTRAINT lookup_index_waits_step_wait_revision_check CHECK ((step_wait_revision > 0))
);


--
-- Name: lookup_question_handoffs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_question_handoffs (
    run_id uuid NOT NULL,
    target integer NOT NULL,
    parent integer NOT NULL,
    parent_attempt integer NOT NULL,
    plan_version integer NOT NULL,
    question text,
    citations jsonb NOT NULL,
    CONSTRAINT lookup_question_handoffs_check CHECK (((parent > 0) AND (parent < target))),
    CONSTRAINT lookup_question_handoffs_question_check CHECK (((char_length(question) >= 1) AND (char_length(question) <= 320))),
    CONSTRAINT lookup_question_handoffs_target_check CHECK ((target > 0))
);


--
-- Name: lookup_question_availability; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.lookup_question_availability AS
 SELECT q.run_id,
    q.target,
    q.parent,
    q.parent_attempt,
    q.plan_version,
    q.question,
    q.citations,
    ((q.plan_version = r.plan_version) AND (i.status = 'completed'::text) AND (i.attempt_no = q.parent_attempt) AND public.run_working_set_usable(q.run_id, q.parent, q.parent_attempt)) AS usable
   FROM ((public.lookup_question_handoffs q
     JOIN public.runs r ON ((r.id = q.run_id)))
     JOIN public.invocations i ON (((i.run_id = q.run_id) AND (i.ordinal = q.parent))));


--
-- Name: lookup_turns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_turns (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    plan_version integer NOT NULL,
    decision bytea,
    outcome text,
    action_kind text,
    agent_id uuid,
    agent_revision integer,
    decided_control_revision integer,
    refinement_evidence jsonb,
    observe_before_commit boolean DEFAULT false NOT NULL,
    action_count integer DEFAULT 1 NOT NULL,
    action_cursor integer DEFAULT 1 NOT NULL,
    initial_evidence jsonb,
    CONSTRAINT lookup_turns_action_count_check CHECK (((action_count >= 1) AND (action_count <= 3))),
    CONSTRAINT lookup_turns_attempt_no_check CHECK ((attempt_no > 0)),
    CONSTRAINT lookup_turns_check CHECK (((decision IS NULL) <> (outcome IS NULL))),
    CONSTRAINT lookup_turns_check1 CHECK ((((action_kind IS NULL) AND (agent_id IS NULL) AND (agent_revision IS NULL) AND (decided_control_revision IS NULL)) OR ((action_kind = ANY (ARRAY['refine_lookup'::text, 'calculate_amounts'::text])) AND (action_kind IS NOT NULL) AND (agent_id IS NOT NULL) AND (agent_revision IS NOT NULL) AND (decided_control_revision IS NOT NULL)))),
    CONSTRAINT lookup_turns_check2 CHECK (((action_cursor >= 1) AND (action_cursor <= action_count))),
    CONSTRAINT lookup_turns_check3 CHECK (((action_count = 1) OR ((NOT (action_kind IS DISTINCT FROM 'refine_lookup'::text)) AND observe_before_commit)))
);


--
-- Name: maintained_rules; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.maintained_rules AS
 SELECT id,
    team_id,
    maintainer AS owner,
    maintenance_vacant,
    maintenance_version,
    proposed_owner,
    proposed_by,
    transfer_reason,
    false AS removed
   FROM public.team_rules;


--
-- Name: model_probes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_probes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    resource_id uuid NOT NULL,
    resource_revision integer NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    status text DEFAULT 'submitted'::text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    tokens integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    candidate uuid,
    key_generation integer,
    resource_lifecycle integer,
    CONSTRAINT model_probes_status_check CHECK ((status = ANY (ARRAY['submitted'::text, 'passed'::text, 'rejected'::text, 'invalid'::text, 'unknown'::text])))
);


--
-- Name: management_call_costs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.management_call_costs AS
 WITH operations AS (
         SELECT i.started_at AS at,
            r.actor,
            i.tokens,
            i.op_key,
            'execution'::text AS operation
           FROM (public.call_attempts i
             JOIN public.runs r ON ((r.id = i.run_id)))
        UNION ALL
         SELECT model_probes.created_at,
            model_probes.actor,
            model_probes.tokens,
            ('connection/'::text || model_probes.id),
            'connection'::text
           FROM public.model_probes
        UNION ALL
         SELECT planning_requests.created_at,
            planning_requests.actor,
            planning_requests.tokens,
            ('planning/'::text || planning_requests.id),
            'planning'::text
           FROM public.planning_requests
        UNION ALL
         SELECT validations.created_at,
            validations.actor,
            validations.tokens,
            ('validation/'::text || validations.id),
            'validation'::text
           FROM public.validations
        UNION ALL
         SELECT column_suggestions.created_at,
            column_suggestions.actor,
            column_suggestions.tokens,
            ('column-suggestion/'::text || column_suggestions.id),
            'column_suggestion'::text
           FROM public.column_suggestions
        )
 SELECT o.at,
    o.actor,
    o.tokens,
    s.team_id,
    s.originating_department AS department_id,
    ((s.id IS NULL) OR (NOT s.settled)) AS pending,
    ((s.id IS NULL) OR ((s.reserved_cny IS NULL) AND (NOT s.settled))) AS unknown,
        CASE
            WHEN (NOT s.settled) THEN GREATEST((s.reserved_cny - s.amount_cny), (0)::numeric)
            ELSE NULL::numeric
        END AS reserved,
    s.amount_cny AS recorded,
    o.op_key,
    o.operation,
    s.id AS spend_id
   FROM (operations o
     LEFT JOIN public.spend s ON ((s.op_key = o.op_key)));


--
-- Name: management_exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    grant_id uuid NOT NULL,
    request_key uuid NOT NULL,
    request_hash bytea NOT NULL,
    include_costs boolean NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    payload jsonb,
    cost_lines boolean DEFAULT false NOT NULL,
    CONSTRAINT management_exports_check CHECK (((NOT cost_lines) OR include_costs))
);


--
-- Name: management_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    team_id uuid,
    department_id uuid,
    include_costs boolean NOT NULL,
    granted_by uuid NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    reason text NOT NULL,
    revoked_at timestamp with time zone,
    revoked_reason text,
    allow_export boolean DEFAULT false NOT NULL,
    export_revision integer DEFAULT 1 NOT NULL,
    allow_details boolean DEFAULT false NOT NULL,
    detail_costs boolean DEFAULT false NOT NULL,
    detail_revision integer DEFAULT 1 NOT NULL,
    enterprise_id boolean,
    financial_export boolean DEFAULT false NOT NULL,
    CONSTRAINT management_grants_check CHECK (((NOT financial_export) OR include_costs)),
    CONSTRAINT management_grants_check1 CHECK (((revoked_at IS NULL) = (revoked_reason IS NULL))),
    CONSTRAINT management_grants_check2 CHECK (((NOT detail_costs) OR allow_details)),
    CONSTRAINT management_grants_detail_revision_check CHECK ((detail_revision > 0)),
    CONSTRAINT management_grants_export_revision_check CHECK ((export_revision > 0)),
    CONSTRAINT management_one_scope CHECK ((num_nonnulls(team_id, department_id, enterprise_id) = 1))
);


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    budget_owner uuid,
    trace_days integer DEFAULT 30 NOT NULL,
    trace_manager uuid,
    trace_policy_revision integer DEFAULT 1 NOT NULL,
    CONSTRAINT teams_trace_days_check CHECK (((trace_days >= 1) AND (trace_days <= 365)))
);


--
-- Name: management_grant_names; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.management_grant_names AS
 SELECT g.id,
    COALESCE(t.name, d.name, e.name) AS name,
        CASE
            WHEN (g.enterprise_id IS TRUE) THEN 'enterprise'::text
            WHEN (g.team_id IS NOT NULL) THEN 'team'::text
            ELSE 'department'::text
        END AS kind
   FROM (((public.management_grants g
     LEFT JOIN public.teams t ON ((g.team_id = t.id)))
     LEFT JOIN public.departments d ON ((g.department_id = d.id)))
     LEFT JOIN public.enterprise e ON ((g.enterprise_id = e.id)));


--
-- Name: management_outcome_events; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.management_outcome_events AS
 SELECT r.created_at AS at,
    r.actor,
    p.team_id,
    p.originating_department AS department_id,
    'run'::text AS kind,
    r.status
   FROM (public.runs r
     JOIN public.projects p ON ((p.id = r.project_id)))
UNION ALL
 SELECT v.ended_at AS at,
    v.actor,
    a.team_id,
    s.originating_department AS department_id,
    'check'::text AS kind,
    NULL::text AS status
   FROM ((public.validations v
     JOIN public.agents a ON ((a.id = v.agent_id)))
     LEFT JOIN public.spend s ON ((s.op_key = ('validation/'::text || v.id))))
  WHERE ((v.check_id IS NOT NULL) AND (v.status = 'passed'::text) AND (v.ended_at IS NOT NULL))
UNION ALL
 SELECT v.created_at AS at,
    p.owner AS actor,
    p.team_id,
    p.originating_department AS department_id,
    'review'::text AS kind,
    NULL::text AS status
   FROM ((public.reviews v
     JOIN public.artifacts a ON ((a.id = v.artifact_id)))
     JOIN public.projects p ON ((p.id = a.project_id)))
UNION ALL
 SELECT v.at,
    p.owner AS actor,
    p.team_id,
    p.originating_department AS department_id,
    'adoption'::text AS kind,
    NULL::text AS status
   FROM (public.answer_adoptions v
     JOIN public.projects p ON ((p.id = v.project_id)))
UNION ALL
 SELECT d.created_at AS at,
    p.owner AS actor,
    p.team_id,
    p.originating_department AS department_id,
    'delivery'::text AS kind,
    NULL::text AS status
   FROM (public.deliveries d
     JOIN public.projects p ON ((p.id = d.project_id)));


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    seq bigint NOT NULL,
    project_id uuid NOT NULL,
    author uuid,
    kind text NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    planning_request uuid
);


--
-- Name: messages_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.messages ALTER COLUMN seq ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.messages_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: model_key_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_key_candidates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    resource_id uuid NOT NULL,
    resource_revision integer NOT NULL,
    base_generation integer NOT NULL,
    encrypted_key bytea,
    created_by uuid NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    closed_at timestamp with time zone,
    CONSTRAINT model_key_candidates_check CHECK (((state = 'pending'::text) = (encrypted_key IS NOT NULL))),
    CONSTRAINT model_key_candidates_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'applied'::text, 'discarded'::text])))
);


--
-- Name: model_probe_receipts; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.model_probe_receipts AS
 SELECT id,
    team_id,
    resource_id,
    resource_revision,
    actor,
    request_key,
    status,
    detail,
    tokens,
    created_at,
    ended_at,
        CASE
            WHEN ((status = 'submitted'::text) AND (created_at < (now() - '00:01:30'::interval))) THEN 'unknown'::text
            ELSE status
        END AS current_status,
    candidate,
    key_generation,
    resource_lifecycle
   FROM public.model_probes p;


--
-- Name: model_replacement_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_replacement_agents (
    batch_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    original integer NOT NULL,
    draft integer NOT NULL,
    activated_at timestamp with time zone,
    base_generation bigint NOT NULL,
    adoption_generation bigint,
    rollback_at timestamp with time zone,
    rollback_actor uuid,
    rollback_reason text,
    CONSTRAINT model_replacement_agents_check CHECK ((((rollback_at IS NULL) = (rollback_actor IS NULL)) AND ((rollback_at IS NULL) = (rollback_reason IS NULL)))),
    CONSTRAINT model_replacement_agents_check1 CHECK ((draft > original))
);


--
-- Name: model_replacements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_replacements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_id uuid NOT NULL,
    source_revision integer NOT NULL,
    target_id uuid NOT NULL,
    target_revision integer NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    request_hash bytea NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT model_replacements_check CHECK (((source_id <> target_id) OR (source_revision <> target_revision)))
);


--
-- Name: objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.objects (
    hash text NOT NULL,
    size_bytes bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT objects_size_bytes_check CHECK ((size_bytes >= 0))
);


--
-- Name: oidc_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_bindings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    issuer text NOT NULL,
    client_id text NOT NULL,
    subject text NOT NULL,
    member_id uuid NOT NULL,
    bound_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: oidc_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_flows (
    state_hash bytea NOT NULL,
    browser_hash bytea NOT NULL,
    nonce text NOT NULL,
    verifier text NOT NULL,
    issuer text NOT NULL,
    client_id text NOT NULL,
    redirect_uri text NOT NULL,
    intent text NOT NULL,
    binding_session bytea,
    invite_hash bytea,
    email text,
    display_name text,
    password_hash text,
    expires_at timestamp with time zone DEFAULT (now() + '00:05:00'::interval) NOT NULL,
    CONSTRAINT oidc_flows_check CHECK (((intent = 'bind'::text) = (binding_session IS NOT NULL))),
    CONSTRAINT oidc_flows_check1 CHECK (((intent = 'enroll'::text) = ((invite_hash IS NOT NULL) AND (email IS NOT NULL) AND (display_name IS NOT NULL) AND (password_hash IS NOT NULL)))),
    CONSTRAINT oidc_flows_intent_check CHECK ((intent = ANY (ARRAY['login'::text, 'bind'::text, 'enroll'::text])))
);


--
-- Name: outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox (
    run_id uuid NOT NULL,
    sent_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    next_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pending_column_reconfirmations; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.pending_column_reconfirmations AS
 SELECT v.run_id,
    v.ordinal,
    v.attempt_no,
    v.control_id,
    v.input_mapping
   FROM ((public.active_call_redos v
     JOIN public.invocations i ON (((i.run_id = v.run_id) AND (i.ordinal = v.ordinal) AND (i.attempt_no = v.attempt_no))))
     JOIN public.runs r ON ((r.id = v.run_id)))
  WHERE ((v.input_mapping IS NOT NULL) AND (NOT v.authority_current) AND (i.status = 'input_rejected'::text) AND (i.input_issue IS NOT NULL) AND (r.status = ANY (ARRAY['running'::text, 'reconcile'::text, 'blocked'::text, 'paused'::text])));


--
-- Name: plan_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_preferences (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    preference_id uuid NOT NULL,
    revision integer NOT NULL
);


--
-- Name: plan_scoped_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_scoped_preferences (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    preference_id uuid NOT NULL,
    revision integer NOT NULL,
    agent_scope uuid NOT NULL
);


--
-- Name: plan_bound_preferences; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.plan_bound_preferences AS
 SELECT plan_preferences.project_id,
    plan_preferences.plan_version,
    plan_preferences.preference_id,
    plan_preferences.revision,
    NULL::uuid AS agent_scope
   FROM public.plan_preferences
UNION ALL
 SELECT plan_scoped_preferences.project_id,
    plan_scoped_preferences.plan_version,
    plan_scoped_preferences.preference_id,
    plan_scoped_preferences.revision,
    plan_scoped_preferences.agent_scope
   FROM public.plan_scoped_preferences;


--
-- Name: plan_delivery_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_delivery_contracts (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    allow_partial boolean NOT NULL
);


--
-- Name: plan_delivery_requirements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_delivery_requirements (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    item integer NOT NULL,
    ordinal integer NOT NULL,
    label text NOT NULL,
    CONSTRAINT plan_delivery_requirements_item_check CHECK ((item > 0))
);


--
-- Name: plan_workflow_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_workflow_templates (
    project_id uuid NOT NULL,
    plan_version integer NOT NULL,
    template_id uuid NOT NULL,
    template_version integer NOT NULL
);


--
-- Name: planning_context_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planning_context_messages (
    request_id uuid NOT NULL,
    message_seq bigint NOT NULL,
    body_bytes integer NOT NULL,
    body_start integer DEFAULT 0 NOT NULL,
    body_hash bytea,
    recalled boolean DEFAULT false NOT NULL,
    CONSTRAINT planning_context_messages_body_bytes_check CHECK ((body_bytes >= 0)),
    CONSTRAINT planning_context_messages_body_hash_check CHECK ((octet_length(body_hash) = 32)),
    CONSTRAINT planning_context_messages_body_start_check CHECK ((body_start >= 0)),
    CONSTRAINT planning_context_messages_check CHECK (((NOT recalled) OR ((body_hash IS NOT NULL) AND (body_bytes > 0))))
);


--
-- Name: planning_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planning_defaults (
    team_id uuid NOT NULL,
    resource_id uuid NOT NULL,
    resource_revision integer NOT NULL,
    revision integer NOT NULL,
    changed_by uuid NOT NULL
);


--
-- Name: plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plans (
    project_id uuid NOT NULL,
    version integer NOT NULL,
    brief text NOT NULL,
    confirmed_by uuid,
    suggestion_id uuid
);


--
-- Name: preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    body text,
    revision integer DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    deleted_at timestamp with time zone,
    review_at timestamp with time zone DEFAULT (now() + '90 days'::interval) NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '365 days'::interval) NOT NULL,
    lifecycle_revision integer DEFAULT 1 NOT NULL,
    departure_guard boolean DEFAULT false NOT NULL,
    purged_at timestamp with time zone,
    agent_scope uuid
);


--
-- Name: preference_lifecycle; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.preference_lifecycle AS
 SELECT id,
    member_id,
    body,
    revision,
    enabled,
    deleted_at,
    review_at,
    expires_at,
    lifecycle_revision,
    departure_guard,
    purged_at,
        CASE
            WHEN ((purged_at IS NOT NULL) OR (body IS NULL)) THEN 'purged'::text
            WHEN departure_guard THEN 'departed'::text
            WHEN (deleted_at IS NOT NULL) THEN 'deleted'::text
            WHEN (expires_at <= now()) THEN 'expired'::text
            WHEN (NOT enabled) THEN 'disabled'::text
            ELSE 'active'::text
        END AS state,
    (LEAST(deleted_at, expires_at) + '30 days'::interval) AS purge_due
   FROM public.preferences p;


--
-- Name: project_agent_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_agent_calls (
    op_key text NOT NULL,
    grant_id uuid NOT NULL
);


--
-- Name: project_budget_status; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.project_budget_status AS
 SELECT b.project_id,
    b.limit_cny,
    b.warning_percent,
    b.revision,
    s.used,
    COALESCE((s.used >= ((b.limit_cny * (b.warning_percent)::numeric) / (100)::numeric)), false) AS warning,
    COALESCE((s.used >= b.limit_cny), false) AS exhausted
   FROM (public.project_budgets b
     CROSS JOIN LATERAL ( SELECT COALESCE(sum((spend.amount_cny +
                CASE
                    WHEN spend.settled THEN (0)::numeric
                    ELSE GREATEST((COALESCE(spend.reserved_cny, (0)::numeric) - spend.amount_cny), (0)::numeric)
                END)), (0)::numeric) AS used
           FROM public.spend
          WHERE (spend.project_id = b.project_id)) s);


--
-- Name: project_feedback_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_feedback_submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    author uuid NOT NULL,
    request_key text NOT NULL,
    fingerprint bytea NOT NULL,
    original text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_session_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_session_events (
    project_id uuid NOT NULL,
    seq bigint NOT NULL,
    run_id uuid,
    draft_seq bigint,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT project_session_events_check CHECK (((run_id IS NULL) = (draft_seq IS NULL)))
);


--
-- Name: project_session_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_session_heads (
    project_id uuid NOT NULL,
    seq bigint NOT NULL,
    last_change_tx bigint
);


--
-- Name: workflow_template_adoptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_template_adoptions (
    project_id uuid NOT NULL,
    template_id uuid NOT NULL,
    from_version integer NOT NULL,
    to_version integer NOT NULL,
    previous_plan_version integer NOT NULL,
    plan_version integer NOT NULL,
    project_revision integer NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    request_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workflow_template_adoptions_check CHECK ((to_version > from_version)),
    CONSTRAINT workflow_template_adoptions_check1 CHECK ((plan_version > previous_plan_version)),
    CONSTRAINT workflow_template_adoptions_previous_plan_version_check CHECK ((previous_plan_version >= 0))
);


--
-- Name: workflow_template_uses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_template_uses (
    project_id uuid NOT NULL,
    template_id uuid NOT NULL,
    version integer NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    request_hash bytea NOT NULL
);


--
-- Name: project_workflow_template_binding; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.project_workflow_template_binding AS
 SELECT u.project_id,
    u.template_id,
    COALESCE(a.to_version, u.version) AS version
   FROM (public.workflow_template_uses u
     LEFT JOIN LATERAL ( SELECT workflow_template_adoptions.to_version
           FROM public.workflow_template_adoptions
          WHERE (workflow_template_adoptions.project_id = u.project_id)
          ORDER BY workflow_template_adoptions.project_revision DESC
         LIMIT 1) a ON (true));


--
-- Name: receipt_wakes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipt_wakes (
    run_id uuid NOT NULL
);


--
-- Name: remote_completion_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remote_completion_evidence (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    agent_id uuid NOT NULL,
    agent_revision integer NOT NULL,
    task text NOT NULL,
    way text NOT NULL,
    input_id uuid,
    body_digest text NOT NULL,
    observed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT remote_completion_evidence_body_digest_check CHECK ((body_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT remote_completion_evidence_check CHECK (((way = 'supplement'::text) = (input_id IS NOT NULL))),
    CONSTRAINT remote_completion_evidence_task_check CHECK (((octet_length(task) >= 1) AND (octet_length(task) <= 512))),
    CONSTRAINT remote_completion_evidence_way_check CHECK ((way = ANY (ARRAY['submit'::text, 'query'::text, 'supplement'::text])))
);


--
-- Name: remote_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remote_jobs (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    phase text NOT NULL,
    check_window_seconds integer DEFAULT 900 NOT NULL,
    deadline timestamp with time zone NOT NULL,
    next_at timestamp with time zone DEFAULT now() NOT NULL,
    checks integer DEFAULT 0 NOT NULL,
    consecutive_errors integer DEFAULT 0 NOT NULL,
    cancel_attempted boolean DEFAULT false NOT NULL,
    wake boolean DEFAULT false NOT NULL,
    lease uuid,
    lease_until timestamp with time zone,
    detail text DEFAULT 'remote_pending'::text NOT NULL,
    input_revision integer DEFAULT 0 NOT NULL,
    input_prompt text DEFAULT ''::text NOT NULL,
    input_message text DEFAULT ''::text NOT NULL,
    CONSTRAINT remote_jobs_phase_check CHECK ((phase = ANY (ARRAY['checking'::text, 'manual'::text, 'finished'::text])))
);


--
-- Name: remote_task_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remote_task_inputs (
    id uuid NOT NULL,
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    input_revision integer NOT NULL,
    attempt_no integer NOT NULL,
    control_revision integer NOT NULL,
    actor uuid NOT NULL,
    task_id text NOT NULL,
    context_id text NOT NULL,
    request_key text NOT NULL,
    signature bytea NOT NULL,
    encrypted_body bytea,
    state text DEFAULT 'queued'::text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    claim_until timestamp with time zone,
    decided_at timestamp with time zone,
    channel_binding_id uuid,
    CONSTRAINT remote_task_inputs_check CHECK (((state = 'queued'::text) = (encrypted_body IS NOT NULL))),
    CONSTRAINT remote_task_inputs_check1 CHECK (((state = 'submitted'::text) = (claim_until IS NOT NULL))),
    CONSTRAINT remote_task_inputs_input_revision_check CHECK ((input_revision > 0)),
    CONSTRAINT remote_task_inputs_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'submitted'::text, 'received'::text, 'uncertain'::text, 'rejected'::text])))
);


--
-- Name: remote_trial_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remote_trial_inputs (
    id uuid NOT NULL,
    trial_id uuid NOT NULL,
    input_revision integer NOT NULL,
    signature bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT remote_trial_inputs_input_revision_check CHECK ((input_revision > 0))
);


--
-- Name: remote_trial_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remote_trial_observations (
    id bigint NOT NULL,
    trial_id uuid NOT NULL,
    operation text NOT NULL,
    outcome text NOT NULL,
    remote_state text,
    observed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT remote_trial_observations_operation_check CHECK ((operation = ANY (ARRAY['send'::text, 'query'::text, 'cancel'::text, 'supplement'::text]))),
    CONSTRAINT remote_trial_observations_outcome_check CHECK ((outcome = ANY (ARRAY['text'::text, 'state'::text, 'unconfirmed'::text])))
);


--
-- Name: remote_trial_observations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.remote_trial_observations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.remote_trial_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: review_notification_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_notification_items (
    batch uuid NOT NULL,
    clock uuid NOT NULL,
    clock_revision integer NOT NULL,
    phase text NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT review_notification_items_phase_check CHECK ((phase = ANY (ARRAY['initial'::text, 'due'::text, 'escalated'::text, 'unassigned'::text])))
);


--
-- Name: review_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant text NOT NULL,
    binding uuid NOT NULL,
    recipient uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    first_attempt timestamp with time zone,
    next_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    accepted_at timestamp with time zone,
    retry_of uuid,
    CONSTRAINT review_notifications_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'accepted'::text, 'failed'::text, 'obsolete'::text])))
);


--
-- Name: review_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_policies (
    team_id uuid,
    project_id uuid,
    hours integer NOT NULL,
    lead_hours integer NOT NULL,
    escalation_hours integer NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    CONSTRAINT review_policies_check CHECK (((lead_hours >= 0) AND (lead_hours < hours))),
    CONSTRAINT review_policies_check1 CHECK ((num_nonnulls(team_id, project_id) = 1)),
    CONSTRAINT review_policies_escalation_hours_check CHECK (((escalation_hours >= 0) AND (escalation_hours <= 8760))),
    CONSTRAINT review_policies_hours_check CHECK (((hours >= 1) AND (hours <= 8760)))
);


--
-- Name: review_reminder_targets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.review_reminder_targets AS
 SELECT clock,
    clock_revision,
    project_id,
    recipient,
        CASE max(priority)
            WHEN 4 THEN 'unassigned'::text
            WHEN 3 THEN 'escalated'::text
            WHEN 2 THEN 'due'::text
            ELSE 'initial'::text
        END AS phase
   FROM ( SELECT c.clock,
            c.clock_revision,
            c.project_id,
            unnest(c.recipients) AS recipient,
                CASE
                    WHEN c.due THEN 2
                    ELSE 1
                END AS priority
           FROM public.live_review_clocks c
        UNION ALL
         SELECT c.clock,
            c.clock_revision,
            c.project_id,
            c.owner,
                CASE
                    WHEN (cardinality(c.recipients) = 0) THEN 4
                    ELSE 3
                END AS "case"
           FROM ((public.live_review_clocks c
             JOIN public.project_members pm ON (((pm.project_id = c.project_id) AND (pm.member_id = c.owner))))
             JOIN public.members m ON (((m.id = c.owner) AND m.enabled AND (m.kind = 'person'::text))))
          WHERE (c.overdue OR (cardinality(c.recipients) = 0))) candidates
  GROUP BY clock, clock_revision, project_id, recipient;


--
-- Name: rule_branch_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_branch_steps (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    mode text NOT NULL,
    origin_run uuid,
    origin_attempt integer,
    artifact_id uuid,
    base_version integer,
    result_version integer,
    finished boolean NOT NULL,
    CONSTRAINT rule_branch_steps_check CHECK (((origin_attempt IS NULL) OR (origin_run IS NOT NULL))),
    CONSTRAINT rule_branch_steps_check1 CHECK (((mode <> 'reuse'::text) OR finished)),
    CONSTRAINT rule_branch_steps_mode_check CHECK ((mode = ANY (ARRAY['reuse'::text, 'rebuild'::text, 'continue'::text]))),
    CONSTRAINT rule_branch_steps_ordinal_check CHECK ((ordinal > 0))
);


--
-- Name: run_artifact_slots; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.run_artifact_slots AS
 SELECT a.run_id,
    a.ordinal,
    a.id AS artifact_id
   FROM public.artifacts a
  WHERE (NOT (EXISTS ( SELECT
           FROM public.rule_branch_steps b
          WHERE ((b.run_id = a.run_id) AND (b.ordinal = a.ordinal)))))
UNION ALL
 SELECT b.run_id,
    b.ordinal,
    b.artifact_id
   FROM public.rule_branch_steps b
  WHERE (b.artifact_id IS NOT NULL);


--
-- Name: run_candidate_artifacts; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.run_candidate_artifacts AS
 SELECT a.id,
    slot.run_id,
    slot.ordinal,
    COALESCE(frozen.base_version, a.current_version) AS current_version
   FROM (((( SELECT a_1.id AS artifact_id,
            a_1.run_id,
            a_1.ordinal
           FROM public.artifacts a_1
          WHERE (NOT (EXISTS ( SELECT
                   FROM public.rule_branch_steps b
                  WHERE ((b.run_id = a_1.run_id) AND (b.ordinal = a_1.ordinal)))))
        UNION ALL
         SELECT b.artifact_id,
            b.run_id,
            b.ordinal
           FROM public.rule_branch_steps b
          WHERE (b.finished AND (b.result_version IS NOT NULL))) slot
     JOIN public.artifacts a ON ((a.id = slot.artifact_id)))
     LEFT JOIN public.rule_branch_rebuilds next ON ((next.source_run = slot.run_id)))
     LEFT JOIN public.rule_branch_steps frozen ON (((frozen.run_id = next.run_id) AND (frozen.ordinal = slot.ordinal) AND (frozen.artifact_id = a.id))));


--
-- Name: run_draft_fragments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_draft_fragments (
    run_id uuid NOT NULL,
    seq bigint NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    control_revision integer NOT NULL,
    byte_offset integer NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT run_draft_fragments_body_check CHECK (((octet_length(body) >= 1) AND (octet_length(body) <= 65536))),
    CONSTRAINT run_draft_fragments_byte_offset_check CHECK ((byte_offset >= 0))
);


--
-- Name: run_observations; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.run_observations AS
 SELECT i.run_id,
    i.ordinal,
    i.run_id AS origin_run,
    i.attempt_no
   FROM public.invocations i
  WHERE (i.status = 'completed'::text)
UNION ALL
 SELECT b.run_id,
    b.ordinal,
    b.origin_run,
    b.origin_attempt AS attempt_no
   FROM public.rule_branch_steps b
  WHERE ((b.mode = 'reuse'::text) AND (b.origin_attempt IS NOT NULL));


--
-- Name: run_source_inputs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.run_source_inputs AS
 SELECT r.id AS run_id,
    s.id AS source_id,
    ps.source_version AS plan_pin,
    v.version,
    COALESCE(v.filename, '历史资料'::text) AS filename,
        CASE
            WHEN ((s.revoked_at IS NULL) AND ((c.id IS NULL) OR (s.current_version = c.observed_version))) THEN v.extracted
            ELSE NULL::text
        END AS extracted,
        CASE
            WHEN public.source_is_picture(v.media_type) THEN v.media_type
            ELSE NULL::text
        END AS picture_media,
        CASE
            WHEN (public.source_is_picture(v.media_type) AND (s.revoked_at IS NULL) AND ((c.id IS NULL) OR (s.current_version = c.observed_version))) THEN v.object_hash
            ELSE NULL::text
        END AS picture_hash,
    ps.picture_order
   FROM (((((public.runs r
     JOIN public.plan_sources ps ON (((ps.project_id = r.project_id) AND (ps.plan_version = r.plan_version))))
     JOIN public.sources s ON (((s.id = ps.source_id) AND (s.project_id = r.project_id))))
     LEFT JOIN public.change_batches b ON ((b.run_id = r.id)))
     LEFT JOIN public.source_assessments c ON (((c.id = b.source_assessment) AND (c.source_id = s.id))))
     JOIN public.source_versions v ON (((v.source_id = s.id) AND (v.version = COALESCE(c.observed_version, ps.source_version)))))
UNION ALL
 SELECT r.id AS run_id,
    s.id AS source_id,
    c.pinned_version AS plan_pin,
    v.version,
    COALESCE(v.filename, '历史资料'::text) AS filename,
        CASE
            WHEN ((s.revoked_at IS NULL) AND (s.current_version = c.observed_version)) THEN v.extracted
            ELSE NULL::text
        END AS extracted,
    NULL::text AS picture_media,
    NULL::text AS picture_hash,
    NULL::integer AS picture_order
   FROM ((((public.runs r
     JOIN public.change_batches b ON ((b.run_id = r.id)))
     JOIN public.source_assessments c ON (((c.id = b.source_assessment) AND (c.artifact_id = b.artifact_id) AND (c.artifact_version = b.base_version))))
     JOIN public.sources s ON (((s.id = c.source_id) AND (s.project_id = r.project_id))))
     JOIN public.source_versions v ON (((v.source_id = s.id) AND (v.version = c.observed_version))))
  WHERE ((NOT (EXISTS ( SELECT
           FROM public.plan_sources p
          WHERE ((p.project_id = r.project_id) AND (p.plan_version = r.plan_version) AND (p.source_id = s.id))))) AND (EXISTS ( SELECT
           FROM public.artifact_step_receipts(b.artifact_id, b.base_version) receipt(run_id, ordinal, request_revision, source_id, source_version, kind, excerpt_start, excerpt_end)
          WHERE ((receipt.source_id = s.id) AND (receipt.source_version = c.pinned_version)))));


--
-- Name: run_source_receipt_pins; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.run_source_receipt_pins AS
 SELECT p.run_id,
    p.ordinal,
    p.request_revision,
    p.source_id,
    p.source_version,
    p.kind,
    p.excerpt_start,
    p.excerpt_end
   FROM public.run_source_receipts p
UNION ALL
 SELECT a.run_id,
    p.ordinal,
    p.request_revision,
    p.source_id,
    p.source_version,
    p.kind,
    p.excerpt_start,
    p.excerpt_end
   FROM (public.branch_rebuild_ancestors a
     JOIN public.run_source_receipts p ON ((p.run_id = a.source_run)));


--
-- Name: run_working_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_working_inputs (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    kind text NOT NULL,
    ref uuid NOT NULL,
    revision integer NOT NULL,
    CONSTRAINT run_working_inputs_kind_check CHECK ((kind = ANY (ARRAY['source'::text, 'preference'::text, 'rule'::text, 'skill'::text])))
);


--
-- Name: run_working_parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_working_parents (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    parent_run uuid NOT NULL,
    parent_ordinal integer NOT NULL,
    parent_attempt integer NOT NULL
);


--
-- Name: run_working_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.run_working_sets (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    plan_version integer NOT NULL,
    control_revision integer NOT NULL,
    message_through bigint DEFAULT 0 NOT NULL,
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    invalidated_at timestamp with time zone,
    build_agent uuid,
    build_revision integer,
    build_digest text,
    invalidated_kind text,
    invalidated_ref uuid,
    upstream_context jsonb,
    CONSTRAINT run_working_sets_attempt_no_check CHECK ((attempt_no > 0)),
    CONSTRAINT run_working_sets_ordinal_check CHECK ((ordinal > 0)),
    CONSTRAINT run_working_sets_upstream_context_check CHECK ((jsonb_typeof(upstream_context) = 'array'::text))
);


--
-- Name: service_action_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_action_receipts (
    run_id uuid NOT NULL,
    request_key text NOT NULL,
    signature bytea NOT NULL,
    result jsonb NOT NULL
);


--
-- Name: service_delivery_requirements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_delivery_requirements (
    service_id uuid NOT NULL,
    version integer NOT NULL,
    item integer NOT NULL,
    ordinal integer NOT NULL,
    label text NOT NULL,
    CONSTRAINT service_delivery_requirements_item_check CHECK ((item > 0)),
    CONSTRAINT service_delivery_requirements_label_check CHECK (((char_length(label) >= 1) AND (char_length(label) <= 180)))
);


--
-- Name: service_edges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_edges (
    service_id uuid NOT NULL,
    version integer NOT NULL,
    ordinal integer NOT NULL,
    depends_on integer NOT NULL,
    CONSTRAINT service_edges_check CHECK (((depends_on < ordinal) AND (depends_on > 0)))
);


--
-- Name: service_event_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_event_heads (
    run_id uuid NOT NULL,
    seq bigint NOT NULL
);


--
-- Name: service_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_events (
    run_id uuid NOT NULL,
    seq bigint NOT NULL,
    kind text NOT NULL,
    state text NOT NULL,
    ordinal integer,
    artifact_id uuid,
    version integer,
    at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: service_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_nodes (
    service_id uuid NOT NULL,
    version integer NOT NULL,
    ordinal integer NOT NULL,
    agent_id uuid NOT NULL,
    agent_revision integer NOT NULL,
    lookup_phase text DEFAULT ''::text NOT NULL,
    CONSTRAINT service_nodes_lookup_phase_check CHECK ((lookup_phase = ANY (ARRAY[''::text, 'search'::text, 'answer'::text, 'answer_calc'::text, 'review_evidence'::text, 'synthesize'::text])))
);


--
-- Name: service_rollbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_rollbacks (
    service_id uuid NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    from_version integer NOT NULL,
    to_version integer NOT NULL,
    expected_routing_revision integer NOT NULL,
    routing_revision integer NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: service_supplements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_supplements (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    revision integer NOT NULL,
    message_seq bigint NOT NULL
);


--
-- Name: service_tool_choices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_tool_choices (
    service_id uuid NOT NULL,
    version integer NOT NULL,
    ordinal integer NOT NULL,
    selector integer NOT NULL,
    alternative uuid NOT NULL,
    alternative_revision integer NOT NULL,
    CONSTRAINT service_tool_choices_check CHECK ((selector < ordinal))
);


--
-- Name: service_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_versions (
    service_id uuid NOT NULL,
    version integer NOT NULL,
    instructions text NOT NULL,
    reviewer uuid NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    example_input text DEFAULT ''::text NOT NULL,
    name text,
    allows_partial_delivery boolean DEFAULT false NOT NULL
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    name text NOT NULL,
    owner uuid NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    routing_revision integer DEFAULT 1 NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    token_hash bytea NOT NULL,
    member_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    oidc_binding uuid,
    emergency boolean DEFAULT false NOT NULL,
    CONSTRAINT sessions_check CHECK (((NOT emergency) OR (oidc_binding IS NULL)))
);


--
-- Name: skill_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_dependencies (
    skill_id uuid NOT NULL,
    revision integer NOT NULL,
    needs_skill uuid NOT NULL,
    needs_revision integer NOT NULL,
    "position" integer NOT NULL,
    CONSTRAINT skill_dependencies_check CHECK ((skill_id <> needs_skill))
);


--
-- Name: skill_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_files (
    skill_id uuid NOT NULL,
    revision integer NOT NULL,
    path text NOT NULL,
    object_hash text NOT NULL,
    in_context boolean NOT NULL
);


--
-- Name: skill_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: skill_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_revisions (
    skill_id uuid NOT NULL,
    revision integer NOT NULL,
    description text NOT NULL,
    digest text NOT NULL,
    published_by uuid NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    activation_terms text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT skill_revisions_activation_terms_check CHECK ((cardinality(activation_terms) <= 8)),
    CONSTRAINT skill_revisions_revision_check CHECK ((revision > 0))
);


--
-- Name: source_object_cleanup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_object_cleanup (
    source_id uuid NOT NULL,
    hash text NOT NULL,
    last_failure timestamp with time zone
);


--
-- Name: source_passages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_passages (
    source_id uuid NOT NULL,
    version integer NOT NULL,
    start_char integer NOT NULL,
    passage text NOT NULL,
    embedding public.vector(512),
    encoder text,
    CONSTRAINT source_passages_check CHECK (((embedding IS NULL) = (encoder IS NULL)))
);


--
-- Name: source_receipt_request_no; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.source_receipt_request_no
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: starter_samples; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.starter_samples (
    project_id uuid NOT NULL,
    team_id uuid NOT NULL,
    actor uuid NOT NULL,
    request_key text NOT NULL,
    agents uuid[] NOT NULL,
    revisions integer[] NOT NULL
);


--
-- Name: step_dispatch_waits_wait_revision_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.step_dispatch_waits ALTER COLUMN wait_revision ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.step_dispatch_waits_wait_revision_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: step_rule_wait_no; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.step_rule_wait_no
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: step_rule_waits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.step_rule_waits (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    rule_id uuid NOT NULL,
    rule_revision integer NOT NULL,
    wait_revision integer DEFAULT nextval('public.step_rule_wait_no'::regclass) NOT NULL,
    rebuild_required boolean NOT NULL,
    CONSTRAINT step_rule_waits_ordinal_check CHECK ((ordinal > 0)),
    CONSTRAINT step_rule_waits_wait_revision_check CHECK ((wait_revision > 0))
);


--
-- Name: step_rule_recovery_choices; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.step_rule_recovery_choices AS
 SELECT w.run_id,
    w.ordinal,
    w.rule_id,
    w.rule_revision,
    w.wait_revision,
    w.rebuild_required,
        CASE
            WHEN (w.rebuild_required OR (EXISTS ( SELECT
               FROM public.invocations i
              WHERE ((i.run_id = w.run_id) AND (i.ordinal = w.ordinal))))) THEN NULL::integer
            WHEN current_pin.usable THEN w.rule_revision
            WHEN (public.rule_usable(w.rule_id, v.revision, r.actor) AND ((n.agent_id = ANY (v.agent_scope)) OR (primary_node.agent_id = ANY (v.agent_scope)))) THEN v.revision
            ELSE NULL::integer
        END AS available_revision
   FROM (((((((public.step_rule_waits w
     JOIN public.runs r ON ((r.id = w.run_id)))
     JOIN public.projects p ON ((p.id = r.project_id)))
     JOIN public.team_rules tr ON (((tr.id = w.rule_id) AND (tr.team_id = p.team_id))))
     JOIN public.effective_run_rules current_pin ON ((((current_pin.run_id = w.run_id) AND (current_pin.ordinal = w.ordinal) AND (current_pin.rule_id = w.rule_id) AND (current_pin.rule_revision = w.rule_revision)) AND current_pin.scoped)))
     JOIN public.effective_run_nodes n ON (((n.run_id = w.run_id) AND (n.ordinal = w.ordinal))))
     JOIN public.nodes primary_node ON (((primary_node.project_id = n.project_id) AND (primary_node.plan_version = n.plan_version) AND (primary_node.ordinal = n.ordinal))))
     LEFT JOIN public.rule_versions v ON (((v.rule_id = tr.id) AND (v.revision = tr.published_revision))));


--
-- Name: step_source_receipt_inputs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.step_source_receipt_inputs AS
 WITH cited_receipts AS NOT MATERIALIZED (
         SELECT p.run_id,
            p.ordinal,
            p.request_revision,
            p.source_id,
            p.source_version,
            p.kind,
            p.excerpt_start,
            p.excerpt_end,
            e.ordinal AS reader
           FROM (((((public.run_source_receipt_pins p
             JOIN public.runs r ON ((r.id = p.run_id)))
             JOIN public.node_edges e ON (((e.project_id = r.project_id) AND (e.plan_version = r.plan_version) AND (e.depends_on = p.ordinal))))
             JOIN public.nodes n ON (((n.project_id = e.project_id) AND (n.plan_version = e.plan_version) AND (n.ordinal = e.ordinal))))
             JOIN public.run_observations i ON (((i.run_id = p.run_id) AND (i.ordinal = p.ordinal))))
             JOIN public.lookup_turns t ON (((t.run_id = i.origin_run) AND (t.ordinal = i.ordinal) AND (t.attempt_no = i.attempt_no))))
          WHERE ((n.lookup_phase = ANY (ARRAY['review_evidence'::text, 'synthesize'::text])) AND (t.outcome = 'lookup_refined'::text) AND (EXISTS ( SELECT
                   FROM jsonb_to_recordset(t.refinement_evidence) c("Source" uuid, "Version" integer)
                  WHERE ((c."Source" = p.source_id) AND (c."Version" = p.source_version)))))
        )
 SELECT p.run_id,
    p.ordinal,
    p.request_revision,
    p.source_id,
    p.source_version,
    p.kind,
    p.excerpt_start,
    p.excerpt_end,
    p.ordinal AS reader
   FROM public.run_source_receipt_pins p
UNION ALL
 SELECT cited_receipts.run_id,
    cited_receipts.ordinal,
    cited_receipts.request_revision,
    cited_receipts.source_id,
    cited_receipts.source_version,
    cited_receipts.kind,
    cited_receipts.excerpt_start,
    cited_receipts.excerpt_end,
    cited_receipts.reader
   FROM cited_receipts
UNION ALL
 SELECT p.run_id,
    p.ordinal,
    p.request_revision,
    p.source_id,
    p.source_version,
    p.kind,
    p.excerpt_start,
    p.excerpt_end,
    e.ordinal AS reader
   FROM ((((((cited_receipts p
     JOIN public.runs r ON ((r.id = p.run_id)))
     JOIN public.nodes review ON (((review.project_id = r.project_id) AND (review.plan_version = r.plan_version) AND (review.ordinal = p.reader))))
     JOIN public.node_edges e ON (((e.project_id = review.project_id) AND (e.plan_version = review.plan_version) AND (e.depends_on = review.ordinal))))
     JOIN public.nodes final ON (((final.project_id = e.project_id) AND (final.plan_version = e.plan_version) AND (final.ordinal = e.ordinal))))
     JOIN public.run_observations i ON (((i.run_id = p.run_id) AND (i.ordinal = p.reader))))
     JOIN public.lookup_turns t ON (((t.run_id = i.origin_run) AND (t.ordinal = i.ordinal) AND (t.attempt_no = i.attempt_no))))
  WHERE ((review.lookup_phase = 'review_evidence'::text) AND (final.lookup_phase = 'synthesize'::text) AND (t.outcome = 'lookup_refined'::text) AND (EXISTS ( SELECT
           FROM jsonb_to_recordset(t.refinement_evidence) c("Source" uuid, "Version" integer)
          WHERE ((c."Source" = p.source_id) AND (c."Version" = p.source_version)))));


--
-- Name: submission_windows; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.submission_windows AS
 SELECT run_id,
    ordinal,
    (started_at + make_interval(secs => (execution_seconds)::double precision)) AS execution_due,
    (started_at + make_interval(secs => ((execution_seconds + receipt_seconds))::double precision)) AS receipt_due
   FROM public.invocations
  WHERE ((status = 'submitted'::text) AND (remote_task IS NULL));


--
-- Name: takeover_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.takeover_reviews (
    assignment uuid NOT NULL,
    artifact_id uuid NOT NULL,
    version integer NOT NULL,
    reviewer uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: team_starters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_starters (
    team_id uuid NOT NULL,
    slot text NOT NULL,
    agent_id uuid NOT NULL,
    template_version integer NOT NULL,
    CONSTRAINT team_starters_slot_check CHECK ((slot = ANY (ARRAY['writer'::text, 'checker'::text, 'document'::text])))
);


--
-- Name: telemetry_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.telemetry_outbox (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_at timestamp with time zone DEFAULT now() NOT NULL,
    lease uuid,
    outcome text DEFAULT 'pending'::text NOT NULL,
    call_attempt integer DEFAULT 1 NOT NULL
);


--
-- Name: text_reply_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.text_reply_checkpoints (
    run_id uuid NOT NULL,
    ordinal integer NOT NULL,
    attempt_no integer NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    payload bytea,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT text_reply_checkpoints_check CHECK (((state = 'pending'::text) = (payload IS NOT NULL))),
    CONSTRAINT text_reply_checkpoints_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'consumed'::text, 'discarded'::text, 'incomplete'::text])))
);


--
-- Name: trace_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trace_events ALTER COLUMN seq ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trace_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trace_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trace_grants (
    run_id uuid NOT NULL,
    member_id uuid NOT NULL,
    scope text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT trace_grants_scope_check CHECK ((scope = ANY (ARRAY['structure'::text, 'content'::text, 'export'::text])))
);


--
-- Name: trial_results; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.trial_results AS
 SELECT v.id,
    v.agent_id,
    v.revision,
    v.actor,
    v.status,
    v.evidence,
    v.created_at,
    v.ended_at,
    v.remote_task,
    v.tokens,
    v.expected,
    v.input_text,
    v.remote_context,
    v.remote_status,
    v.follow_lease,
    v.follow_until,
    v.cancel_requested,
    v.request_key,
    v.check_id,
        CASE
            WHEN ((v.status = 'submitted'::text) AND ((v.created_at + ((COALESCE(((r.remote_policy ->> 'executionSeconds'::text))::integer,
            CASE
                WHEN (r.tool IS NOT NULL) THEN 45
                ELSE 90
            END))::double precision * '00:00:01'::interval)) <= now())) THEN 'unknown'::text
            ELSE v.status
        END AS current_status
   FROM (public.validations v
     JOIN public.agent_revisions r ON (((r.agent_id = v.agent_id) AND (r.revision = v.revision))));


--
-- Name: validation_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validation_files (
    trial_id uuid NOT NULL,
    object_hash text NOT NULL,
    filename text NOT NULL,
    media_type text NOT NULL
);


--
-- Name: validation_pictures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validation_pictures (
    trial_id uuid NOT NULL,
    object_hash text NOT NULL,
    filename text NOT NULL,
    media_type text NOT NULL,
    CONSTRAINT validation_pictures_media_type_check CHECK (public.source_is_picture(media_type))
);


--
-- Name: validation_skill_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validation_skill_inputs (
    trial_id uuid NOT NULL,
    skill_id uuid NOT NULL,
    skill_revision integer NOT NULL
);


--
-- Name: workflow_template_builds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_template_builds (
    template_id uuid NOT NULL,
    version integer NOT NULL,
    agent_id uuid NOT NULL,
    agent_revision integer NOT NULL,
    build_digest text NOT NULL
);


--
-- Name: workflow_template_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_template_versions (
    template_id uuid NOT NULL,
    version integer NOT NULL,
    name text NOT NULL,
    instructions text NOT NULL,
    inputs text NOT NULL,
    outcomes text NOT NULL,
    requires_sources boolean NOT NULL,
    nodes jsonb NOT NULL,
    origin_project uuid NOT NULL,
    origin_plan integer NOT NULL,
    author uuid NOT NULL,
    request_key text NOT NULL,
    request_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    manifest_digest text,
    delivery_contract jsonb,
    CONSTRAINT workflow_template_versions_delivery_contract_check CHECK (((delivery_contract IS NULL) OR ((jsonb_typeof(delivery_contract) = 'object'::text) AND (delivery_contract ?& ARRAY['allowPartial'::text, 'items'::text]) AND (jsonb_typeof((delivery_contract -> 'allowPartial'::text)) = 'boolean'::text) AND (jsonb_typeof((delivery_contract -> 'items'::text)) = 'array'::text)))),
    CONSTRAINT workflow_template_versions_manifest_digest_check CHECK ((manifest_digest ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT workflow_template_versions_nodes_check CHECK (((jsonb_typeof(nodes) = 'array'::text) AND ((jsonb_array_length(nodes) >= 1) AND (jsonb_array_length(nodes) <= 12)))),
    CONSTRAINT workflow_template_versions_version_check CHECK ((version > 0))
);


--
-- Name: workflow_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    owner uuid NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    published_version integer DEFAULT 0 NOT NULL,
    requested_version integer DEFAULT 0 NOT NULL,
    decision_reason text DEFAULT ''::text NOT NULL,
    archived_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workflow_templates_check CHECK (((published_version >= 0) AND (published_version <= current_version))),
    CONSTRAINT workflow_templates_check1 CHECK (((requested_version = 0) OR (requested_version = current_version))),
    CONSTRAINT workflow_templates_current_version_check CHECK ((current_version > 0))
);


--
-- Data for Name: account_notices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_build_manifests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_checks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_improvement_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_improvements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_publications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_release_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agent_skill_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: answer_adoptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: artifact_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: artifact_remote_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: artifact_requirement_evidence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: artifact_upstream_context; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: artifact_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: artifacts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: bill_rows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: budget_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: calculation_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: call_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: change_batches; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: change_inputs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_attachment_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_card_actions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_codes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_contexts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_proposals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_remote_input_proposals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: channel_replies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: column_suggestions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: controls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: delegations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: delivery_item_assessments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: delivery_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: delivery_revision_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: delivery_source_evidence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: distribution_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: enterprise; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: enterprise_login_policy; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.enterprise_login_policy VALUES (true, '', '', '', '', '');


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: feedback_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: feedback_source_quotes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: gap_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: im_binding_codes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: im_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: im_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: im_service_launches; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: im_threads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invocation_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: late_call_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: local_action_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: lookup_index_waits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: lookup_question_handoffs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: lookup_turns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: management_exports; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: management_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_key_candidates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_probes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_replacement_agents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_replacements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_resources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: model_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: node_edges; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: objects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oidc_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oidc_flows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: outbox; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_delivery_contracts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_delivery_requirements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_preferences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_scoped_preferences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_sources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_tool_choices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plan_workflow_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_budget_blocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_context_messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: preferences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_agent_calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_agent_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_budgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_feedback_submissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_memberships; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_session_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_session_heads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: receipt_wakes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: remote_completion_evidence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: remote_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: remote_task_inputs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: remote_trial_inputs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: remote_trial_observations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: resource_budgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: review_clocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: review_notification_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: review_notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: review_policies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: reviewer_handoffs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: rule_branch_rebuilds; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: rule_branch_steps; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: rule_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_draft_fragments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_source_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_tool_choice_waits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_tool_choices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_working_inputs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_working_parents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: run_working_sets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_action_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_delivery_requirements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_edges; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_event_heads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_nodes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_rollbacks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_supplements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_tool_choices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: skill_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: skill_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: skill_packs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: skill_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source_assessments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source_object_cleanup; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source_passages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: spend; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: starter_samples; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: step_dispatch_waits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: step_rule_replacements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: step_rule_waits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: step_tool_choice_waits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: superseded_calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: takeover_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_starters; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: telemetry_outbox; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: text_reply_checkpoints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: trace_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: trace_grants; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: validation_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: validation_pictures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: validation_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: validation_skill_inputs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: validation_withdrawals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: validations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_template_adoptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_template_builds; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_template_uses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_template_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: audit_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_events_seq_seq', 1, false);


--
-- Name: delivery_item_assessments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delivery_item_assessments_id_seq', 1, false);


--
-- Name: lookup_index_wait_no; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lookup_index_wait_no', 1, false);


--
-- Name: messages_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_seq_seq', 1, false);


--
-- Name: remote_trial_observations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.remote_trial_observations_id_seq', 1, false);


--
-- Name: source_receipt_request_no; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.source_receipt_request_no', 1, false);


--
-- Name: step_dispatch_waits_wait_revision_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.step_dispatch_waits_wait_revision_seq', 1, false);


--
-- Name: step_rule_wait_no; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.step_rule_wait_no', 1, false);


--
-- Name: trace_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trace_events_seq_seq', 1, false);


--
-- Name: account_notices account_notices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_notices
    ADD CONSTRAINT account_notices_pkey PRIMARY KEY (event_seq);


--
-- Name: agent_build_manifests agent_build_manifests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_build_manifests
    ADD CONSTRAINT agent_build_manifests_pkey PRIMARY KEY (agent_id, revision, digest);


--
-- Name: agent_checks agent_checks_agent_id_revision_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_checks
    ADD CONSTRAINT agent_checks_agent_id_revision_id_key UNIQUE (agent_id, revision, id);


--
-- Name: agent_checks agent_checks_agent_id_revision_ordinal_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_checks
    ADD CONSTRAINT agent_checks_agent_id_revision_ordinal_key UNIQUE (agent_id, revision, ordinal);


--
-- Name: agent_checks agent_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_checks
    ADD CONSTRAINT agent_checks_pkey PRIMARY KEY (id);


--
-- Name: agent_improvement_decisions agent_improvement_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvement_decisions
    ADD CONSTRAINT agent_improvement_decisions_pkey PRIMARY KEY (request_id, version);


--
-- Name: agent_improvements agent_improvements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvements
    ADD CONSTRAINT agent_improvements_pkey PRIMARY KEY (id);


--
-- Name: agent_improvements agent_improvements_requester_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvements
    ADD CONSTRAINT agent_improvements_requester_request_key_key UNIQUE (requester, request_key);


--
-- Name: agent_publications agent_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_publications
    ADD CONSTRAINT agent_publications_pkey PRIMARY KEY (agent_id, generation);


--
-- Name: agent_release_requests agent_release_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_release_requests
    ADD CONSTRAINT agent_release_requests_pkey PRIMARY KEY (id);


--
-- Name: agent_revisions agent_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_revisions
    ADD CONSTRAINT agent_revisions_pkey PRIMARY KEY (agent_id, revision);


--
-- Name: agent_skill_bindings agent_skill_bindings_agent_id_revision_position_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skill_bindings
    ADD CONSTRAINT agent_skill_bindings_agent_id_revision_position_key UNIQUE (agent_id, revision, "position");


--
-- Name: agent_skill_bindings agent_skill_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skill_bindings
    ADD CONSTRAINT agent_skill_bindings_pkey PRIMARY KEY (agent_id, revision, skill_id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: answer_adoptions answer_adoptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.answer_adoptions
    ADD CONSTRAINT answer_adoptions_pkey PRIMARY KEY (project_id);


--
-- Name: answer_adoptions answer_adoptions_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.answer_adoptions
    ADD CONSTRAINT answer_adoptions_request_id_key UNIQUE (request_id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: applications applications_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_token_hash_key UNIQUE (token_hash);


--
-- Name: artifact_files artifact_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_files
    ADD CONSTRAINT artifact_files_pkey PRIMARY KEY (artifact_id, version);


--
-- Name: artifact_remote_receipts artifact_remote_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_remote_receipts
    ADD CONSTRAINT artifact_remote_receipts_pkey PRIMARY KEY (artifact_id, version);


--
-- Name: artifact_requirement_evidence artifact_requirement_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_requirement_evidence
    ADD CONSTRAINT artifact_requirement_evidence_pkey PRIMARY KEY (artifact_id, version);


--
-- Name: artifact_upstream_context artifact_upstream_context_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_upstream_context
    ADD CONSTRAINT artifact_upstream_context_pkey PRIMARY KEY (artifact_id, version);


--
-- Name: artifact_versions artifact_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT artifact_versions_pkey PRIMARY KEY (artifact_id, version);


--
-- Name: artifacts artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_pkey PRIMARY KEY (id);


--
-- Name: artifacts artifacts_run_id_ordinal_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_run_id_ordinal_key UNIQUE (run_id, ordinal);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (seq);


--
-- Name: bill_rows bill_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_rows
    ADD CONSTRAINT bill_rows_pkey PRIMARY KEY (team_id, line_key);


--
-- Name: budget_requests budget_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_pkey PRIMARY KEY (id);


--
-- Name: budget_requests budget_requests_requester_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_requester_request_key_key UNIQUE (requester, request_key);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (team_id);


--
-- Name: calculation_requests calculation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculation_requests
    ADD CONSTRAINT calculation_requests_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: call_reviews call_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_reviews
    ADD CONSTRAINT call_reviews_pkey PRIMARY KEY (control_id);


--
-- Name: change_batches change_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_batches
    ADD CONSTRAINT change_batches_pkey PRIMARY KEY (run_id);


--
-- Name: change_inputs change_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_inputs
    ADD CONSTRAINT change_inputs_pkey PRIMARY KEY (run_id, artifact_id);


--
-- Name: channel_attachment_jobs channel_attachment_jobs_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_attachment_jobs
    ADD CONSTRAINT channel_attachment_jobs_event_id_key UNIQUE (event_id);


--
-- Name: channel_attachment_jobs channel_attachment_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_attachment_jobs
    ADD CONSTRAINT channel_attachment_jobs_pkey PRIMARY KEY (id);


--
-- Name: channel_card_actions channel_card_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_card_actions
    ADD CONSTRAINT channel_card_actions_pkey PRIMARY KEY (id);


--
-- Name: channel_card_actions channel_card_actions_reply_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_card_actions
    ADD CONSTRAINT channel_card_actions_reply_id_key UNIQUE (reply_id);


--
-- Name: channel_codes channel_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_codes
    ADD CONSTRAINT channel_codes_pkey PRIMARY KEY (token_hash);


--
-- Name: channel_contexts channel_contexts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_contexts
    ADD CONSTRAINT channel_contexts_pkey PRIMARY KEY (tenant, chat_id, member_id);


--
-- Name: channel_events channel_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_events
    ADD CONSTRAINT channel_events_pkey PRIMARY KEY (id);


--
-- Name: channel_links channel_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_links
    ADD CONSTRAINT channel_links_pkey PRIMARY KEY (tenant, open_id);


--
-- Name: channel_links channel_links_tenant_member_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_links
    ADD CONSTRAINT channel_links_tenant_member_id_key UNIQUE (tenant, member_id);


--
-- Name: channel_proposals channel_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_proposals
    ADD CONSTRAINT channel_proposals_pkey PRIMARY KEY (id);


--
-- Name: channel_proposals channel_proposals_tenant_chat_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_proposals
    ADD CONSTRAINT channel_proposals_tenant_chat_id_member_id_key UNIQUE (tenant, chat_id, member_id);


--
-- Name: channel_remote_input_proposals channel_remote_input_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_remote_input_proposals
    ADD CONSTRAINT channel_remote_input_proposals_pkey PRIMARY KEY (id);


--
-- Name: channel_remote_input_proposals channel_remote_input_proposals_tenant_chat_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_remote_input_proposals
    ADD CONSTRAINT channel_remote_input_proposals_tenant_chat_id_member_id_key UNIQUE (tenant, chat_id, member_id);


--
-- Name: channel_replies channel_replies_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_replies
    ADD CONSTRAINT channel_replies_event_id_key UNIQUE (event_id);


--
-- Name: channel_replies channel_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_replies
    ADD CONSTRAINT channel_replies_pkey PRIMARY KEY (id);


--
-- Name: column_suggestions column_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.column_suggestions
    ADD CONSTRAINT column_suggestions_pkey PRIMARY KEY (id);


--
-- Name: column_suggestions column_suggestions_run_id_ordinal_attempt_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.column_suggestions
    ADD CONSTRAINT column_suggestions_run_id_ordinal_attempt_no_key UNIQUE (run_id, ordinal, attempt_no);


--
-- Name: controls controls_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.controls
    ADD CONSTRAINT controls_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: controls controls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.controls
    ADD CONSTRAINT controls_pkey PRIMARY KEY (id);


--
-- Name: delegations delegations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegations
    ADD CONSTRAINT delegations_pkey PRIMARY KEY (id);


--
-- Name: delegations delegations_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegations
    ADD CONSTRAINT delegations_token_hash_key UNIQUE (token_hash);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (id);


--
-- Name: deliveries deliveries_project_id_edition_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_project_id_edition_key UNIQUE (project_id, edition);


--
-- Name: delivery_item_assessments delivery_item_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_item_assessments
    ADD CONSTRAINT delivery_item_assessments_pkey PRIMARY KEY (id);


--
-- Name: delivery_items delivery_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_items
    ADD CONSTRAINT delivery_items_pkey PRIMARY KEY (delivery_id, artifact_id);


--
-- Name: delivery_revision_requests delivery_revision_requests_feedback_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_revision_requests
    ADD CONSTRAINT delivery_revision_requests_feedback_id_key UNIQUE (feedback_id);


--
-- Name: delivery_revision_requests delivery_revision_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_revision_requests
    ADD CONSTRAINT delivery_revision_requests_pkey PRIMARY KEY (base_delivery);


--
-- Name: delivery_source_evidence delivery_source_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_source_evidence
    ADD CONSTRAINT delivery_source_evidence_pkey PRIMARY KEY (delivery_id, source_id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: distribution_reviews distribution_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_reviews
    ADD CONSTRAINT distribution_reviews_pkey PRIMARY KEY (source_id, artifact_id, version, revision);


--
-- Name: enterprise_login_policy enterprise_login_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_login_policy
    ADD CONSTRAINT enterprise_login_policy_pkey PRIMARY KEY (singleton);


--
-- Name: enterprise enterprise_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise
    ADD CONSTRAINT enterprise_pkey PRIMARY KEY (id);


--
-- Name: feedback_events feedback_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_events
    ADD CONSTRAINT feedback_events_pkey PRIMARY KEY (feedback_id, revision);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: feedback_source_quotes feedback_source_quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_source_quotes
    ADD CONSTRAINT feedback_source_quotes_pkey PRIMARY KEY (feedback_id);


--
-- Name: feedback feedback_submission_id_submission_item_artifact_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_submission_id_submission_item_artifact_id_key UNIQUE (submission_id, submission_item, artifact_id);


--
-- Name: gap_bindings gap_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gap_bindings
    ADD CONSTRAINT gap_bindings_pkey PRIMARY KEY (request_id, slot);


--
-- Name: im_binding_codes im_binding_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_binding_codes
    ADD CONSTRAINT im_binding_codes_pkey PRIMARY KEY (connection, member_id);


--
-- Name: im_binding_codes im_binding_codes_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_binding_codes
    ADD CONSTRAINT im_binding_codes_token_hash_key UNIQUE (token_hash);


--
-- Name: im_bindings im_bindings_connection_member_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_bindings
    ADD CONSTRAINT im_bindings_connection_member_id_key UNIQUE (connection, member_id);


--
-- Name: im_bindings im_bindings_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_bindings
    ADD CONSTRAINT im_bindings_id_key UNIQUE (id);


--
-- Name: im_bindings im_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_bindings
    ADD CONSTRAINT im_bindings_pkey PRIMARY KEY (connection, external_user);


--
-- Name: im_events im_events_connection_chat_id_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_events
    ADD CONSTRAINT im_events_connection_chat_id_message_id_key UNIQUE (connection, chat_id, message_id);


--
-- Name: im_events im_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_events
    ADD CONSTRAINT im_events_pkey PRIMARY KEY (connection, event_id);


--
-- Name: im_service_launches im_service_launches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_service_launches
    ADD CONSTRAINT im_service_launches_pkey PRIMARY KEY (id);


--
-- Name: im_service_launches im_service_launches_run_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_service_launches
    ADD CONSTRAINT im_service_launches_run_id_key UNIQUE (run_id);


--
-- Name: im_threads im_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_threads
    ADD CONSTRAINT im_threads_pkey PRIMARY KEY (binding_id, chat_id, thread_id);


--
-- Name: invites invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (token_hash);


--
-- Name: invocation_files invocation_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_files
    ADD CONSTRAINT invocation_files_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: invocations invocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocations
    ADD CONSTRAINT invocations_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: late_call_receipts late_call_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.late_call_receipts
    ADD CONSTRAINT late_call_receipts_pkey PRIMARY KEY (run_id, ordinal, attempt_no);


--
-- Name: local_action_observations local_action_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_action_observations
    ADD CONSTRAINT local_action_observations_pkey PRIMARY KEY (run_id, ordinal, attempt_no, action_round);


--
-- Name: lookup_index_waits lookup_index_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lookup_index_waits
    ADD CONSTRAINT lookup_index_waits_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: lookup_question_handoffs lookup_question_handoffs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lookup_question_handoffs
    ADD CONSTRAINT lookup_question_handoffs_pkey PRIMARY KEY (run_id, target);


--
-- Name: lookup_turns lookup_turns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lookup_turns
    ADD CONSTRAINT lookup_turns_pkey PRIMARY KEY (run_id, ordinal, attempt_no);


--
-- Name: management_exports management_exports_grant_id_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_exports
    ADD CONSTRAINT management_exports_grant_id_request_key_key UNIQUE (grant_id, request_key);


--
-- Name: management_exports management_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_exports
    ADD CONSTRAINT management_exports_pkey PRIMARY KEY (id);


--
-- Name: management_grants management_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_grants
    ADD CONSTRAINT management_grants_pkey PRIMARY KEY (id);


--
-- Name: members members_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_email_key UNIQUE (email);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (seq);


--
-- Name: model_key_candidates model_key_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_key_candidates
    ADD CONSTRAINT model_key_candidates_pkey PRIMARY KEY (id);


--
-- Name: model_probes model_probes_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_probes
    ADD CONSTRAINT model_probes_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: model_probes model_probes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_probes
    ADD CONSTRAINT model_probes_pkey PRIMARY KEY (id);


--
-- Name: model_replacement_agents model_replacement_agents_batch_id_agent_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacement_agents
    ADD CONSTRAINT model_replacement_agents_batch_id_agent_id_key UNIQUE (batch_id, agent_id);


--
-- Name: model_replacement_agents model_replacement_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacement_agents
    ADD CONSTRAINT model_replacement_agents_pkey PRIMARY KEY (agent_id, draft);


--
-- Name: model_replacements model_replacements_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacements
    ADD CONSTRAINT model_replacements_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: model_replacements model_replacements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacements
    ADD CONSTRAINT model_replacements_pkey PRIMARY KEY (id);


--
-- Name: model_resources model_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_resources
    ADD CONSTRAINT model_resources_pkey PRIMARY KEY (id);


--
-- Name: model_revisions model_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_revisions
    ADD CONSTRAINT model_revisions_pkey PRIMARY KEY (resource_id, revision);


--
-- Name: node_edges node_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_edges
    ADD CONSTRAINT node_edges_pkey PRIMARY KEY (project_id, plan_version, ordinal, depends_on);


--
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (project_id, plan_version, ordinal);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (hash);


--
-- Name: oidc_bindings oidc_bindings_issuer_client_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_bindings
    ADD CONSTRAINT oidc_bindings_issuer_client_id_member_id_key UNIQUE (issuer, client_id, member_id);


--
-- Name: oidc_bindings oidc_bindings_issuer_client_id_subject_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_bindings
    ADD CONSTRAINT oidc_bindings_issuer_client_id_subject_key UNIQUE (issuer, client_id, subject);


--
-- Name: oidc_bindings oidc_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_bindings
    ADD CONSTRAINT oidc_bindings_pkey PRIMARY KEY (id);


--
-- Name: oidc_flows oidc_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_flows
    ADD CONSTRAINT oidc_flows_pkey PRIMARY KEY (state_hash);


--
-- Name: outbox outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox
    ADD CONSTRAINT outbox_pkey PRIMARY KEY (run_id);


--
-- Name: plan_delivery_contracts plan_delivery_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_delivery_contracts
    ADD CONSTRAINT plan_delivery_contracts_pkey PRIMARY KEY (project_id, plan_version);


--
-- Name: plan_delivery_requirements plan_delivery_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_delivery_requirements
    ADD CONSTRAINT plan_delivery_requirements_pkey PRIMARY KEY (project_id, plan_version, item);


--
-- Name: plan_preferences plan_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_preferences
    ADD CONSTRAINT plan_preferences_pkey PRIMARY KEY (project_id, plan_version, preference_id);


--
-- Name: plan_rules plan_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_rules
    ADD CONSTRAINT plan_rules_pkey PRIMARY KEY (project_id, plan_version, rule_id);


--
-- Name: plan_scoped_preferences plan_scoped_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_scoped_preferences
    ADD CONSTRAINT plan_scoped_preferences_pkey PRIMARY KEY (project_id, plan_version, preference_id);


--
-- Name: plan_sources plan_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_sources
    ADD CONSTRAINT plan_sources_pkey PRIMARY KEY (project_id, plan_version, source_id);


--
-- Name: plan_tool_choices plan_tool_choices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_tool_choices
    ADD CONSTRAINT plan_tool_choices_pkey PRIMARY KEY (project_id, plan_version, ordinal);


--
-- Name: plan_tool_choices plan_tool_choices_project_id_plan_version_selector_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_tool_choices
    ADD CONSTRAINT plan_tool_choices_project_id_plan_version_selector_key UNIQUE (project_id, plan_version, selector);


--
-- Name: plan_workflow_templates plan_workflow_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_workflow_templates
    ADD CONSTRAINT plan_workflow_templates_pkey PRIMARY KEY (project_id, plan_version);


--
-- Name: planning_budget_blocks planning_budget_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_budget_blocks
    ADD CONSTRAINT planning_budget_blocks_pkey PRIMARY KEY (project_id);


--
-- Name: planning_context_messages planning_context_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_context_messages
    ADD CONSTRAINT planning_context_messages_pkey PRIMARY KEY (request_id, message_seq);


--
-- Name: planning_defaults planning_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_defaults
    ADD CONSTRAINT planning_defaults_pkey PRIMARY KEY (team_id);


--
-- Name: planning_requests planning_requests_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_requests
    ADD CONSTRAINT planning_requests_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: planning_requests planning_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_requests
    ADD CONSTRAINT planning_requests_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (project_id, version);


--
-- Name: preferences preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_pkey PRIMARY KEY (id);


--
-- Name: project_agent_calls project_agent_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_calls
    ADD CONSTRAINT project_agent_calls_pkey PRIMARY KEY (op_key);


--
-- Name: project_agent_grants project_agent_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_grants
    ADD CONSTRAINT project_agent_grants_pkey PRIMARY KEY (id);


--
-- Name: project_budgets project_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_budgets
    ADD CONSTRAINT project_budgets_pkey PRIMARY KEY (project_id);


--
-- Name: project_feedback_submissions project_feedback_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_feedback_submissions
    ADD CONSTRAINT project_feedback_submissions_pkey PRIMARY KEY (id);


--
-- Name: project_feedback_submissions project_feedback_submissions_project_id_author_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_feedback_submissions
    ADD CONSTRAINT project_feedback_submissions_project_id_author_request_key_key UNIQUE (project_id, author, request_key);


--
-- Name: project_memberships project_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_members_pkey PRIMARY KEY (project_id, member_id);


--
-- Name: project_session_events project_session_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_session_events
    ADD CONSTRAINT project_session_events_pkey PRIMARY KEY (project_id, seq);


--
-- Name: project_session_heads project_session_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_session_heads
    ADD CONSTRAINT project_session_heads_pkey PRIMARY KEY (project_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: receipt_wakes receipt_wakes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_wakes
    ADD CONSTRAINT receipt_wakes_pkey PRIMARY KEY (run_id);


--
-- Name: remote_completion_evidence remote_completion_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_completion_evidence
    ADD CONSTRAINT remote_completion_evidence_pkey PRIMARY KEY (run_id, ordinal, attempt_no);


--
-- Name: remote_jobs remote_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_jobs
    ADD CONSTRAINT remote_jobs_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: remote_task_inputs remote_task_inputs_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_task_inputs
    ADD CONSTRAINT remote_task_inputs_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: remote_task_inputs remote_task_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_task_inputs
    ADD CONSTRAINT remote_task_inputs_pkey PRIMARY KEY (id);


--
-- Name: remote_trial_inputs remote_trial_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_trial_inputs
    ADD CONSTRAINT remote_trial_inputs_pkey PRIMARY KEY (id);


--
-- Name: remote_trial_inputs remote_trial_inputs_trial_id_input_revision_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_trial_inputs
    ADD CONSTRAINT remote_trial_inputs_trial_id_input_revision_key UNIQUE (trial_id, input_revision);


--
-- Name: remote_trial_observations remote_trial_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_trial_observations
    ADD CONSTRAINT remote_trial_observations_pkey PRIMARY KEY (id);


--
-- Name: resource_budgets resource_budgets_agent_id_kind_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_budgets
    ADD CONSTRAINT resource_budgets_agent_id_kind_key UNIQUE (agent_id, kind);


--
-- Name: resource_budgets resource_budgets_id_team_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_budgets
    ADD CONSTRAINT resource_budgets_id_team_id_key UNIQUE (id, team_id);


--
-- Name: resource_budgets resource_budgets_model_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_budgets
    ADD CONSTRAINT resource_budgets_model_id_key UNIQUE (model_id);


--
-- Name: resource_budgets resource_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_budgets
    ADD CONSTRAINT resource_budgets_pkey PRIMARY KEY (id);


--
-- Name: review_clocks review_clocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_clocks
    ADD CONSTRAINT review_clocks_pkey PRIMARY KEY (id);


--
-- Name: review_notification_items review_notification_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_notification_items
    ADD CONSTRAINT review_notification_items_pkey PRIMARY KEY (batch, clock);


--
-- Name: review_notifications review_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_notifications
    ADD CONSTRAINT review_notifications_pkey PRIMARY KEY (id);


--
-- Name: review_policies review_policies_project_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_policies
    ADD CONSTRAINT review_policies_project_id_key UNIQUE (project_id);


--
-- Name: review_policies review_policies_team_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_policies
    ADD CONSTRAINT review_policies_team_id_key UNIQUE (team_id);


--
-- Name: reviewer_handoffs reviewer_handoffs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviewer_handoffs
    ADD CONSTRAINT reviewer_handoffs_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (artifact_id, version);


--
-- Name: rule_branch_rebuilds rule_branch_rebuilds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_rebuilds
    ADD CONSTRAINT rule_branch_rebuilds_pkey PRIMARY KEY (run_id);


--
-- Name: rule_branch_rebuilds rule_branch_rebuilds_source_run_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_rebuilds
    ADD CONSTRAINT rule_branch_rebuilds_source_run_key UNIQUE (source_run);


--
-- Name: rule_branch_steps rule_branch_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_steps
    ADD CONSTRAINT rule_branch_steps_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: rule_versions rule_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions
    ADD CONSTRAINT rule_versions_pkey PRIMARY KEY (rule_id, revision);


--
-- Name: run_draft_fragments run_draft_fragments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_draft_fragments
    ADD CONSTRAINT run_draft_fragments_pkey PRIMARY KEY (run_id, seq);


--
-- Name: run_draft_fragments run_draft_fragments_run_id_ordinal_attempt_no_byte_offset_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_draft_fragments
    ADD CONSTRAINT run_draft_fragments_run_id_ordinal_attempt_no_byte_offset_key UNIQUE (run_id, ordinal, attempt_no, byte_offset);


--
-- Name: run_source_receipts run_source_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_source_receipts
    ADD CONSTRAINT run_source_receipts_pkey PRIMARY KEY (run_id, ordinal, source_id);


--
-- Name: run_source_receipts run_source_receipts_request_revision_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_source_receipts
    ADD CONSTRAINT run_source_receipts_request_revision_key UNIQUE (request_revision);


--
-- Name: run_tool_choice_waits run_tool_choice_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_tool_choice_waits
    ADD CONSTRAINT run_tool_choice_waits_pkey PRIMARY KEY (run_id);


--
-- Name: run_tool_choices run_tool_choices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_tool_choices
    ADD CONSTRAINT run_tool_choices_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: run_working_inputs run_working_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_inputs
    ADD CONSTRAINT run_working_inputs_pkey PRIMARY KEY (run_id, ordinal, attempt_no, kind, ref);


--
-- Name: run_working_parents run_working_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_parents
    ADD CONSTRAINT run_working_parents_pkey PRIMARY KEY (run_id, ordinal, attempt_no, parent_run, parent_ordinal);


--
-- Name: run_working_sets run_working_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_sets
    ADD CONSTRAINT run_working_sets_pkey PRIMARY KEY (run_id, ordinal, attempt_no);


--
-- Name: runs runs_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (id);


--
-- Name: service_action_receipts service_action_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_action_receipts
    ADD CONSTRAINT service_action_receipts_pkey PRIMARY KEY (run_id, request_key);


--
-- Name: service_delivery_requirements service_delivery_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_delivery_requirements
    ADD CONSTRAINT service_delivery_requirements_pkey PRIMARY KEY (service_id, version, item);


--
-- Name: service_edges service_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_edges
    ADD CONSTRAINT service_edges_pkey PRIMARY KEY (service_id, version, ordinal, depends_on);


--
-- Name: service_event_heads service_event_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_event_heads
    ADD CONSTRAINT service_event_heads_pkey PRIMARY KEY (run_id);


--
-- Name: service_events service_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_events
    ADD CONSTRAINT service_events_pkey PRIMARY KEY (run_id, seq);


--
-- Name: service_nodes service_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_nodes
    ADD CONSTRAINT service_nodes_pkey PRIMARY KEY (service_id, version, ordinal);


--
-- Name: service_rollbacks service_rollbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rollbacks
    ADD CONSTRAINT service_rollbacks_pkey PRIMARY KEY (service_id, actor, request_key);


--
-- Name: service_rollbacks service_rollbacks_service_id_routing_revision_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rollbacks
    ADD CONSTRAINT service_rollbacks_service_id_routing_revision_key UNIQUE (service_id, routing_revision);


--
-- Name: service_supplements service_supplements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_supplements
    ADD CONSTRAINT service_supplements_pkey PRIMARY KEY (run_id, ordinal, revision);


--
-- Name: service_tool_choices service_tool_choices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tool_choices
    ADD CONSTRAINT service_tool_choices_pkey PRIMARY KEY (service_id, version, ordinal);


--
-- Name: service_tool_choices service_tool_choices_service_id_version_selector_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tool_choices
    ADD CONSTRAINT service_tool_choices_service_id_version_selector_key UNIQUE (service_id, version, selector);


--
-- Name: service_versions service_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_versions
    ADD CONSTRAINT service_versions_pkey PRIMARY KEY (service_id, version);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: skill_dependencies skill_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT skill_dependencies_pkey PRIMARY KEY (skill_id, revision, needs_skill);


--
-- Name: skill_dependencies skill_dependencies_skill_id_revision_position_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT skill_dependencies_skill_id_revision_position_key UNIQUE (skill_id, revision, "position");


--
-- Name: skill_files skill_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_files
    ADD CONSTRAINT skill_files_pkey PRIMARY KEY (skill_id, revision, path);


--
-- Name: skill_packs skill_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_pkey PRIMARY KEY (id);


--
-- Name: skill_packs skill_packs_team_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_team_id_name_key UNIQUE (team_id, name);


--
-- Name: skill_revisions skill_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_revisions
    ADD CONSTRAINT skill_revisions_pkey PRIMARY KEY (skill_id, revision);


--
-- Name: source_assessments source_assessments_artifact_id_artifact_version_source_id_o_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_assessments
    ADD CONSTRAINT source_assessments_artifact_id_artifact_version_source_id_o_key UNIQUE (artifact_id, artifact_version, source_id, observed_version, revoked);


--
-- Name: source_assessments source_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_assessments
    ADD CONSTRAINT source_assessments_pkey PRIMARY KEY (id);


--
-- Name: source_object_cleanup source_object_cleanup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_object_cleanup
    ADD CONSTRAINT source_object_cleanup_pkey PRIMARY KEY (source_id, hash);


--
-- Name: source_passages source_passages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_passages
    ADD CONSTRAINT source_passages_pkey PRIMARY KEY (source_id, version, start_char);


--
-- Name: source_versions source_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_versions
    ADD CONSTRAINT source_versions_pkey PRIMARY KEY (source_id, version);


--
-- Name: sources sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (id);


--
-- Name: spend spend_op_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_op_key_key UNIQUE (op_key);


--
-- Name: spend spend_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_pkey PRIMARY KEY (id);


--
-- Name: starter_samples starter_samples_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.starter_samples
    ADD CONSTRAINT starter_samples_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: starter_samples starter_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.starter_samples
    ADD CONSTRAINT starter_samples_pkey PRIMARY KEY (project_id);


--
-- Name: step_dispatch_waits step_dispatch_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_dispatch_waits
    ADD CONSTRAINT step_dispatch_waits_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: step_rule_replacements step_rule_replacements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_rule_replacements
    ADD CONSTRAINT step_rule_replacements_pkey PRIMARY KEY (run_id, ordinal, rule_id);


--
-- Name: step_rule_waits step_rule_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_rule_waits
    ADD CONSTRAINT step_rule_waits_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: step_tool_choice_waits step_tool_choice_waits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_tool_choice_waits
    ADD CONSTRAINT step_tool_choice_waits_pkey PRIMARY KEY (run_id, ordinal);


--
-- Name: superseded_calls superseded_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superseded_calls
    ADD CONSTRAINT superseded_calls_pkey PRIMARY KEY (run_id, ordinal, attempt_no);


--
-- Name: superseded_calls superseded_calls_review_control_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superseded_calls
    ADD CONSTRAINT superseded_calls_review_control_key UNIQUE (review_control);


--
-- Name: takeover_reviews takeover_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeover_reviews
    ADD CONSTRAINT takeover_reviews_pkey PRIMARY KEY (assignment, artifact_id, version);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (team_id, member_id);


--
-- Name: team_rules team_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rules
    ADD CONSTRAINT team_rules_pkey PRIMARY KEY (id);


--
-- Name: team_starters team_starters_agent_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_starters
    ADD CONSTRAINT team_starters_agent_id_key UNIQUE (agent_id);


--
-- Name: team_starters team_starters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_starters
    ADD CONSTRAINT team_starters_pkey PRIMARY KEY (team_id, slot);


--
-- Name: teams teams_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_name_key UNIQUE (name);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: telemetry_outbox telemetry_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telemetry_outbox
    ADD CONSTRAINT telemetry_outbox_pkey PRIMARY KEY (run_id, ordinal, call_attempt);


--
-- Name: text_reply_checkpoints text_reply_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.text_reply_checkpoints
    ADD CONSTRAINT text_reply_checkpoints_pkey PRIMARY KEY (run_id, ordinal, attempt_no);


--
-- Name: trace_events trace_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trace_events
    ADD CONSTRAINT trace_events_pkey PRIMARY KEY (seq);


--
-- Name: trace_grants trace_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trace_grants
    ADD CONSTRAINT trace_grants_pkey PRIMARY KEY (run_id, member_id, scope);


--
-- Name: validation_files validation_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_files
    ADD CONSTRAINT validation_files_pkey PRIMARY KEY (trial_id);


--
-- Name: validation_pictures validation_pictures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_pictures
    ADD CONSTRAINT validation_pictures_pkey PRIMARY KEY (trial_id);


--
-- Name: validation_reviews validation_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_reviews
    ADD CONSTRAINT validation_reviews_pkey PRIMARY KEY (trial_id);


--
-- Name: validation_skill_inputs validation_skill_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_skill_inputs
    ADD CONSTRAINT validation_skill_inputs_pkey PRIMARY KEY (trial_id, skill_id);


--
-- Name: validation_withdrawals validation_withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_withdrawals
    ADD CONSTRAINT validation_withdrawals_pkey PRIMARY KEY (trial_id);


--
-- Name: validations validations_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: validations validations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_pkey PRIMARY KEY (id);


--
-- Name: workflow_template_adoptions workflow_template_adoptions_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_adoptions
    ADD CONSTRAINT workflow_template_adoptions_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: workflow_template_adoptions workflow_template_adoptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_adoptions
    ADD CONSTRAINT workflow_template_adoptions_pkey PRIMARY KEY (project_id, project_revision);


--
-- Name: workflow_template_builds workflow_template_builds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_builds
    ADD CONSTRAINT workflow_template_builds_pkey PRIMARY KEY (template_id, version, agent_id, agent_revision);


--
-- Name: workflow_template_uses workflow_template_uses_actor_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_uses
    ADD CONSTRAINT workflow_template_uses_actor_request_key_key UNIQUE (actor, request_key);


--
-- Name: workflow_template_uses workflow_template_uses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_uses
    ADD CONSTRAINT workflow_template_uses_pkey PRIMARY KEY (project_id);


--
-- Name: workflow_template_uses workflow_template_uses_project_id_template_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_uses
    ADD CONSTRAINT workflow_template_uses_project_id_template_id_key UNIQUE (project_id, template_id);


--
-- Name: workflow_template_versions workflow_template_versions_author_request_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_versions
    ADD CONSTRAINT workflow_template_versions_author_request_key_key UNIQUE (author, request_key);


--
-- Name: workflow_template_versions workflow_template_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_versions
    ADD CONSTRAINT workflow_template_versions_pkey PRIMARY KEY (template_id, version);


--
-- Name: workflow_templates workflow_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_pkey PRIMARY KEY (id);


--
-- Name: agent_improvement_by_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_improvement_by_agent ON public.agent_improvements USING btree (agent_id, created_at DESC);


--
-- Name: agent_publications_by_revision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_publications_by_revision ON public.agent_publications USING btree (agent_id, revision, generation DESC);


--
-- Name: agent_release_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_release_history ON public.agent_release_requests USING btree (agent_id, revision, requested_at DESC);


--
-- Name: agent_release_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_release_pending ON public.agent_release_requests USING btree (agent_id, revision) WHERE (state = 'pending'::text);


--
-- Name: agent_skill_bindings_by_skill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_skill_bindings_by_skill ON public.agent_skill_bindings USING btree (skill_id, skill_revision);


--
-- Name: artifact_files_by_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX artifact_files_by_hash ON public.artifact_files USING btree (object_hash);


--
-- Name: artifact_remote_receipts_by_call; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX artifact_remote_receipts_by_call ON public.artifact_remote_receipts USING btree (run_id, ordinal, attempt_no);


--
-- Name: artifact_requirement_evidence_attempt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX artifact_requirement_evidence_attempt ON public.artifact_requirement_evidence USING btree (run_id, ordinal, attempt_no);


--
-- Name: artifact_upstream_context_by_call; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX artifact_upstream_context_by_call ON public.artifact_upstream_context USING btree (run_id, ordinal, attempt_no);


--
-- Name: artifacts_review_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX artifacts_review_project ON public.artifacts USING btree (project_id);


--
-- Name: budget_requests_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_requests_project ON public.budget_requests USING btree (project_id, created_at DESC);


--
-- Name: budget_requests_team; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_requests_team ON public.budget_requests USING btree (team_id, state, created_at DESC);


--
-- Name: call_review_step; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX call_review_step ON public.call_reviews USING btree (run_id, ordinal);


--
-- Name: calls_by_project_grant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calls_by_project_grant ON public.project_agent_calls USING btree (grant_id);


--
-- Name: change_open_feedback; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX change_open_feedback ON public.change_batches USING btree (feedback_id) WHERE (disposition = ANY (ARRAY['pending'::text, 'conflict'::text]));


--
-- Name: channel_attachment_jobs_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_attachment_jobs_due ON public.channel_attachment_jobs USING btree (tenant, next_at);


--
-- Name: channel_card_action_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_card_action_expiry ON public.channel_card_actions USING btree (expires_at);


--
-- Name: channel_events_message; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX channel_events_message ON public.channel_events USING btree (tenant, message_id);


--
-- Name: channel_proposals_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_proposals_expiry ON public.channel_proposals USING btree (expires_at);


--
-- Name: channel_remote_input_proposals_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX channel_remote_input_proposals_expiry ON public.channel_remote_input_proposals USING btree (expires_at);


--
-- Name: correction_batch_issues; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX correction_batch_issues ON public.invocations USING gin (input_issue jsonb_path_ops) WHERE (jsonb_typeof(input_issue) = 'array'::text);


--
-- Name: correction_batch_mappings; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX correction_batch_mappings ON public.call_reviews USING gin (input_mapping jsonb_path_ops) WHERE (jsonb_typeof(input_mapping) = 'array'::text);


--
-- Name: correction_issue_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX correction_issue_source ON public.invocations USING btree (((input_issue ->> 'source'::text))) WHERE (input_issue IS NOT NULL);


--
-- Name: correction_mapping_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX correction_mapping_source ON public.call_reviews USING btree (((input_mapping ->> 'source'::text))) WHERE (input_mapping IS NOT NULL);


--
-- Name: current_project_agent_grant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX current_project_agent_grant ON public.project_agent_grants USING btree (project_id, agent_id) WHERE (revoked_at IS NULL);


--
-- Name: delivery_evidence_by_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_evidence_by_source ON public.delivery_source_evidence USING btree (source_id, delivery_id);


--
-- Name: delivery_item_assessments_latest; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_item_assessments_latest ON public.delivery_item_assessments USING btree (project_id, plan_version, item, id DESC);


--
-- Name: feedback_artifact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_artifact ON public.feedback USING btree (artifact_id, created_at);


--
-- Name: financial_bill_rows; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_bill_rows ON public.bill_rows USING btree (spend_id, recorded_at);


--
-- Name: im_events_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX im_events_due ON public.im_events USING btree (connection, next_at, received_at) WHERE (state = ANY (ARRAY['received'::text, 'ready'::text, 'sending'::text]));


--
-- Name: im_pending_in_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX im_pending_in_thread ON public.im_events USING btree (connection, chat_id, thread_id, received_at, event_id) WHERE (state = 'received'::text);


--
-- Name: im_replies_in_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX im_replies_in_thread ON public.im_events USING btree (connection, chat_id, thread_id, received_at, event_id) WHERE (state = ANY (ARRAY['ready'::text, 'sending'::text]));


--
-- Name: im_service_launch_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX im_service_launch_pending ON public.im_service_launches USING btree (binding_id, chat_id, thread_id) WHERE (run_id IS NULL);


--
-- Name: im_service_launch_retention; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX im_service_launch_retention ON public.im_service_launches USING btree (COALESCE(accepted_at, expires_at));


--
-- Name: invocation_files_by_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invocation_files_by_hash ON public.invocation_files USING btree (object_hash);


--
-- Name: lookup_index_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lookup_index_due ON public.lookup_index_waits USING btree (next_check_at, run_id) WHERE active;


--
-- Name: lookup_index_owns_block; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lookup_index_owns_block ON public.lookup_index_waits USING btree (run_id) WHERE (active AND (step_wait_revision IS NULL));


--
-- Name: lookup_index_step_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lookup_index_step_expiry ON public.lookup_index_waits USING btree (deadline, run_id, ordinal) WHERE (active AND (step_wait_revision IS NOT NULL) AND (NOT expiry_announced));


--
-- Name: lookup_index_step_wakes; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lookup_index_step_wakes ON public.lookup_index_waits USING btree (next_check_at, run_id, ordinal) WHERE wake_pending;


--
-- Name: maintenance_proposed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_proposed ON public.agents USING btree (team_id, proposed_owner) WHERE (proposed_owner IS NOT NULL);


--
-- Name: management_department_grant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX management_department_grant ON public.management_grants USING btree (member_id, department_id) WHERE ((revoked_at IS NULL) AND (department_id IS NOT NULL));


--
-- Name: management_enterprise_grant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX management_enterprise_grant ON public.management_grants USING btree (member_id) WHERE ((enterprise_id IS TRUE) AND (revoked_at IS NULL));


--
-- Name: management_run_spend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX management_run_spend ON public.spend USING btree (run_id) WHERE (run_id IS NOT NULL);


--
-- Name: management_runs_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX management_runs_page ON public.runs USING btree (created_at DESC, id DESC);


--
-- Name: management_team_grant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX management_team_grant ON public.management_grants USING btree (member_id, team_id) WHERE ((revoked_at IS NULL) AND (team_id IS NOT NULL));


--
-- Name: member_audit_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_audit_page ON public.audit_events USING btree (subject, seq DESC) WHERE (action = ANY (ARRAY['member.enroll'::text, 'member.change'::text, 'department.assign'::text]));


--
-- Name: member_team_audit_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_team_audit_page ON public.audit_events USING btree (((detail ->> 'member'::text)), seq DESC) WHERE (action = 'team.membership'::text);


--
-- Name: messages_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_project ON public.messages USING btree (project_id, seq);


--
-- Name: messages_project_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_project_user ON public.messages USING btree (project_id, seq) WHERE (kind = 'user'::text);


--
-- Name: model_probes_team_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_probes_team_time ON public.model_probes USING btree (team_id, created_at DESC);


--
-- Name: model_replacements_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_replacements_source ON public.model_replacements USING btree (source_id, source_revision, created_at DESC);


--
-- Name: oidc_flow_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oidc_flow_expiry ON public.oidc_flows USING btree (expires_at);


--
-- Name: oidc_session_binding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oidc_session_binding ON public.sessions USING btree (oidc_binding) WHERE (oidc_binding IS NOT NULL);


--
-- Name: one_pending_review_digest; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX one_pending_review_digest ON public.review_notifications USING btree (binding) WHERE (status = 'pending'::text);


--
-- Name: open_lookup_question_payloads; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX open_lookup_question_payloads ON public.lookup_question_handoffs USING btree (run_id, parent, parent_attempt) WHERE (question IS NOT NULL);


--
-- Name: open_review_clock; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX open_review_clock ON public.review_clocks USING btree (action_key) WHERE (closed_at IS NULL);


--
-- Name: pending_invocation_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_invocation_start ON public.invocations USING btree (started_at) WHERE (status = 'submitted'::text);


--
-- Name: pending_lookup_turns; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_lookup_turns ON public.lookup_turns USING btree (run_id, plan_version) WHERE (decision IS NOT NULL);


--
-- Name: pending_management_export_cleanup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_management_export_cleanup ON public.management_exports USING btree (expires_at) WHERE (payload IS NOT NULL);


--
-- Name: pending_model_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pending_model_key ON public.model_key_candidates USING btree (resource_id, resource_revision) WHERE (state = 'pending'::text);


--
-- Name: pending_rule_maintenance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_rule_maintenance ON public.team_rules USING btree (team_id, proposed_owner) WHERE (proposed_owner IS NOT NULL);


--
-- Name: pending_text_reply_payloads; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_text_reply_payloads ON public.text_reply_checkpoints USING btree (run_id, ordinal, attempt_no) WHERE (state = 'pending'::text);


--
-- Name: pinned_source_plans; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pinned_source_plans ON public.plan_sources USING btree (source_id, project_id, plan_version);


--
-- Name: planning_request_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX planning_request_history ON public.planning_requests USING btree (project_id, actor, created_at DESC, id DESC);


--
-- Name: preference_purge_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX preference_purge_due ON public.preferences USING btree (LEAST(deleted_at, expires_at)) WHERE (purged_at IS NULL);


--
-- Name: project_session_event_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_session_event_expiry ON public.project_session_events USING btree (created_at);


--
-- Name: remote_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX remote_due ON public.remote_jobs USING btree (next_at) WHERE (phase = 'checking'::text);


--
-- Name: remote_task_input_once; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX remote_task_input_once ON public.remote_task_inputs USING btree (run_id, ordinal, input_revision) WHERE (state <> 'rejected'::text);


--
-- Name: remote_task_input_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX remote_task_input_queue ON public.remote_task_inputs USING btree (created_at) WHERE (state = ANY (ARRAY['queued'::text, 'submitted'::text]));


--
-- Name: remote_trial_observations_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX remote_trial_observations_history ON public.remote_trial_observations USING btree (trial_id, id);


--
-- Name: remote_wake; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX remote_wake ON public.remote_jobs USING btree (run_id) WHERE wake;


--
-- Name: review_clock_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX review_clock_project ON public.review_clocks USING btree (project_id) WHERE (closed_at IS NULL);


--
-- Name: review_notification_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX review_notification_due ON public.review_notifications USING btree (tenant, next_at) WHERE (status = 'pending'::text);


--
-- Name: review_notification_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX review_notification_history ON public.review_notification_items USING btree (clock, clock_revision, phase);


--
-- Name: review_project_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX review_project_scan ON public.projects USING btree (id) WHERE (stage = 'review'::text);


--
-- Name: reviewer_handoffs_nominee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reviewer_handoffs_nominee ON public.reviewer_handoffs USING btree (successor) WHERE (state = 'pending'::text);


--
-- Name: reviewer_handoffs_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reviewer_handoffs_pending ON public.reviewer_handoffs USING btree (project_id) WHERE (state = 'pending'::text);


--
-- Name: reviewer_recovery_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reviewer_recovery_scope ON public.reviewer_handoffs USING btree (project_id, successor) WHERE (recovery_until IS NOT NULL);


--
-- Name: rule_branch_artifact_editions; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX rule_branch_artifact_editions ON public.rule_branch_steps USING btree (artifact_id, result_version) WHERE ((mode <> 'reuse'::text) AND (result_version IS NOT NULL));


--
-- Name: rule_handoff_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rule_handoff_history ON public.audit_events USING btree (subject, seq) WHERE (action ~~ 'rule.maintenance.%'::text);


--
-- Name: rule_project_references; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rule_project_references ON public.plan_rules USING btree (rule_id, project_id, plan_version);


--
-- Name: run_draft_fragment_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX run_draft_fragment_expiry ON public.run_draft_fragments USING btree (created_at);


--
-- Name: run_source_receipts_by_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX run_source_receipts_by_source ON public.run_source_receipts USING btree (source_id);


--
-- Name: run_working_inputs_by_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX run_working_inputs_by_ref ON public.run_working_inputs USING btree (kind, ref, revision);


--
-- Name: runs_finished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_finished ON public.runs USING btree (finished_at) WHERE (finished_at IS NOT NULL);


--
-- Name: runs_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_project ON public.runs USING btree (project_id, created_at);


--
-- Name: runs_service_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_service_actor ON public.runs USING btree (service_id, actor) WHERE (service_id IS NOT NULL);


--
-- Name: runs_trace_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX runs_trace_expiry ON public.runs USING btree (trace_expires_at) WHERE (trace_expires_at IS NOT NULL);


--
-- Name: single_redo_per_attempt; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX single_redo_per_attempt ON public.call_reviews USING btree (run_id, ordinal, attempt_no) WHERE ((decision = 'redo'::text) AND (superseded_by IS NULL));


--
-- Name: skill_files_by_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX skill_files_by_hash ON public.skill_files USING btree (object_hash);


--
-- Name: source_cleanup_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_cleanup_hash ON public.source_object_cleanup USING btree (hash);


--
-- Name: source_files_by_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_files_by_hash ON public.source_versions USING btree (object_hash) WHERE (object_hash IS NOT NULL);


--
-- Name: source_passage_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_passage_pending ON public.source_passages USING btree (source_id, version, start_char) WHERE (embedding IS NULL);


--
-- Name: source_purge_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_purge_due ON public.sources USING btree (purge_due) WHERE ((purged_at IS NULL) AND (recycled_at IS NOT NULL));


--
-- Name: source_upload_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX source_upload_identity ON public.sources USING btree (project_id, created_by, upload_key) WHERE (upload_key IS NOT NULL);


--
-- Name: spend_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spend_project ON public.spend USING btree (project_id) WHERE (project_id IS NOT NULL);


--
-- Name: spend_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spend_resource ON public.spend USING btree (resource_budget) WHERE (resource_budget IS NOT NULL);


--
-- Name: spend_team; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spend_team ON public.spend USING btree (team_id);


--
-- Name: starter_samples_team; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX starter_samples_team ON public.starter_samples USING btree (team_id);


--
-- Name: telemetry_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX telemetry_due ON public.telemetry_outbox USING btree (next_at) WHERE (outcome = 'pending'::text);


--
-- Name: trace_events_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trace_events_run ON public.trace_events USING btree (run_id, seq);


--
-- Name: unread_account_notices; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unread_account_notices ON public.account_notices USING btree (member_id, event_seq) WHERE (read_at IS NULL);


--
-- Name: validation_files_by_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX validation_files_by_hash ON public.validation_files USING btree (object_hash);


--
-- Name: validation_pictures_by_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX validation_pictures_by_hash ON public.validation_pictures USING btree (object_hash);


--
-- Name: validation_skill_coverage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX validation_skill_coverage ON public.validation_skill_inputs USING btree (skill_id, skill_revision, trial_id);


--
-- Name: validations_check_recency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX validations_check_recency ON public.validations USING btree (check_id, created_at DESC, id DESC) WHERE (check_id IS NOT NULL);


--
-- Name: validations_revision_pass; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX validations_revision_pass ON public.validations USING btree (agent_id, revision) WHERE (status = 'passed'::text);


--
-- Name: workflow_templates_by_team; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflow_templates_by_team ON public.workflow_templates USING btree (team_id, updated_at DESC) WHERE (archived_at IS NULL);


--
-- Name: delivery_recipient_manifests _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.delivery_recipient_manifests AS
 SELECT d.project_id,
    d.id,
    d.confirmed_by,
    d.created_at,
    d.handoff,
    jsonb_agg(jsonb_build_object('artifact', i.artifact_id, 'step', i.ordinal, 'name', i.name, 'version', i.version, 'body', v.body, 'dependencies', i.dependencies) ORDER BY i.ordinal) AS items,
    d.partial,
    d.coverage
   FROM ((public.deliveries d
     JOIN public.delivery_recipient_items i ON ((i.delivery_id = d.id)))
     JOIN public.artifact_versions v ON (((v.artifact_id = i.artifact_id) AND (v.version = i.version))))
  GROUP BY d.id;


--
-- Name: artifact_versions bind_artifact_copy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER bind_artifact_copy BEFORE INSERT ON public.artifact_versions FOR EACH ROW EXECUTE FUNCTION public.bind_artifact_copy();


--
-- Name: team_members cancel_maintenance_on_departure; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancel_maintenance_on_departure AFTER DELETE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.cancel_departed_maintenance_offer();


--
-- Name: spend charge_resource_required; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER charge_resource_required BEFORE INSERT ON public.spend FOR EACH ROW EXECUTE FUNCTION public.require_charge_resource();


--
-- Name: projects close_project_review_clocks; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER close_project_review_clocks AFTER UPDATE OF stage ON public.projects FOR EACH ROW WHEN (((old.stage = 'review'::text) AND (new.stage <> 'review'::text))) EXECUTE FUNCTION public.close_project_review_clocks();


--
-- Name: projects close_terminal_budget_requests; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER close_terminal_budget_requests AFTER UPDATE OF stage ON public.projects FOR EACH ROW WHEN (((new.stage = ANY (ARRAY['delivered'::text, 'adopted'::text, 'cancelled'::text, 'failed'::text])) AND (new.stage IS DISTINCT FROM old.stage))) EXECUTE FUNCTION public.close_budget_requests();


--
-- Name: agents count_agent_publication; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER count_agent_publication BEFORE UPDATE OF published_revision ON public.agents FOR EACH ROW WHEN ((old.published_revision IS DISTINCT FROM new.published_revision)) EXECUTE FUNCTION public.count_agent_publication();


--
-- Name: runs discard_text_replies_on_run_end; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER discard_text_replies_on_run_end AFTER UPDATE OF status ON public.runs FOR EACH ROW WHEN (((new.status = ANY (ARRAY['completed'::text, 'cancelled'::text, 'failed'::text])) AND (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.discard_run_text_replies();


--
-- Name: run_working_sets discard_text_reply_on_input_invalidation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER discard_text_reply_on_input_invalidation AFTER UPDATE OF invalidated_at ON public.run_working_sets FOR EACH ROW WHEN (((old.invalidated_at IS NULL) AND (new.invalidated_at IS NOT NULL))) EXECUTE FUNCTION public.discard_invalidated_text_reply();


--
-- Name: members end_member_management; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER end_member_management AFTER UPDATE ON public.members FOR EACH ROW WHEN (((old.enabled AND (NOT new.enabled)) OR (old.department_id IS DISTINCT FROM new.department_id))) EXECUTE FUNCTION public.end_management_grants();


--
-- Name: team_members end_team_management; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER end_team_management AFTER DELETE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.end_management_grants();


--
-- Name: runs ended_lookup_turns; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ended_lookup_turns AFTER UPDATE OF status ON public.runs FOR EACH ROW WHEN (((new.status IS DISTINCT FROM old.status) AND (new.status = ANY (ARRAY['completed'::text, 'failed'::text, 'cancelled'::text])))) EXECUTE FUNCTION public.clear_ended_lookup_turns();


--
-- Name: projects enter_review_period; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER enter_review_period BEFORE UPDATE OF stage ON public.projects FOR EACH ROW WHEN ((new.stage IS DISTINCT FROM old.stage)) EXECUTE FUNCTION public.enter_review_period();


--
-- Name: invocations guard_scoped_preference_dispatch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER guard_scoped_preference_dispatch BEFORE INSERT OR UPDATE OF attempt_no ON public.invocations FOR EACH ROW EXECUTE FUNCTION public.require_scoped_preference_worker();


--
-- Name: invocations guard_step_dispatch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER guard_step_dispatch BEFORE INSERT OR UPDATE OF attempt_no ON public.invocations FOR EACH ROW EXECUTE FUNCTION public.require_step_dispatch_worker();


--
-- Name: invocations guard_text_agent_choice_dispatch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER guard_text_agent_choice_dispatch BEFORE INSERT OR UPDATE OF attempt_no ON public.invocations FOR EACH ROW EXECUTE FUNCTION public.require_text_agent_choice_worker();


--
-- Name: plan_preferences guard_unscoped_preference_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER guard_unscoped_preference_binding BEFORE INSERT OR UPDATE ON public.plan_preferences FOR EACH ROW EXECUTE FUNCTION public.guard_unscoped_preference_binding();


--
-- Name: members handoff_member_changed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER handoff_member_changed AFTER UPDATE OF enabled, role ON public.members FOR EACH ROW WHEN (((old.enabled AND (NOT new.enabled)) OR ((old.role = 'admin'::text) AND (new.role <> 'admin'::text)))) EXECUTE FUNCTION public.expire_inactive_reviewer_offers();


--
-- Name: projects handoff_project_closed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER handoff_project_closed AFTER UPDATE OF stage ON public.projects FOR EACH ROW WHEN ((new.stage = ANY (ARRAY['delivered'::text, 'adopted'::text, 'cancelled'::text, 'failed'::text]))) EXECUTE FUNCTION public.close_responsibility_offers();


--
-- Name: projects handoff_service_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER handoff_service_event AFTER UPDATE OF final_reviewer ON public.projects FOR EACH ROW WHEN ((old.final_reviewer IS DISTINCT FROM new.final_reviewer)) EXECUTE FUNCTION public.publish_reviewer_event();


--
-- Name: agent_revisions inherit_agent_checks; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inherit_agent_checks AFTER INSERT ON public.agent_revisions FOR EACH ROW WHEN ((new.revision > 1)) EXECUTE FUNCTION public.inherit_agent_checks();


--
-- Name: team_rules initial_rule_owner; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER initial_rule_owner BEFORE INSERT ON public.team_rules FOR EACH ROW EXECUTE FUNCTION public.initialize_rule_maintenance();


--
-- Name: team_rules invalidate_disabled_working_rules; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER invalidate_disabled_working_rules AFTER UPDATE OF disabled ON public.team_rules FOR EACH ROW WHEN (((NOT old.disabled) AND new.disabled)) EXECUTE FUNCTION public.invalidate_run_working_input('rule');


--
-- Name: preferences invalidate_edited_working_preferences; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER invalidate_edited_working_preferences AFTER UPDATE ON public.preferences FOR EACH ROW WHEN (((old.revision IS DISTINCT FROM new.revision) OR (old.enabled AND (NOT new.enabled)) OR ((NOT old.departure_guard) AND new.departure_guard) OR ((old.deleted_at IS NULL) AND (new.deleted_at IS NOT NULL)))) EXECUTE FUNCTION public.invalidate_run_working_input('preference');


--
-- Name: members invalidate_emergency_on_demotion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER invalidate_emergency_on_demotion AFTER UPDATE OF role ON public.members FOR EACH ROW WHEN (((old.role = 'admin'::text) AND (new.role <> 'admin'::text))) EXECUTE FUNCTION public.invalidate_emergency_session();


--
-- Name: sources invalidate_withdrawn_working_sources; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER invalidate_withdrawn_working_sources AFTER UPDATE OF revoked_at ON public.sources FOR EACH ROW WHEN (((old.revoked_at IS NULL) AND (new.revoked_at IS NOT NULL))) EXECUTE FUNCTION public.invalidate_run_working_input('source');


--
-- Name: run_working_sets local_action_working_scope_invalidated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER local_action_working_scope_invalidated AFTER UPDATE OF invalidated_at ON public.run_working_sets FOR EACH ROW WHEN (((old.invalidated_at IS NULL) AND (new.invalidated_at IS NOT NULL))) EXECUTE FUNCTION public.clear_invalidated_local_action();


--
-- Name: lookup_turns local_observation_decision_ended; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER local_observation_decision_ended AFTER UPDATE OF decision ON public.lookup_turns FOR EACH ROW WHEN (((old.decision IS NOT NULL) AND (new.decision IS NULL))) EXECUTE FUNCTION public.discard_pending_local_observation();


--
-- Name: run_working_sets lookup_question_parent_invalidated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER lookup_question_parent_invalidated AFTER UPDATE OF invalidated_at ON public.run_working_sets FOR EACH ROW WHEN (((old.invalidated_at IS NULL) AND (new.invalidated_at IS NOT NULL))) EXECUTE FUNCTION public.erase_lookup_question_on_invalidation();


--
-- Name: runs lookup_question_run_ended; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER lookup_question_run_ended AFTER UPDATE OF status ON public.runs FOR EACH ROW WHEN (((new.status IS DISTINCT FROM old.status) AND (new.status = ANY (ARRAY['completed'::text, 'cancelled'::text, 'failed'::text])))) EXECUTE FUNCTION public.erase_lookup_questions_on_run_end();


--
-- Name: members member_account_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER member_account_change BEFORE UPDATE OF enabled, role, departed_at ON public.members FOR EACH ROW WHEN ((((old.enabled IS DISTINCT FROM new.enabled) OR (old.role IS DISTINCT FROM new.role)) OR (old.departed_at IS DISTINCT FROM new.departed_at))) EXECUTE FUNCTION public.advance_account_revision();


--
-- Name: audit_events notice_on_account_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notice_on_account_change AFTER INSERT ON public.audit_events FOR EACH ROW WHEN (((new.action = 'member.change'::text) AND (((new.detail ->> 'role'::text) IS DISTINCT FROM (new.detail ->> 'oldRole'::text)) OR ((new.detail ->> 'enabled'::text) IS DISTINCT FROM (new.detail ->> 'oldEnabled'::text)) OR (COALESCE((new.detail ->> 'employment'::text), ''::text) <> ''::text)))) EXECUTE FUNCTION public.notify_account_change();


--
-- Name: projects pin_planner_on_creation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pin_planner_on_creation BEFORE INSERT ON public.projects FOR EACH ROW EXECUTE FUNCTION public.pin_project_planner();


--
-- Name: projects project_budget_created; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_budget_created AFTER INSERT ON public.projects FOR EACH ROW EXECUTE FUNCTION public.create_project_budget();


--
-- Name: projects project_originating_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_originating_department BEFORE INSERT ON public.projects FOR EACH ROW EXECUTE FUNCTION public.capture_originating_department('owner');


--
-- Name: projects project_recovery_ended; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_recovery_ended AFTER UPDATE OF stage, reviewer_assignment ON public.projects FOR EACH ROW WHEN (((old.reviewer_assignment IS NOT NULL) AND ((new.reviewer_assignment IS DISTINCT FROM old.reviewer_assignment) OR ((new.stage IS DISTINCT FROM old.stage) AND (new.stage = ANY (ARRAY['delivered'::text, 'adopted'::text, 'cancelled'::text, 'failed'::text])))))) EXECUTE FUNCTION public.end_recovery_after_project_change();


--
-- Name: invocations project_session_attempt_changed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_attempt_changed AFTER UPDATE ON public.invocations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((((new.status IS DISTINCT FROM old.status) OR (new.attempt_no IS DISTINCT FROM old.attempt_no)) OR (new.remote_status IS DISTINCT FROM old.remote_status)) OR ((new.result IS NULL) IS DISTINCT FROM (old.result IS NULL)))) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: invocations project_session_attempt_created; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_attempt_created AFTER INSERT ON public.invocations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: run_draft_fragments project_session_draft; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_draft AFTER INSERT ON public.run_draft_fragments DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: run_working_sets project_session_invalidation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_invalidation AFTER UPDATE ON public.run_working_sets DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.invalidated_at IS DISTINCT FROM old.invalidated_at)) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: local_action_observations project_session_local_observation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_local_observation AFTER INSERT ON public.local_action_observations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: lookup_turns project_session_lookup; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_lookup AFTER INSERT OR UPDATE ON public.lookup_turns DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: messages project_session_message; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_message AFTER INSERT ON public.messages DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: projects project_session_project; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_project AFTER UPDATE ON public.projects DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((((new.revision IS DISTINCT FROM old.revision) OR (new.stage IS DISTINCT FROM old.stage)) OR (new.owner IS DISTINCT FROM old.owner)) OR (new.final_reviewer IS DISTINCT FROM old.final_reviewer))) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: lookup_question_handoffs project_session_question_erased; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_question_erased AFTER UPDATE ON public.lookup_question_handoffs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.question IS NOT NULL) AND (new.question IS NULL))) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: remote_task_inputs project_session_remote_input; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_remote_input AFTER UPDATE ON public.remote_task_inputs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.state IS DISTINCT FROM old.state)) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: remote_jobs project_session_remote_job; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_remote_job AFTER UPDATE ON public.remote_jobs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((((new.phase IS DISTINCT FROM old.phase) OR (new.detail IS DISTINCT FROM old.detail)) OR (new.input_revision IS DISTINCT FROM old.input_revision))) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: text_reply_checkpoints project_session_reply_discarded; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_reply_discarded AFTER UPDATE ON public.text_reply_checkpoints DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((old.state = 'pending'::text) AND (new.state = 'discarded'::text))) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: runs project_session_run_changed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_run_changed AFTER UPDATE ON public.runs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((new.status IS DISTINCT FROM old.status) OR (new.control_revision IS DISTINCT FROM old.control_revision))) EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: runs project_session_run_created; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER project_session_run_created AFTER INSERT ON public.runs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.publish_project_session_event();


--
-- Name: sources purge_csv_header_copies; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER purge_csv_header_copies AFTER UPDATE OF purged_at ON public.sources FOR EACH ROW WHEN (((old.purged_at IS NULL) AND (new.purged_at IS NOT NULL))) EXECUTE FUNCTION public.purge_correction_headers();


--
-- Name: members recovery_account_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recovery_account_change AFTER UPDATE OF role, enabled ON public.members FOR EACH ROW WHEN (((old.enabled AND (NOT new.enabled)) OR ((old.role = 'admin'::text) AND (new.role <> 'admin'::text)))) EXECUTE FUNCTION public.end_recovery_on_account_change();


--
-- Name: team_members recovery_team_loss; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recovery_team_loss AFTER DELETE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.end_recovery_on_team_loss();


--
-- Name: agent_revisions register_agent_budget; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER register_agent_budget AFTER INSERT ON public.agent_revisions FOR EACH ROW EXECUTE FUNCTION public.register_resource_budget();


--
-- Name: model_resources register_model_budget; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER register_model_budget AFTER INSERT ON public.model_resources FOR EACH ROW EXECUTE FUNCTION public.register_resource_budget();


--
-- Name: source_versions release_extraction_locations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER release_extraction_locations BEFORE UPDATE OF extracted ON public.source_versions FOR EACH ROW WHEN (((new.extracted IS NULL) AND (new.object_hash IS NULL))) EXECUTE FUNCTION public.clear_extraction_locations();


--
-- Name: members remove_departed_oidc; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER remove_departed_oidc AFTER UPDATE OF departed_at ON public.members FOR EACH ROW WHEN (((old.departed_at IS NULL) AND (new.departed_at IS NOT NULL))) EXECUTE FUNCTION public.remove_departed_oidc();


--
-- Name: team_members removed_budget_owner; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER removed_budget_owner AFTER DELETE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.clear_budget_owner();


--
-- Name: reviews require_review_preference_inputs; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER require_review_preference_inputs BEFORE INSERT ON public.reviews FOR EACH ROW EXECUTE FUNCTION public.require_review_preference_inputs();


--
-- Name: channel_links retire_review_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER retire_review_binding AFTER DELETE ON public.channel_links FOR EACH ROW EXECUTE FUNCTION public.retire_review_binding();


--
-- Name: project_memberships reviewer_membership_removed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reviewer_membership_removed AFTER DELETE ON public.project_memberships FOR EACH ROW EXECUTE FUNCTION public.expire_responsibility_offers();


--
-- Name: sources revoked_lookup_turns; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER revoked_lookup_turns AFTER UPDATE OF revoked_at ON public.sources FOR EACH ROW WHEN (((old.revoked_at IS NULL) AND (new.revoked_at IS NOT NULL))) EXECUTE FUNCTION public.clear_revoked_lookup_turns();


--
-- Name: members rule_offer_role; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rule_offer_role AFTER UPDATE OF enabled, role ON public.members FOR EACH ROW WHEN (((old.enabled <> new.enabled) OR (old.role <> new.role))) EXECUTE FUNCTION public.invalidate_rule_offer();


--
-- Name: team_rules rule_owner_changed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rule_owner_changed BEFORE UPDATE OF maintainer, maintenance_vacant ON public.team_rules FOR EACH ROW WHEN (((old.maintainer IS DISTINCT FROM new.maintainer) OR (old.maintenance_vacant <> new.maintenance_vacant))) EXECUTE FUNCTION public.rule_owner_changed();


--
-- Name: team_members rule_team_exit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rule_team_exit AFTER DELETE ON public.team_members FOR EACH ROW EXECUTE FUNCTION public.end_team_rule_duties();


--
-- Name: runs run_service_delivery_contract; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER run_service_delivery_contract BEFORE INSERT OR UPDATE OF service_id, service_version, plan_version ON public.runs FOR EACH ROW WHEN (((new.service_id IS NOT NULL) AND (new.service_version IS NOT NULL))) EXECUTE FUNCTION public.require_service_run_delivery_contract();


--
-- Name: artifacts service_artifact_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER service_artifact_event AFTER INSERT OR UPDATE OF current_version ON public.artifacts FOR EACH ROW EXECUTE FUNCTION public.track_service_event();


--
-- Name: feedback service_feedback_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER service_feedback_event AFTER INSERT OR UPDATE OF state ON public.feedback FOR EACH ROW EXECUTE FUNCTION public.track_service_event();


--
-- Name: projects service_project_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER service_project_event AFTER UPDATE OF stage ON public.projects FOR EACH ROW EXECUTE FUNCTION public.track_service_event();


--
-- Name: reviews service_review_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER service_review_event AFTER INSERT ON public.reviews FOR EACH ROW EXECUTE FUNCTION public.track_service_event();


--
-- Name: runs service_run_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER service_run_event AFTER INSERT OR UPDATE OF status ON public.runs FOR EACH ROW EXECUTE FUNCTION public.track_service_event();


--
-- Name: skill_revisions skill_activation_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skill_activation_immutable BEFORE UPDATE OF activation_terms ON public.skill_revisions FOR EACH ROW EXECUTE FUNCTION public.keep_skill_activation();


--
-- Name: skill_revisions skill_working_sets_revoked; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER skill_working_sets_revoked AFTER UPDATE OF revoked_at ON public.skill_revisions FOR EACH ROW WHEN (((old.revoked_at IS NULL) AND (new.revoked_at IS NOT NULL))) EXECUTE FUNCTION public.invalidate_revoked_skill_working_sets();


--
-- Name: sources source_passages_scope; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER source_passages_scope AFTER UPDATE OF current_version, revoked_at ON public.sources FOR EACH ROW WHEN (((old.current_version IS DISTINCT FROM new.current_version) OR (old.revoked_at IS DISTINCT FROM new.revoked_at))) EXECUTE FUNCTION public.source_passages_after_source();


--
-- Name: source_versions source_passages_version; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER source_passages_version AFTER INSERT OR UPDATE OF extracted ON public.source_versions FOR EACH ROW EXECUTE FUNCTION public.source_passages_after_version();


--
-- Name: spend spend_originating_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER spend_originating_department BEFORE INSERT ON public.spend FOR EACH ROW EXECUTE FUNCTION public.capture_originating_department('actor');


--
-- Name: projects start_review_period; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER start_review_period BEFORE INSERT ON public.projects FOR EACH ROW WHEN ((new.stage = 'review'::text)) EXECUTE FUNCTION public.enter_review_period();


--
-- Name: agent_revisions supersede_agent_release_requests; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER supersede_agent_release_requests AFTER INSERT ON public.agent_revisions FOR EACH ROW EXECUTE FUNCTION public.supersede_agent_release_requests();


--
-- Name: takeover_reviews takeover_service_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER takeover_service_event AFTER INSERT ON public.takeover_reviews FOR EACH ROW EXECUTE FUNCTION public.publish_reviewer_event();


--
-- Name: invocations telemetry_call; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER telemetry_call AFTER UPDATE OF ended_at ON public.invocations FOR EACH ROW EXECUTE FUNCTION public.enqueue_trace_span();


--
-- Name: runs telemetry_run; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER telemetry_run AFTER UPDATE OF status ON public.runs FOR EACH ROW EXECUTE FUNCTION public.enqueue_trace_span();


--
-- Name: invocations trace_calls; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trace_calls AFTER INSERT OR UPDATE OF status ON public.invocations FOR EACH ROW EXECUTE FUNCTION public.trace_transition_event();


--
-- Name: trace_events trace_event_attempt; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trace_event_attempt BEFORE INSERT ON public.trace_events FOR EACH ROW EXECUTE FUNCTION public.assign_event_attempt();


--
-- Name: runs trace_finish; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trace_finish BEFORE INSERT OR UPDATE OF status ON public.runs FOR EACH ROW EXECUTE FUNCTION public.trace_run_transition();


--
-- Name: runs trace_runs; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trace_runs AFTER INSERT OR UPDATE OF status ON public.runs FOR EACH ROW EXECUTE FUNCTION public.trace_transition_event();


--
-- Name: account_notices account_notices_event_seq_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_notices
    ADD CONSTRAINT account_notices_event_seq_fkey FOREIGN KEY (event_seq) REFERENCES public.audit_events(seq) ON DELETE CASCADE;


--
-- Name: account_notices account_notices_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_notices
    ADD CONSTRAINT account_notices_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: agent_build_manifests agent_build_manifests_agent_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_build_manifests
    ADD CONSTRAINT agent_build_manifests_agent_id_revision_fkey FOREIGN KEY (agent_id, revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: agent_checks agent_checks_agent_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_checks
    ADD CONSTRAINT agent_checks_agent_id_revision_fkey FOREIGN KEY (agent_id, revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: agent_checks agent_checks_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_checks
    ADD CONSTRAINT agent_checks_reviewer_fkey FOREIGN KEY (reviewer) REFERENCES public.members(id);


--
-- Name: agent_improvement_decisions agent_improvement_decisions_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvement_decisions
    ADD CONSTRAINT agent_improvement_decisions_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: agent_improvement_decisions agent_improvement_decisions_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvement_decisions
    ADD CONSTRAINT agent_improvement_decisions_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.agent_improvements(id);


--
-- Name: agent_improvements agent_improvements_agent_id_base_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvements
    ADD CONSTRAINT agent_improvements_agent_id_base_revision_fkey FOREIGN KEY (agent_id, base_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: agent_improvements agent_improvements_agent_id_result_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvements
    ADD CONSTRAINT agent_improvements_agent_id_result_revision_fkey FOREIGN KEY (agent_id, result_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: agent_improvements agent_improvements_requester_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_improvements
    ADD CONSTRAINT agent_improvements_requester_fkey FOREIGN KEY (requester) REFERENCES public.members(id);


--
-- Name: agent_publications agent_publications_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_publications
    ADD CONSTRAINT agent_publications_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: agent_publications agent_publications_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_publications
    ADD CONSTRAINT agent_publications_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_publications agent_publications_agent_id_restored_from_generation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_publications
    ADD CONSTRAINT agent_publications_agent_id_restored_from_generation_fkey FOREIGN KEY (agent_id, restored_from_generation) REFERENCES public.agent_publications(agent_id, generation);


--
-- Name: agent_publications agent_publications_agent_id_revision_build_digest_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_publications
    ADD CONSTRAINT agent_publications_agent_id_revision_build_digest_fkey FOREIGN KEY (agent_id, revision, build_digest) REFERENCES public.agent_build_manifests(agent_id, revision, digest);


--
-- Name: agent_publications agent_publications_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_publications
    ADD CONSTRAINT agent_publications_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.agent_release_requests(id);


--
-- Name: agent_release_requests agent_release_requests_agent_id_revision_build_digest_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_release_requests
    ADD CONSTRAINT agent_release_requests_agent_id_revision_build_digest_fkey FOREIGN KEY (agent_id, revision, build_digest) REFERENCES public.agent_build_manifests(agent_id, revision, digest);


--
-- Name: agent_release_requests agent_release_requests_agent_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_release_requests
    ADD CONSTRAINT agent_release_requests_agent_id_revision_fkey FOREIGN KEY (agent_id, revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: agent_release_requests agent_release_requests_decider_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_release_requests
    ADD CONSTRAINT agent_release_requests_decider_fkey FOREIGN KEY (decider) REFERENCES public.members(id);


--
-- Name: agent_release_requests agent_release_requests_requester_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_release_requests
    ADD CONSTRAINT agent_release_requests_requester_fkey FOREIGN KEY (requester) REFERENCES public.members(id);


--
-- Name: agent_revisions agent_revisions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_revisions
    ADD CONSTRAINT agent_revisions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_revisions agent_revisions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_revisions
    ADD CONSTRAINT agent_revisions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.members(id);


--
-- Name: agent_revisions agent_revisions_resource_id_resource_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_revisions
    ADD CONSTRAINT agent_revisions_resource_id_resource_revision_fkey FOREIGN KEY (resource_id, resource_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: agent_skill_bindings agent_skill_bindings_agent_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skill_bindings
    ADD CONSTRAINT agent_skill_bindings_agent_id_revision_fkey FOREIGN KEY (agent_id, revision) REFERENCES public.agent_revisions(agent_id, revision) ON DELETE CASCADE;


--
-- Name: agent_skill_bindings agent_skill_bindings_skill_id_skill_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skill_bindings
    ADD CONSTRAINT agent_skill_bindings_skill_id_skill_revision_fkey FOREIGN KEY (skill_id, skill_revision) REFERENCES public.skill_revisions(skill_id, revision);


--
-- Name: agents agents_id_published_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_id_published_revision_fkey FOREIGN KEY (id, published_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: agents agents_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_owner_fkey FOREIGN KEY (owner) REFERENCES public.members(id);


--
-- Name: agents agents_proposed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_proposed_by_fkey FOREIGN KEY (proposed_by) REFERENCES public.members(id);


--
-- Name: agents agents_proposed_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_proposed_owner_fkey FOREIGN KEY (proposed_owner) REFERENCES public.members(id);


--
-- Name: agents agents_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: answer_adoptions answer_adoptions_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.answer_adoptions
    ADD CONSTRAINT answer_adoptions_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: answer_adoptions answer_adoptions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.answer_adoptions
    ADD CONSTRAINT answer_adoptions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: answer_adoptions answer_adoptions_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.answer_adoptions
    ADD CONSTRAINT answer_adoptions_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.planning_requests(id);


--
-- Name: applications applications_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_id_fkey FOREIGN KEY (id) REFERENCES public.members(id);


--
-- Name: applications applications_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: artifact_files artifact_files_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_files
    ADD CONSTRAINT artifact_files_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: artifact_files artifact_files_object_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_files
    ADD CONSTRAINT artifact_files_object_hash_fkey FOREIGN KEY (object_hash) REFERENCES public.objects(hash);


--
-- Name: artifact_remote_receipts artifact_remote_receipts_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_remote_receipts
    ADD CONSTRAINT artifact_remote_receipts_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version) ON DELETE CASCADE;


--
-- Name: artifact_remote_receipts artifact_remote_receipts_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_remote_receipts
    ADD CONSTRAINT artifact_remote_receipts_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.remote_completion_evidence(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: artifact_requirement_evidence artifact_requirement_evidence_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_requirement_evidence
    ADD CONSTRAINT artifact_requirement_evidence_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version) ON DELETE CASCADE;


--
-- Name: artifact_requirement_evidence artifact_requirement_evidence_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_requirement_evidence
    ADD CONSTRAINT artifact_requirement_evidence_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.run_working_sets(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: artifact_upstream_context artifact_upstream_context_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_upstream_context
    ADD CONSTRAINT artifact_upstream_context_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version) ON DELETE CASCADE;


--
-- Name: artifact_upstream_context artifact_upstream_context_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_upstream_context
    ADD CONSTRAINT artifact_upstream_context_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.run_working_sets(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: artifact_versions artifact_versions_artifact_id_copied_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT artifact_versions_artifact_id_copied_from_fkey FOREIGN KEY (artifact_id, copied_from) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: artifact_versions artifact_versions_artifact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT artifact_versions_artifact_id_fkey FOREIGN KEY (artifact_id) REFERENCES public.artifacts(id);


--
-- Name: artifacts artifacts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: artifacts artifacts_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: audit_events audit_events_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: bill_rows bill_rows_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_rows
    ADD CONSTRAINT bill_rows_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: bill_rows bill_rows_spend_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_rows
    ADD CONSTRAINT bill_rows_spend_id_fkey FOREIGN KEY (spend_id) REFERENCES public.spend(id);


--
-- Name: bill_rows bill_rows_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_rows
    ADD CONSTRAINT bill_rows_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: budget_requests budget_requests_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.members(id);


--
-- Name: budget_requests budget_requests_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: budget_requests budget_requests_requester_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_requester_fkey FOREIGN KEY (requester) REFERENCES public.members(id);


--
-- Name: budget_requests budget_requests_resource_budget_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_resource_budget_fkey FOREIGN KEY (resource_budget) REFERENCES public.resource_budgets(id);


--
-- Name: budget_requests budget_requests_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: budget_requests budget_requests_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_requests
    ADD CONSTRAINT budget_requests_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: budgets budgets_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: calculation_requests calculation_requests_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculation_requests
    ADD CONSTRAINT calculation_requests_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: call_reviews call_reviews_control_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_reviews
    ADD CONSTRAINT call_reviews_control_id_fkey FOREIGN KEY (control_id) REFERENCES public.controls(id);


--
-- Name: call_reviews call_reviews_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_reviews
    ADD CONSTRAINT call_reviews_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.invocations(run_id, ordinal);


--
-- Name: call_reviews call_reviews_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_reviews
    ADD CONSTRAINT call_reviews_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.call_reviews(control_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: change_batches change_batches_artifact_id_applied_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_batches
    ADD CONSTRAINT change_batches_artifact_id_applied_version_fkey FOREIGN KEY (artifact_id, applied_version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: change_batches change_batches_artifact_id_base_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_batches
    ADD CONSTRAINT change_batches_artifact_id_base_version_fkey FOREIGN KEY (artifact_id, base_version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: change_batches change_batches_feedback_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_batches
    ADD CONSTRAINT change_batches_feedback_id_fkey FOREIGN KEY (feedback_id) REFERENCES public.feedback(id);


--
-- Name: change_batches change_batches_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_batches
    ADD CONSTRAINT change_batches_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: change_batches change_batches_source_assessment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_batches
    ADD CONSTRAINT change_batches_source_assessment_fkey FOREIGN KEY (source_assessment) REFERENCES public.source_assessments(id);


--
-- Name: change_inputs change_inputs_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_inputs
    ADD CONSTRAINT change_inputs_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: change_inputs change_inputs_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_inputs
    ADD CONSTRAINT change_inputs_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.change_batches(run_id);


--
-- Name: channel_attachment_jobs channel_attachment_jobs_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_attachment_jobs
    ADD CONSTRAINT channel_attachment_jobs_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.channel_events(id);


--
-- Name: channel_attachment_jobs channel_attachment_jobs_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_attachment_jobs
    ADD CONSTRAINT channel_attachment_jobs_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: channel_attachment_jobs channel_attachment_jobs_receipt_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_attachment_jobs
    ADD CONSTRAINT channel_attachment_jobs_receipt_run_fkey FOREIGN KEY (receipt_run) REFERENCES public.runs(id);


--
-- Name: channel_attachment_jobs channel_attachment_jobs_service_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_attachment_jobs
    ADD CONSTRAINT channel_attachment_jobs_service_id_version_fkey FOREIGN KEY (service_id, version) REFERENCES public.service_versions(service_id, version);


--
-- Name: channel_card_actions channel_card_actions_reply_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_card_actions
    ADD CONSTRAINT channel_card_actions_reply_id_fkey FOREIGN KEY (reply_id) REFERENCES public.channel_replies(id) ON DELETE CASCADE;


--
-- Name: channel_card_actions channel_card_actions_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_card_actions
    ADD CONSTRAINT channel_card_actions_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.planning_requests(id) ON DELETE CASCADE;


--
-- Name: channel_codes channel_codes_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_codes
    ADD CONSTRAINT channel_codes_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: channel_contexts channel_contexts_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_contexts
    ADD CONSTRAINT channel_contexts_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: channel_contexts channel_contexts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_contexts
    ADD CONSTRAINT channel_contexts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: channel_links channel_links_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_links
    ADD CONSTRAINT channel_links_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: channel_proposals channel_proposals_receipt_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_proposals
    ADD CONSTRAINT channel_proposals_receipt_run_fkey FOREIGN KEY (receipt_run) REFERENCES public.runs(id);


--
-- Name: channel_proposals channel_proposals_service_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_proposals
    ADD CONSTRAINT channel_proposals_service_id_version_fkey FOREIGN KEY (service_id, version) REFERENCES public.service_versions(service_id, version);


--
-- Name: channel_proposals channel_proposals_tenant_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_proposals
    ADD CONSTRAINT channel_proposals_tenant_member_id_fkey FOREIGN KEY (tenant, member_id) REFERENCES public.channel_links(tenant, member_id) ON DELETE CASCADE;


--
-- Name: channel_remote_input_proposals channel_remote_input_proposals_input_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_remote_input_proposals
    ADD CONSTRAINT channel_remote_input_proposals_input_id_fkey FOREIGN KEY (input_id) REFERENCES public.remote_task_inputs(id);


--
-- Name: channel_remote_input_proposals channel_remote_input_proposals_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_remote_input_proposals
    ADD CONSTRAINT channel_remote_input_proposals_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.remote_jobs(run_id, ordinal);


--
-- Name: channel_remote_input_proposals channel_remote_input_proposals_tenant_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_remote_input_proposals
    ADD CONSTRAINT channel_remote_input_proposals_tenant_member_id_fkey FOREIGN KEY (tenant, member_id) REFERENCES public.channel_links(tenant, member_id) ON DELETE CASCADE;


--
-- Name: channel_replies channel_replies_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_replies
    ADD CONSTRAINT channel_replies_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.channel_events(id);


--
-- Name: channel_replies channel_replies_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_replies
    ADD CONSTRAINT channel_replies_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: channel_replies channel_replies_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_replies
    ADD CONSTRAINT channel_replies_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: column_suggestions column_suggestions_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.column_suggestions
    ADD CONSTRAINT column_suggestions_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: column_suggestions column_suggestions_resource_id_resource_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.column_suggestions
    ADD CONSTRAINT column_suggestions_resource_id_resource_revision_fkey FOREIGN KEY (resource_id, resource_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: column_suggestions column_suggestions_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.column_suggestions
    ADD CONSTRAINT column_suggestions_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: controls controls_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.controls
    ADD CONSTRAINT controls_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: controls controls_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.controls
    ADD CONSTRAINT controls_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: delegations delegations_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegations
    ADD CONSTRAINT delegations_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.applications(id);


--
-- Name: delegations delegations_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delegations
    ADD CONSTRAINT delegations_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: deliveries deliveries_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.members(id);


--
-- Name: deliveries deliveries_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: deliveries deliveries_reviewer_assignment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_reviewer_assignment_fkey FOREIGN KEY (reviewer_assignment) REFERENCES public.reviewer_handoffs(id);


--
-- Name: delivery_item_assessments delivery_item_assessments_artifact_id_artifact_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_item_assessments
    ADD CONSTRAINT delivery_item_assessments_artifact_id_artifact_version_fkey FOREIGN KEY (artifact_id, artifact_version) REFERENCES public.artifact_versions(artifact_id, version) MATCH FULL;


--
-- Name: delivery_item_assessments delivery_item_assessments_artifact_id_remote_receipt_versi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_item_assessments
    ADD CONSTRAINT delivery_item_assessments_artifact_id_remote_receipt_versi_fkey FOREIGN KEY (artifact_id, remote_receipt_version) REFERENCES public.artifact_remote_receipts(artifact_id, version) ON DELETE SET NULL (remote_receipt_version);


--
-- Name: delivery_item_assessments delivery_item_assessments_project_id_plan_version_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_item_assessments
    ADD CONSTRAINT delivery_item_assessments_project_id_plan_version_item_fkey FOREIGN KEY (project_id, plan_version, item) REFERENCES public.plan_delivery_requirements(project_id, plan_version, item);


--
-- Name: delivery_item_assessments delivery_item_assessments_responsible_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_item_assessments
    ADD CONSTRAINT delivery_item_assessments_responsible_fkey FOREIGN KEY (responsible) REFERENCES public.members(id);


--
-- Name: delivery_item_assessments delivery_item_assessments_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_item_assessments
    ADD CONSTRAINT delivery_item_assessments_reviewer_fkey FOREIGN KEY (reviewer) REFERENCES public.members(id);


--
-- Name: delivery_item_assessments delivery_item_assessments_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_item_assessments
    ADD CONSTRAINT delivery_item_assessments_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: delivery_items delivery_items_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_items
    ADD CONSTRAINT delivery_items_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.reviews(artifact_id, version);


--
-- Name: delivery_items delivery_items_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_items
    ADD CONSTRAINT delivery_items_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: delivery_revision_requests delivery_revision_requests_base_delivery_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_revision_requests
    ADD CONSTRAINT delivery_revision_requests_base_delivery_fkey FOREIGN KEY (base_delivery) REFERENCES public.deliveries(id);


--
-- Name: delivery_revision_requests delivery_revision_requests_feedback_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_revision_requests
    ADD CONSTRAINT delivery_revision_requests_feedback_id_fkey FOREIGN KEY (feedback_id) REFERENCES public.feedback(id);


--
-- Name: delivery_revision_requests delivery_revision_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_revision_requests
    ADD CONSTRAINT delivery_revision_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.members(id);


--
-- Name: delivery_source_evidence delivery_source_evidence_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_source_evidence
    ADD CONSTRAINT delivery_source_evidence_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: delivery_source_evidence delivery_source_evidence_source_id_observed_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_source_evidence
    ADD CONSTRAINT delivery_source_evidence_source_id_observed_fkey FOREIGN KEY (source_id, observed) REFERENCES public.source_versions(source_id, version);


--
-- Name: delivery_source_evidence delivery_source_evidence_source_id_pinned_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_source_evidence
    ADD CONSTRAINT delivery_source_evidence_source_id_pinned_fkey FOREIGN KEY (source_id, pinned) REFERENCES public.source_versions(source_id, version);


--
-- Name: distribution_reviews distribution_reviews_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_reviews
    ADD CONSTRAINT distribution_reviews_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: distribution_reviews distribution_reviews_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_reviews
    ADD CONSTRAINT distribution_reviews_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: distribution_reviews distribution_reviews_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_reviews
    ADD CONSTRAINT distribution_reviews_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id);


--
-- Name: enterprise enterprise_default_team_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise
    ADD CONSTRAINT enterprise_default_team_fkey FOREIGN KEY (default_team) REFERENCES public.teams(id);


--
-- Name: feedback feedback_artifact_id_base_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_artifact_id_base_version_fkey FOREIGN KEY (artifact_id, base_version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: feedback feedback_artifact_id_candidate_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_artifact_id_candidate_version_fkey FOREIGN KEY (artifact_id, candidate_version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: feedback feedback_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_author_fkey FOREIGN KEY (author) REFERENCES public.members(id);


--
-- Name: feedback_events feedback_events_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_events
    ADD CONSTRAINT feedback_events_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: feedback_events feedback_events_feedback_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_events
    ADD CONSTRAINT feedback_events_feedback_id_fkey FOREIGN KEY (feedback_id) REFERENCES public.feedback(id);


--
-- Name: feedback feedback_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_reviewer_fkey FOREIGN KEY (reviewer) REFERENCES public.members(id);


--
-- Name: feedback_source_quotes feedback_source_quotes_feedback_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_source_quotes
    ADD CONSTRAINT feedback_source_quotes_feedback_id_fkey FOREIGN KEY (feedback_id) REFERENCES public.feedback(id) ON DELETE CASCADE;


--
-- Name: feedback_source_quotes feedback_source_quotes_source_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_source_quotes
    ADD CONSTRAINT feedback_source_quotes_source_id_version_fkey FOREIGN KEY (source_id, version) REFERENCES public.source_versions(source_id, version);


--
-- Name: feedback feedback_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.project_feedback_submissions(id);


--
-- Name: gap_bindings gap_bindings_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gap_bindings
    ADD CONSTRAINT gap_bindings_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: gap_bindings gap_bindings_agent_id_agent_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gap_bindings
    ADD CONSTRAINT gap_bindings_agent_id_agent_revision_fkey FOREIGN KEY (agent_id, agent_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: gap_bindings gap_bindings_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gap_bindings
    ADD CONSTRAINT gap_bindings_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.planning_requests(id);


--
-- Name: im_binding_codes im_binding_codes_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_binding_codes
    ADD CONSTRAINT im_binding_codes_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: im_bindings im_bindings_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_bindings
    ADD CONSTRAINT im_bindings_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: im_events im_events_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_events
    ADD CONSTRAINT im_events_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: im_service_launches im_service_launches_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_service_launches
    ADD CONSTRAINT im_service_launches_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.im_bindings(id) ON DELETE CASCADE;


--
-- Name: im_service_launches im_service_launches_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_service_launches
    ADD CONSTRAINT im_service_launches_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: im_service_launches im_service_launches_service_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_service_launches
    ADD CONSTRAINT im_service_launches_service_id_version_fkey FOREIGN KEY (service_id, version) REFERENCES public.service_versions(service_id, version) ON DELETE CASCADE;


--
-- Name: im_threads im_threads_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_threads
    ADD CONSTRAINT im_threads_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.im_bindings(id) ON DELETE CASCADE;


--
-- Name: im_threads im_threads_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.im_threads
    ADD CONSTRAINT im_threads_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: invites invites_issued_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_issued_by_fkey FOREIGN KEY (issued_by) REFERENCES public.members(id);


--
-- Name: invites invites_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: invites invites_used_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_used_by_fkey FOREIGN KEY (used_by) REFERENCES public.members(id);


--
-- Name: invocation_files invocation_files_object_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_files
    ADD CONSTRAINT invocation_files_object_hash_fkey FOREIGN KEY (object_hash) REFERENCES public.objects(hash);


--
-- Name: invocation_files invocation_files_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_files
    ADD CONSTRAINT invocation_files_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.invocations(run_id, ordinal);


--
-- Name: invocations invocations_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocations
    ADD CONSTRAINT invocations_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: late_call_receipts late_call_receipts_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.late_call_receipts
    ADD CONSTRAINT late_call_receipts_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.invocations(run_id, ordinal);


--
-- Name: local_action_observations local_action_observations_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_action_observations
    ADD CONSTRAINT local_action_observations_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.lookup_turns(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: lookup_index_waits lookup_index_waits_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lookup_index_waits
    ADD CONSTRAINT lookup_index_waits_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: lookup_question_handoffs lookup_question_handoffs_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lookup_question_handoffs
    ADD CONSTRAINT lookup_question_handoffs_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: lookup_question_handoffs lookup_question_handoffs_run_id_parent_parent_attempt_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lookup_question_handoffs
    ADD CONSTRAINT lookup_question_handoffs_run_id_parent_parent_attempt_fkey FOREIGN KEY (run_id, parent, parent_attempt) REFERENCES public.run_working_sets(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: lookup_turns lookup_turns_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lookup_turns
    ADD CONSTRAINT lookup_turns_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.invocations(run_id, ordinal) ON DELETE CASCADE;


--
-- Name: management_exports management_exports_grant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_exports
    ADD CONSTRAINT management_exports_grant_id_fkey FOREIGN KEY (grant_id) REFERENCES public.management_grants(id);


--
-- Name: management_grants management_grants_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_grants
    ADD CONSTRAINT management_grants_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: management_grants management_grants_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_grants
    ADD CONSTRAINT management_grants_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: management_grants management_grants_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_grants
    ADD CONSTRAINT management_grants_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.members(id);


--
-- Name: management_grants management_grants_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_grants
    ADD CONSTRAINT management_grants_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: management_grants management_grants_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_grants
    ADD CONSTRAINT management_grants_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: members members_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: messages messages_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_author_fkey FOREIGN KEY (author) REFERENCES public.members(id);


--
-- Name: messages messages_planning_request_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_planning_request_fkey FOREIGN KEY (planning_request) REFERENCES public.planning_requests(id);


--
-- Name: messages messages_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: model_key_candidates model_key_candidates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_key_candidates
    ADD CONSTRAINT model_key_candidates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.members(id);


--
-- Name: model_key_candidates model_key_candidates_resource_id_resource_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_key_candidates
    ADD CONSTRAINT model_key_candidates_resource_id_resource_revision_fkey FOREIGN KEY (resource_id, resource_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: model_probes model_probes_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_probes
    ADD CONSTRAINT model_probes_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: model_probes model_probes_candidate_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_probes
    ADD CONSTRAINT model_probes_candidate_fkey FOREIGN KEY (candidate) REFERENCES public.model_key_candidates(id);


--
-- Name: model_probes model_probes_resource_id_resource_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_probes
    ADD CONSTRAINT model_probes_resource_id_resource_revision_fkey FOREIGN KEY (resource_id, resource_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: model_probes model_probes_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_probes
    ADD CONSTRAINT model_probes_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: model_replacement_agents model_replacement_agents_agent_id_draft_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacement_agents
    ADD CONSTRAINT model_replacement_agents_agent_id_draft_fkey FOREIGN KEY (agent_id, draft) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: model_replacement_agents model_replacement_agents_agent_id_original_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacement_agents
    ADD CONSTRAINT model_replacement_agents_agent_id_original_fkey FOREIGN KEY (agent_id, original) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: model_replacement_agents model_replacement_agents_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacement_agents
    ADD CONSTRAINT model_replacement_agents_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.model_replacements(id);


--
-- Name: model_replacement_agents model_replacement_agents_rollback_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacement_agents
    ADD CONSTRAINT model_replacement_agents_rollback_actor_fkey FOREIGN KEY (rollback_actor) REFERENCES public.members(id);


--
-- Name: model_replacements model_replacements_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacements
    ADD CONSTRAINT model_replacements_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: model_replacements model_replacements_source_id_source_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacements
    ADD CONSTRAINT model_replacements_source_id_source_revision_fkey FOREIGN KEY (source_id, source_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: model_replacements model_replacements_target_id_target_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_replacements
    ADD CONSTRAINT model_replacements_target_id_target_revision_fkey FOREIGN KEY (target_id, target_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: model_resources model_resources_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_resources
    ADD CONSTRAINT model_resources_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.members(id);


--
-- Name: model_resources model_resources_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_resources
    ADD CONSTRAINT model_resources_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: model_revisions model_revisions_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_revisions
    ADD CONSTRAINT model_revisions_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.model_resources(id);


--
-- Name: node_edges node_edges_project_id_plan_version_depends_on_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_edges
    ADD CONSTRAINT node_edges_project_id_plan_version_depends_on_fkey FOREIGN KEY (project_id, plan_version, depends_on) REFERENCES public.nodes(project_id, plan_version, ordinal);


--
-- Name: node_edges node_edges_project_id_plan_version_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_edges
    ADD CONSTRAINT node_edges_project_id_plan_version_ordinal_fkey FOREIGN KEY (project_id, plan_version, ordinal) REFERENCES public.nodes(project_id, plan_version, ordinal);


--
-- Name: nodes nodes_agent_id_agent_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_agent_id_agent_revision_fkey FOREIGN KEY (agent_id, agent_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: nodes nodes_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: oidc_bindings oidc_bindings_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_bindings
    ADD CONSTRAINT oidc_bindings_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: oidc_flows oidc_flows_binding_session_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_flows
    ADD CONSTRAINT oidc_flows_binding_session_fkey FOREIGN KEY (binding_session) REFERENCES public.sessions(token_hash) ON DELETE CASCADE;


--
-- Name: outbox outbox_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox
    ADD CONSTRAINT outbox_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: plan_delivery_contracts plan_delivery_contracts_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_delivery_contracts
    ADD CONSTRAINT plan_delivery_contracts_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: plan_delivery_requirements plan_delivery_requirements_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_delivery_requirements
    ADD CONSTRAINT plan_delivery_requirements_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plan_delivery_contracts(project_id, plan_version);


--
-- Name: plan_delivery_requirements plan_delivery_requirements_project_id_plan_version_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_delivery_requirements
    ADD CONSTRAINT plan_delivery_requirements_project_id_plan_version_ordinal_fkey FOREIGN KEY (project_id, plan_version, ordinal) REFERENCES public.nodes(project_id, plan_version, ordinal);


--
-- Name: plan_preferences plan_preferences_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_preferences
    ADD CONSTRAINT plan_preferences_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.preferences(id);


--
-- Name: plan_preferences plan_preferences_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_preferences
    ADD CONSTRAINT plan_preferences_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: plan_rules plan_rules_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_rules
    ADD CONSTRAINT plan_rules_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: plan_rules plan_rules_rule_id_rule_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_rules
    ADD CONSTRAINT plan_rules_rule_id_rule_revision_fkey FOREIGN KEY (rule_id, rule_revision) REFERENCES public.rule_versions(rule_id, revision);


--
-- Name: plan_scoped_preferences plan_scoped_preferences_agent_scope_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_scoped_preferences
    ADD CONSTRAINT plan_scoped_preferences_agent_scope_fkey FOREIGN KEY (agent_scope) REFERENCES public.agents(id);


--
-- Name: plan_scoped_preferences plan_scoped_preferences_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_scoped_preferences
    ADD CONSTRAINT plan_scoped_preferences_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.preferences(id);


--
-- Name: plan_scoped_preferences plan_scoped_preferences_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_scoped_preferences
    ADD CONSTRAINT plan_scoped_preferences_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: plan_sources plan_sources_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_sources
    ADD CONSTRAINT plan_sources_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: plan_sources plan_sources_source_id_source_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_sources
    ADD CONSTRAINT plan_sources_source_id_source_version_fkey FOREIGN KEY (source_id, source_version) REFERENCES public.source_versions(source_id, version);


--
-- Name: plan_tool_choices plan_tool_choices_alternative_alternative_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_tool_choices
    ADD CONSTRAINT plan_tool_choices_alternative_alternative_revision_fkey FOREIGN KEY (alternative, alternative_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: plan_tool_choices plan_tool_choices_project_id_plan_version_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_tool_choices
    ADD CONSTRAINT plan_tool_choices_project_id_plan_version_ordinal_fkey FOREIGN KEY (project_id, plan_version, ordinal) REFERENCES public.nodes(project_id, plan_version, ordinal);


--
-- Name: plan_tool_choices plan_tool_choices_project_id_plan_version_selector_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_tool_choices
    ADD CONSTRAINT plan_tool_choices_project_id_plan_version_selector_fkey FOREIGN KEY (project_id, plan_version, selector) REFERENCES public.nodes(project_id, plan_version, ordinal);


--
-- Name: plan_workflow_templates plan_workflow_templates_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_workflow_templates
    ADD CONSTRAINT plan_workflow_templates_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: plan_workflow_templates plan_workflow_templates_project_id_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_workflow_templates
    ADD CONSTRAINT plan_workflow_templates_project_id_template_id_fkey FOREIGN KEY (project_id, template_id) REFERENCES public.workflow_template_uses(project_id, template_id);


--
-- Name: plan_workflow_templates plan_workflow_templates_template_id_template_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_workflow_templates
    ADD CONSTRAINT plan_workflow_templates_template_id_template_version_fkey FOREIGN KEY (template_id, template_version) REFERENCES public.workflow_template_versions(template_id, version);


--
-- Name: planning_budget_blocks planning_budget_blocks_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_budget_blocks
    ADD CONSTRAINT planning_budget_blocks_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.resource_budgets(id);


--
-- Name: planning_budget_blocks planning_budget_blocks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_budget_blocks
    ADD CONSTRAINT planning_budget_blocks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: planning_context_messages planning_context_messages_message_seq_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_context_messages
    ADD CONSTRAINT planning_context_messages_message_seq_fkey FOREIGN KEY (message_seq) REFERENCES public.messages(seq);


--
-- Name: planning_context_messages planning_context_messages_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_context_messages
    ADD CONSTRAINT planning_context_messages_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.planning_requests(id) ON DELETE CASCADE;


--
-- Name: planning_defaults planning_defaults_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_defaults
    ADD CONSTRAINT planning_defaults_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.members(id);


--
-- Name: planning_defaults planning_defaults_resource_id_resource_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_defaults
    ADD CONSTRAINT planning_defaults_resource_id_resource_revision_fkey FOREIGN KEY (resource_id, resource_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: planning_defaults planning_defaults_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_defaults
    ADD CONSTRAINT planning_defaults_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: planning_requests planning_requests_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_requests
    ADD CONSTRAINT planning_requests_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: planning_requests planning_requests_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_requests
    ADD CONSTRAINT planning_requests_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: planning_requests planning_requests_resource_id_resource_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_requests
    ADD CONSTRAINT planning_requests_resource_id_resource_revision_fkey FOREIGN KEY (resource_id, resource_revision) REFERENCES public.model_revisions(resource_id, revision);


--
-- Name: plans plans_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.members(id);


--
-- Name: plans plans_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: plans plans_suggestion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_suggestion_id_fkey FOREIGN KEY (suggestion_id) REFERENCES public.planning_requests(id);


--
-- Name: preferences preferences_agent_scope_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_agent_scope_fkey FOREIGN KEY (agent_scope) REFERENCES public.agents(id);


--
-- Name: preferences preferences_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: project_agent_calls project_agent_calls_grant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_calls
    ADD CONSTRAINT project_agent_calls_grant_id_fkey FOREIGN KEY (grant_id) REFERENCES public.project_agent_grants(id);


--
-- Name: project_agent_calls project_agent_calls_op_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_calls
    ADD CONSTRAINT project_agent_calls_op_key_fkey FOREIGN KEY (op_key) REFERENCES public.spend(op_key);


--
-- Name: project_agent_grants project_agent_grants_agent_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_grants
    ADD CONSTRAINT project_agent_grants_agent_id_revision_fkey FOREIGN KEY (agent_id, revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: project_agent_grants project_agent_grants_budget_approver_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_grants
    ADD CONSTRAINT project_agent_grants_budget_approver_fkey FOREIGN KEY (budget_approver) REFERENCES public.members(id);


--
-- Name: project_agent_grants project_agent_grants_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_grants
    ADD CONSTRAINT project_agent_grants_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: project_agent_grants project_agent_grants_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_grants
    ADD CONSTRAINT project_agent_grants_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.members(id);


--
-- Name: project_agent_grants project_agent_grants_resource_approver_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_agent_grants
    ADD CONSTRAINT project_agent_grants_resource_approver_fkey FOREIGN KEY (resource_approver) REFERENCES public.members(id);


--
-- Name: project_budgets project_budgets_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_budgets
    ADD CONSTRAINT project_budgets_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: project_feedback_submissions project_feedback_submissions_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_feedback_submissions
    ADD CONSTRAINT project_feedback_submissions_author_fkey FOREIGN KEY (author) REFERENCES public.members(id);


--
-- Name: project_feedback_submissions project_feedback_submissions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_feedback_submissions
    ADD CONSTRAINT project_feedback_submissions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: project_memberships project_members_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_members_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: project_memberships project_members_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_members_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: project_memberships project_memberships_recovery_assignment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_memberships_recovery_assignment_fkey FOREIGN KEY (recovery_assignment) REFERENCES public.reviewer_handoffs(id);


--
-- Name: project_session_events project_session_events_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_session_events
    ADD CONSTRAINT project_session_events_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project_session_heads(project_id) ON DELETE CASCADE;


--
-- Name: project_session_heads project_session_heads_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_session_heads
    ADD CONSTRAINT project_session_heads_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_final_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_final_reviewer_fkey FOREIGN KEY (final_reviewer) REFERENCES public.members(id);


--
-- Name: projects projects_originating_department_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_originating_department_fkey FOREIGN KEY (originating_department) REFERENCES public.departments(id);


--
-- Name: projects projects_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_owner_fkey FOREIGN KEY (owner) REFERENCES public.members(id);


--
-- Name: projects projects_planning_resource_planning_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_planning_resource_planning_revision_fkey FOREIGN KEY (planning_resource, planning_revision) REFERENCES public.model_revisions(resource_id, revision) MATCH FULL;


--
-- Name: projects projects_reviewer_assignment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_reviewer_assignment_fkey FOREIGN KEY (reviewer_assignment) REFERENCES public.reviewer_handoffs(id);


--
-- Name: projects projects_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: receipt_wakes receipt_wakes_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_wakes
    ADD CONSTRAINT receipt_wakes_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: remote_completion_evidence remote_completion_evidence_agent_id_agent_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_completion_evidence
    ADD CONSTRAINT remote_completion_evidence_agent_id_agent_revision_fkey FOREIGN KEY (agent_id, agent_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: remote_completion_evidence remote_completion_evidence_input_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_completion_evidence
    ADD CONSTRAINT remote_completion_evidence_input_id_fkey FOREIGN KEY (input_id) REFERENCES public.remote_task_inputs(id);


--
-- Name: remote_completion_evidence remote_completion_evidence_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_completion_evidence
    ADD CONSTRAINT remote_completion_evidence_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.run_working_sets(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: remote_jobs remote_jobs_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_jobs
    ADD CONSTRAINT remote_jobs_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.invocations(run_id, ordinal);


--
-- Name: remote_task_inputs remote_task_inputs_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_task_inputs
    ADD CONSTRAINT remote_task_inputs_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: remote_task_inputs remote_task_inputs_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_task_inputs
    ADD CONSTRAINT remote_task_inputs_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.remote_jobs(run_id, ordinal);


--
-- Name: remote_trial_inputs remote_trial_inputs_trial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_trial_inputs
    ADD CONSTRAINT remote_trial_inputs_trial_id_fkey FOREIGN KEY (trial_id) REFERENCES public.validations(id);


--
-- Name: remote_trial_observations remote_trial_observations_trial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_trial_observations
    ADD CONSTRAINT remote_trial_observations_trial_id_fkey FOREIGN KEY (trial_id) REFERENCES public.validations(id);


--
-- Name: resource_budgets resource_budgets_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_budgets
    ADD CONSTRAINT resource_budgets_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: resource_budgets resource_budgets_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_budgets
    ADD CONSTRAINT resource_budgets_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.model_resources(id);


--
-- Name: resource_budgets resource_budgets_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_budgets
    ADD CONSTRAINT resource_budgets_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: review_clocks review_clocks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_clocks
    ADD CONSTRAINT review_clocks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: review_notification_items review_notification_items_batch_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_notification_items
    ADD CONSTRAINT review_notification_items_batch_fkey FOREIGN KEY (batch) REFERENCES public.review_notifications(id);


--
-- Name: review_notification_items review_notification_items_clock_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_notification_items
    ADD CONSTRAINT review_notification_items_clock_fkey FOREIGN KEY (clock) REFERENCES public.review_clocks(id);


--
-- Name: review_notifications review_notifications_recipient_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_notifications
    ADD CONSTRAINT review_notifications_recipient_fkey FOREIGN KEY (recipient) REFERENCES public.members(id);


--
-- Name: review_notifications review_notifications_retry_of_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_notifications
    ADD CONSTRAINT review_notifications_retry_of_fkey FOREIGN KEY (retry_of) REFERENCES public.review_notifications(id);


--
-- Name: review_policies review_policies_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_policies
    ADD CONSTRAINT review_policies_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: review_policies review_policies_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_policies
    ADD CONSTRAINT review_policies_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: reviewer_handoffs reviewer_handoffs_decision_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviewer_handoffs
    ADD CONSTRAINT reviewer_handoffs_decision_by_fkey FOREIGN KEY (decision_by) REFERENCES public.members(id);


--
-- Name: reviewer_handoffs reviewer_handoffs_previous_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviewer_handoffs
    ADD CONSTRAINT reviewer_handoffs_previous_reviewer_fkey FOREIGN KEY (previous_reviewer) REFERENCES public.members(id);


--
-- Name: reviewer_handoffs reviewer_handoffs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviewer_handoffs
    ADD CONSTRAINT reviewer_handoffs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: reviewer_handoffs reviewer_handoffs_proposer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviewer_handoffs
    ADD CONSTRAINT reviewer_handoffs_proposer_fkey FOREIGN KEY (proposer) REFERENCES public.members(id);


--
-- Name: reviewer_handoffs reviewer_handoffs_successor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviewer_handoffs
    ADD CONSTRAINT reviewer_handoffs_successor_fkey FOREIGN KEY (successor) REFERENCES public.members(id);


--
-- Name: reviews reviews_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: reviews reviews_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_reviewer_fkey FOREIGN KEY (reviewer) REFERENCES public.members(id);


--
-- Name: rule_branch_rebuilds rule_branch_rebuilds_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_rebuilds
    ADD CONSTRAINT rule_branch_rebuilds_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: rule_branch_rebuilds rule_branch_rebuilds_source_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_rebuilds
    ADD CONSTRAINT rule_branch_rebuilds_source_run_fkey FOREIGN KEY (source_run) REFERENCES public.runs(id);


--
-- Name: rule_branch_steps rule_branch_steps_artifact_id_base_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_steps
    ADD CONSTRAINT rule_branch_steps_artifact_id_base_version_fkey FOREIGN KEY (artifact_id, base_version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: rule_branch_steps rule_branch_steps_artifact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_steps
    ADD CONSTRAINT rule_branch_steps_artifact_id_fkey FOREIGN KEY (artifact_id) REFERENCES public.artifacts(id);


--
-- Name: rule_branch_steps rule_branch_steps_artifact_id_result_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_steps
    ADD CONSTRAINT rule_branch_steps_artifact_id_result_version_fkey FOREIGN KEY (artifact_id, result_version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: rule_branch_steps rule_branch_steps_origin_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_steps
    ADD CONSTRAINT rule_branch_steps_origin_run_fkey FOREIGN KEY (origin_run) REFERENCES public.runs(id);


--
-- Name: rule_branch_steps rule_branch_steps_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_branch_steps
    ADD CONSTRAINT rule_branch_steps_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.rule_branch_rebuilds(run_id);


--
-- Name: rule_versions rule_versions_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions
    ADD CONSTRAINT rule_versions_author_fkey FOREIGN KEY (author) REFERENCES public.members(id);


--
-- Name: rule_versions rule_versions_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_versions
    ADD CONSTRAINT rule_versions_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.team_rules(id);


--
-- Name: run_draft_fragments run_draft_fragments_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_draft_fragments
    ADD CONSTRAINT run_draft_fragments_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.invocations(run_id, ordinal) ON DELETE CASCADE;


--
-- Name: run_source_receipts run_source_receipts_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_source_receipts
    ADD CONSTRAINT run_source_receipts_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: run_source_receipts run_source_receipts_source_id_source_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_source_receipts
    ADD CONSTRAINT run_source_receipts_source_id_source_version_fkey FOREIGN KEY (source_id, source_version) REFERENCES public.source_versions(source_id, version);


--
-- Name: run_tool_choice_waits run_tool_choice_waits_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_tool_choice_waits
    ADD CONSTRAINT run_tool_choice_waits_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.run_tool_choices(run_id, ordinal) ON DELETE CASCADE;


--
-- Name: run_tool_choices run_tool_choices_manual_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_tool_choices
    ADD CONSTRAINT run_tool_choices_manual_by_fkey FOREIGN KEY (manual_by) REFERENCES public.members(id);


--
-- Name: run_tool_choices run_tool_choices_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_tool_choices
    ADD CONSTRAINT run_tool_choices_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: run_working_inputs run_working_inputs_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_inputs
    ADD CONSTRAINT run_working_inputs_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.run_working_sets(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: run_working_parents run_working_parents_parent_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_parents
    ADD CONSTRAINT run_working_parents_parent_run_fkey FOREIGN KEY (parent_run) REFERENCES public.runs(id);


--
-- Name: run_working_parents run_working_parents_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_parents
    ADD CONSTRAINT run_working_parents_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.run_working_sets(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: run_working_sets run_working_sets_build_agent_build_revision_build_digest_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_sets
    ADD CONSTRAINT run_working_sets_build_agent_build_revision_build_digest_fkey FOREIGN KEY (build_agent, build_revision, build_digest) REFERENCES public.agent_build_manifests(agent_id, revision, digest) MATCH FULL;


--
-- Name: run_working_sets run_working_sets_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.run_working_sets
    ADD CONSTRAINT run_working_sets_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: runs runs_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: runs runs_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.applications(id);


--
-- Name: runs runs_charge_team_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_charge_team_fkey FOREIGN KEY (charge_team) REFERENCES public.teams(id);


--
-- Name: runs runs_delegated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_delegated_by_fkey FOREIGN KEY (delegated_by) REFERENCES public.delegations(id);


--
-- Name: runs runs_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: runs runs_service_id_service_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_service_id_service_version_fkey FOREIGN KEY (service_id, service_version) REFERENCES public.service_versions(service_id, version);


--
-- Name: service_action_receipts service_action_receipts_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_action_receipts
    ADD CONSTRAINT service_action_receipts_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: service_delivery_requirements service_delivery_requirements_service_id_version_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_delivery_requirements
    ADD CONSTRAINT service_delivery_requirements_service_id_version_ordinal_fkey FOREIGN KEY (service_id, version, ordinal) REFERENCES public.service_nodes(service_id, version, ordinal) ON DELETE CASCADE;


--
-- Name: service_edges service_edges_service_id_version_depends_on_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_edges
    ADD CONSTRAINT service_edges_service_id_version_depends_on_fkey FOREIGN KEY (service_id, version, depends_on) REFERENCES public.service_nodes(service_id, version, ordinal);


--
-- Name: service_edges service_edges_service_id_version_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_edges
    ADD CONSTRAINT service_edges_service_id_version_ordinal_fkey FOREIGN KEY (service_id, version, ordinal) REFERENCES public.service_nodes(service_id, version, ordinal);


--
-- Name: service_event_heads service_event_heads_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_event_heads
    ADD CONSTRAINT service_event_heads_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: service_events service_events_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_events
    ADD CONSTRAINT service_events_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: service_nodes service_nodes_agent_id_agent_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_nodes
    ADD CONSTRAINT service_nodes_agent_id_agent_revision_fkey FOREIGN KEY (agent_id, agent_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: service_nodes service_nodes_service_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_nodes
    ADD CONSTRAINT service_nodes_service_id_version_fkey FOREIGN KEY (service_id, version) REFERENCES public.service_versions(service_id, version);


--
-- Name: service_rollbacks service_rollbacks_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rollbacks
    ADD CONSTRAINT service_rollbacks_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: service_rollbacks service_rollbacks_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rollbacks
    ADD CONSTRAINT service_rollbacks_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: service_rollbacks service_rollbacks_service_id_from_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rollbacks
    ADD CONSTRAINT service_rollbacks_service_id_from_version_fkey FOREIGN KEY (service_id, from_version) REFERENCES public.service_versions(service_id, version);


--
-- Name: service_rollbacks service_rollbacks_service_id_to_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rollbacks
    ADD CONSTRAINT service_rollbacks_service_id_to_version_fkey FOREIGN KEY (service_id, to_version) REFERENCES public.service_versions(service_id, version);


--
-- Name: service_supplements service_supplements_message_seq_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_supplements
    ADD CONSTRAINT service_supplements_message_seq_fkey FOREIGN KEY (message_seq) REFERENCES public.messages(seq);


--
-- Name: service_supplements service_supplements_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_supplements
    ADD CONSTRAINT service_supplements_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: service_tool_choices service_tool_choices_alternative_alternative_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tool_choices
    ADD CONSTRAINT service_tool_choices_alternative_alternative_revision_fkey FOREIGN KEY (alternative, alternative_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: service_tool_choices service_tool_choices_service_id_version_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tool_choices
    ADD CONSTRAINT service_tool_choices_service_id_version_ordinal_fkey FOREIGN KEY (service_id, version, ordinal) REFERENCES public.service_nodes(service_id, version, ordinal);


--
-- Name: service_tool_choices service_tool_choices_service_id_version_selector_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_tool_choices
    ADD CONSTRAINT service_tool_choices_service_id_version_selector_fkey FOREIGN KEY (service_id, version, selector) REFERENCES public.service_nodes(service_id, version, ordinal);


--
-- Name: service_versions service_versions_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_versions
    ADD CONSTRAINT service_versions_reviewer_fkey FOREIGN KEY (reviewer) REFERENCES public.members(id);


--
-- Name: service_versions service_versions_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_versions
    ADD CONSTRAINT service_versions_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: services services_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_owner_fkey FOREIGN KEY (owner) REFERENCES public.members(id);


--
-- Name: services services_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: sessions sessions_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: sessions sessions_oidc_binding_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_oidc_binding_fkey FOREIGN KEY (oidc_binding) REFERENCES public.oidc_bindings(id) ON DELETE CASCADE;


--
-- Name: skill_dependencies skill_dependencies_needs_skill_needs_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT skill_dependencies_needs_skill_needs_revision_fkey FOREIGN KEY (needs_skill, needs_revision) REFERENCES public.skill_revisions(skill_id, revision);


--
-- Name: skill_dependencies skill_dependencies_skill_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT skill_dependencies_skill_id_revision_fkey FOREIGN KEY (skill_id, revision) REFERENCES public.skill_revisions(skill_id, revision);


--
-- Name: skill_files skill_files_object_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_files
    ADD CONSTRAINT skill_files_object_hash_fkey FOREIGN KEY (object_hash) REFERENCES public.objects(hash);


--
-- Name: skill_files skill_files_skill_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_files
    ADD CONSTRAINT skill_files_skill_id_revision_fkey FOREIGN KEY (skill_id, revision) REFERENCES public.skill_revisions(skill_id, revision);


--
-- Name: skill_packs skill_packs_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_packs
    ADD CONSTRAINT skill_packs_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: skill_revisions skill_revisions_published_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_revisions
    ADD CONSTRAINT skill_revisions_published_by_fkey FOREIGN KEY (published_by) REFERENCES public.members(id);


--
-- Name: skill_revisions skill_revisions_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_revisions
    ADD CONSTRAINT skill_revisions_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skill_packs(id);


--
-- Name: source_assessments source_assessments_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_assessments
    ADD CONSTRAINT source_assessments_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: source_assessments source_assessments_artifact_id_artifact_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_assessments
    ADD CONSTRAINT source_assessments_artifact_id_artifact_version_fkey FOREIGN KEY (artifact_id, artifact_version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: source_assessments source_assessments_feedback_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_assessments
    ADD CONSTRAINT source_assessments_feedback_id_fkey FOREIGN KEY (feedback_id) REFERENCES public.feedback(id);


--
-- Name: source_assessments source_assessments_source_id_observed_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_assessments
    ADD CONSTRAINT source_assessments_source_id_observed_version_fkey FOREIGN KEY (source_id, observed_version) REFERENCES public.source_versions(source_id, version);


--
-- Name: source_assessments source_assessments_source_id_pinned_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_assessments
    ADD CONSTRAINT source_assessments_source_id_pinned_version_fkey FOREIGN KEY (source_id, pinned_version) REFERENCES public.source_versions(source_id, version);


--
-- Name: source_object_cleanup source_object_cleanup_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_object_cleanup
    ADD CONSTRAINT source_object_cleanup_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id);


--
-- Name: source_passages source_passages_source_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_passages
    ADD CONSTRAINT source_passages_source_id_version_fkey FOREIGN KEY (source_id, version) REFERENCES public.source_versions(source_id, version) ON DELETE CASCADE;


--
-- Name: source_versions source_versions_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_versions
    ADD CONSTRAINT source_versions_author_fkey FOREIGN KEY (author) REFERENCES public.members(id);


--
-- Name: source_versions source_versions_object_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_versions
    ADD CONSTRAINT source_versions_object_hash_fkey FOREIGN KEY (object_hash) REFERENCES public.objects(hash);


--
-- Name: source_versions source_versions_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_versions
    ADD CONSTRAINT source_versions_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id);


--
-- Name: sources sources_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.members(id);


--
-- Name: sources sources_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: sources sources_recovered_as_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_recovered_as_fkey FOREIGN KEY (recovered_as) REFERENCES public.sources(id);


--
-- Name: spend spend_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: spend spend_originating_department_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_originating_department_fkey FOREIGN KEY (originating_department) REFERENCES public.departments(id);


--
-- Name: spend spend_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: spend spend_resource_budget_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_resource_budget_team_id_fkey FOREIGN KEY (resource_budget, team_id) REFERENCES public.resource_budgets(id, team_id);


--
-- Name: spend spend_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: spend spend_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spend
    ADD CONSTRAINT spend_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: starter_samples starter_samples_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.starter_samples
    ADD CONSTRAINT starter_samples_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: starter_samples starter_samples_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.starter_samples
    ADD CONSTRAINT starter_samples_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: starter_samples starter_samples_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.starter_samples
    ADD CONSTRAINT starter_samples_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: step_dispatch_waits step_dispatch_waits_agent_id_agent_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_dispatch_waits
    ADD CONSTRAINT step_dispatch_waits_agent_id_agent_revision_fkey FOREIGN KEY (agent_id, agent_revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: step_dispatch_waits step_dispatch_waits_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_dispatch_waits
    ADD CONSTRAINT step_dispatch_waits_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: step_rule_replacements step_rule_replacements_rule_id_rule_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_rule_replacements
    ADD CONSTRAINT step_rule_replacements_rule_id_rule_revision_fkey FOREIGN KEY (rule_id, rule_revision) REFERENCES public.rule_versions(rule_id, revision);


--
-- Name: step_rule_replacements step_rule_replacements_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_rule_replacements
    ADD CONSTRAINT step_rule_replacements_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: step_rule_waits step_rule_waits_rule_id_rule_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_rule_waits
    ADD CONSTRAINT step_rule_waits_rule_id_rule_revision_fkey FOREIGN KEY (rule_id, rule_revision) REFERENCES public.rule_versions(rule_id, revision);


--
-- Name: step_rule_waits step_rule_waits_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_rule_waits
    ADD CONSTRAINT step_rule_waits_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: step_tool_choice_waits step_tool_choice_waits_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.step_tool_choice_waits
    ADD CONSTRAINT step_tool_choice_waits_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.run_tool_choices(run_id, ordinal) ON DELETE CASCADE;


--
-- Name: superseded_calls superseded_calls_review_control_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superseded_calls
    ADD CONSTRAINT superseded_calls_review_control_fkey FOREIGN KEY (review_control) REFERENCES public.call_reviews(control_id);


--
-- Name: superseded_calls superseded_calls_run_id_ordinal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superseded_calls
    ADD CONSTRAINT superseded_calls_run_id_ordinal_fkey FOREIGN KEY (run_id, ordinal) REFERENCES public.invocations(run_id, ordinal);


--
-- Name: takeover_reviews takeover_reviews_artifact_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeover_reviews
    ADD CONSTRAINT takeover_reviews_artifact_id_version_fkey FOREIGN KEY (artifact_id, version) REFERENCES public.artifact_versions(artifact_id, version);


--
-- Name: takeover_reviews takeover_reviews_assignment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeover_reviews
    ADD CONSTRAINT takeover_reviews_assignment_fkey FOREIGN KEY (assignment) REFERENCES public.reviewer_handoffs(id);


--
-- Name: takeover_reviews takeover_reviews_reviewer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeover_reviews
    ADD CONSTRAINT takeover_reviews_reviewer_fkey FOREIGN KEY (reviewer) REFERENCES public.members(id);


--
-- Name: team_members team_members_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: team_rules team_rules_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rules
    ADD CONSTRAINT team_rules_author_fkey FOREIGN KEY (author) REFERENCES public.members(id);


--
-- Name: team_rules team_rules_id_published_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rules
    ADD CONSTRAINT team_rules_id_published_revision_fkey FOREIGN KEY (id, published_revision) REFERENCES public.rule_versions(rule_id, revision);


--
-- Name: team_rules team_rules_maintainer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rules
    ADD CONSTRAINT team_rules_maintainer_fkey FOREIGN KEY (maintainer) REFERENCES public.members(id);


--
-- Name: team_rules team_rules_proposed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rules
    ADD CONSTRAINT team_rules_proposed_by_fkey FOREIGN KEY (proposed_by) REFERENCES public.members(id);


--
-- Name: team_rules team_rules_proposed_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rules
    ADD CONSTRAINT team_rules_proposed_owner_fkey FOREIGN KEY (proposed_owner) REFERENCES public.members(id);


--
-- Name: team_rules team_rules_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_rules
    ADD CONSTRAINT team_rules_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: team_starters team_starters_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_starters
    ADD CONSTRAINT team_starters_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: team_starters team_starters_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_starters
    ADD CONSTRAINT team_starters_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: teams teams_budget_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_budget_owner_fkey FOREIGN KEY (budget_owner) REFERENCES public.members(id);


--
-- Name: teams teams_trace_manager_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_trace_manager_fkey FOREIGN KEY (trace_manager) REFERENCES public.members(id);


--
-- Name: telemetry_outbox telemetry_outbox_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telemetry_outbox
    ADD CONSTRAINT telemetry_outbox_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: text_reply_checkpoints text_reply_checkpoints_run_id_ordinal_attempt_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.text_reply_checkpoints
    ADD CONSTRAINT text_reply_checkpoints_run_id_ordinal_attempt_no_fkey FOREIGN KEY (run_id, ordinal, attempt_no) REFERENCES public.run_working_sets(run_id, ordinal, attempt_no) ON DELETE CASCADE;


--
-- Name: trace_events trace_events_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trace_events
    ADD CONSTRAINT trace_events_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: trace_grants trace_grants_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trace_grants
    ADD CONSTRAINT trace_grants_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: trace_grants trace_grants_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trace_grants
    ADD CONSTRAINT trace_grants_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runs(id);


--
-- Name: validation_files validation_files_object_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_files
    ADD CONSTRAINT validation_files_object_hash_fkey FOREIGN KEY (object_hash) REFERENCES public.objects(hash);


--
-- Name: validation_files validation_files_trial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_files
    ADD CONSTRAINT validation_files_trial_id_fkey FOREIGN KEY (trial_id) REFERENCES public.validations(id);


--
-- Name: validation_pictures validation_pictures_object_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_pictures
    ADD CONSTRAINT validation_pictures_object_hash_fkey FOREIGN KEY (object_hash) REFERENCES public.objects(hash);


--
-- Name: validation_pictures validation_pictures_trial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_pictures
    ADD CONSTRAINT validation_pictures_trial_id_fkey FOREIGN KEY (trial_id) REFERENCES public.validations(id);


--
-- Name: validation_reviews validation_reviews_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_reviews
    ADD CONSTRAINT validation_reviews_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: validation_reviews validation_reviews_trial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_reviews
    ADD CONSTRAINT validation_reviews_trial_id_fkey FOREIGN KEY (trial_id) REFERENCES public.validations(id);


--
-- Name: validation_skill_inputs validation_skill_inputs_skill_id_skill_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_skill_inputs
    ADD CONSTRAINT validation_skill_inputs_skill_id_skill_revision_fkey FOREIGN KEY (skill_id, skill_revision) REFERENCES public.skill_revisions(skill_id, revision);


--
-- Name: validation_skill_inputs validation_skill_inputs_trial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_skill_inputs
    ADD CONSTRAINT validation_skill_inputs_trial_id_fkey FOREIGN KEY (trial_id) REFERENCES public.validations(id) ON DELETE CASCADE;


--
-- Name: validation_withdrawals validation_withdrawals_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_withdrawals
    ADD CONSTRAINT validation_withdrawals_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: validation_withdrawals validation_withdrawals_trial_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validation_withdrawals
    ADD CONSTRAINT validation_withdrawals_trial_id_fkey FOREIGN KEY (trial_id) REFERENCES public.validations(id);


--
-- Name: validations validations_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: validations validations_agent_id_revision_build_digest_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_agent_id_revision_build_digest_fkey FOREIGN KEY (agent_id, revision, build_digest) REFERENCES public.agent_build_manifests(agent_id, revision, digest);


--
-- Name: validations validations_agent_id_revision_check_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_agent_id_revision_check_id_fkey FOREIGN KEY (agent_id, revision, check_id) REFERENCES public.agent_checks(agent_id, revision, id);


--
-- Name: validations validations_agent_id_revision_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_agent_id_revision_fkey FOREIGN KEY (agent_id, revision) REFERENCES public.agent_revisions(agent_id, revision);


--
-- Name: workflow_template_adoptions workflow_template_adoptions_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_adoptions
    ADD CONSTRAINT workflow_template_adoptions_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: workflow_template_adoptions workflow_template_adoptions_project_id_plan_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_adoptions
    ADD CONSTRAINT workflow_template_adoptions_project_id_plan_version_fkey FOREIGN KEY (project_id, plan_version) REFERENCES public.plans(project_id, version);


--
-- Name: workflow_template_adoptions workflow_template_adoptions_project_id_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_adoptions
    ADD CONSTRAINT workflow_template_adoptions_project_id_template_id_fkey FOREIGN KEY (project_id, template_id) REFERENCES public.workflow_template_uses(project_id, template_id);


--
-- Name: workflow_template_adoptions workflow_template_adoptions_template_id_from_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_adoptions
    ADD CONSTRAINT workflow_template_adoptions_template_id_from_version_fkey FOREIGN KEY (template_id, from_version) REFERENCES public.workflow_template_versions(template_id, version);


--
-- Name: workflow_template_adoptions workflow_template_adoptions_template_id_to_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_adoptions
    ADD CONSTRAINT workflow_template_adoptions_template_id_to_version_fkey FOREIGN KEY (template_id, to_version) REFERENCES public.workflow_template_versions(template_id, version);


--
-- Name: workflow_template_builds workflow_template_builds_agent_id_agent_revision_build_dig_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_builds
    ADD CONSTRAINT workflow_template_builds_agent_id_agent_revision_build_dig_fkey FOREIGN KEY (agent_id, agent_revision, build_digest) REFERENCES public.agent_build_manifests(agent_id, revision, digest);


--
-- Name: workflow_template_builds workflow_template_builds_template_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_builds
    ADD CONSTRAINT workflow_template_builds_template_id_version_fkey FOREIGN KEY (template_id, version) REFERENCES public.workflow_template_versions(template_id, version);


--
-- Name: workflow_template_uses workflow_template_uses_actor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_uses
    ADD CONSTRAINT workflow_template_uses_actor_fkey FOREIGN KEY (actor) REFERENCES public.members(id);


--
-- Name: workflow_template_uses workflow_template_uses_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_uses
    ADD CONSTRAINT workflow_template_uses_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: workflow_template_uses workflow_template_uses_template_id_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_uses
    ADD CONSTRAINT workflow_template_uses_template_id_version_fkey FOREIGN KEY (template_id, version) REFERENCES public.workflow_template_versions(template_id, version);


--
-- Name: workflow_template_versions workflow_template_versions_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_versions
    ADD CONSTRAINT workflow_template_versions_author_fkey FOREIGN KEY (author) REFERENCES public.members(id);


--
-- Name: workflow_template_versions workflow_template_versions_origin_project_origin_plan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_versions
    ADD CONSTRAINT workflow_template_versions_origin_project_origin_plan_fkey FOREIGN KEY (origin_project, origin_plan) REFERENCES public.plans(project_id, version);


--
-- Name: workflow_template_versions workflow_template_versions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_template_versions
    ADD CONSTRAINT workflow_template_versions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.workflow_templates(id);


--
-- Name: workflow_templates workflow_templates_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_owner_fkey FOREIGN KEY (owner) REFERENCES public.members(id);


--
-- Name: workflow_templates workflow_templates_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- PostgreSQL database dump complete
--


